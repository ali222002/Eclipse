// app.js
const express = require('express');
const bodyParser = require('body-parser');
const passport = require('passport');
const cors = require('cors');
const path = require('path')
const ErrorMiddelware = require('./middelwares/ErrorMiddelware');
const { allowHeaders } = require('./utils/headers');

require('./config/db');

const app = express();

// Body parser middleware
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
// app.use(cors({
//     origin: 'http://localhost:3000',
//     credentials: true
// }));

// Static folder

app.all(/.*/, allowHeaders);

app.use('/upload', express.static(path.join(__dirname, '..' , 'upload')));


// // Passport middleware
// app.use(passport.initialize());

// // Passport config
// require('./config/passport')(passport);

app.use('/api', require('./routes/index.route'));

app.get('/', (req, res) => {
    res.send('Hello World');
});
app.use(ErrorMiddelware)

module.exports = app;