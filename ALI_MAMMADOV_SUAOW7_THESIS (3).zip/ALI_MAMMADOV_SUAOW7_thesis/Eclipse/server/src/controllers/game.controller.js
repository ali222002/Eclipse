// controllers/gameController.js
const Comment = require('../models/Comment.model');
const Game = require('../models/Game.model');
const User = require('../models/User.model');
const { ValidationError, APIError } = require('../utils/ApiError');
const CatchAsync = require('../utils/CatchAsync');
const { calculateSimilarity } = require('../utils/game');


let GameController = {
  createGame: CatchAsync(async (req, res, next) => {

    const { description, price, type, name } = req.body;
    let pictures = req.files.map((file) => file.path);
    let thumbnail = pictures.shift();
    let download = pictures.pop();

    if (!thumbnail || !description || !price || !pictures || !type) {
      throw new ValidationError("All fields are required");
    }

    if (!Array.isArray(pictures)) {
      throw new ValidationError("Exactly 4 pictures are required");
    }

    const game = new Game({ thumbnail, description, price, pictures, type, user: req.user._id, downloadLink: download, name });
    await game.save();
    res.status(201).json({ msg: 'Game created successfully', game });
  }),

  getGames: CatchAsync(async (req, res, next) => {
    const games = await Game.find()
      .sort({ createdAt: -1 })

    res.json(games);
  }),

  getMyGames: CatchAsync(async (req, res, next) => {
    // return comments length also only length not whole comments
    const games = await Game.find({ user: req.user._id })
      // length of comments
      .populate('comments')
      .sort({ createdAt: -1 });

    res.json(games);
  }),

  getGameById: CatchAsync(async (req, res, next) => {
    const game = await Game.findById(req.params.id)
      .populate('comments')
      .populate('user');

    let comments = await Comment.find({ game: game._id }).populate('user');
    game.comments = comments;

    if (!game) {
      throw new APIError(404, "Game not found");
    }
    res.json(game);
  }),

  updateGame: CatchAsync(async (req, res, next) => {
    const { thumbnail, description, price, pictures, type, name } = req.body;
    const game = await Game.findById(req.params.id);

    if (!game) {
      throw new ValidationError("Game not found");
    }

    if (thumbnail) game.thumbnail = thumbnail;
    if (name) game.name = name;
    if (description) game.description = description;
    if (price) game.price = price;
    if (pictures && Array.isArray(pictures) && pictures.length === 4) {
      game.pictures = pictures;
    }
    if (type) game.type = type;

    await game.save();
    res.json({ msg: 'Game updated successfully', game });
  }),

  deleteGame: CatchAsync(async (req, res, next) => {
    const game = await Game.findById(req.params.id);
    if (!game) {
      throw new ValidationError("Game not found");
    }

    await game.remove();
    res.json({ msg: 'Game deleted successfully' });
  }),

  likeGame: CatchAsync(async (req, res, next) => {
    const game = await Game.findById(req.params.id);
    if (!game) {
      throw new ValidationError("Game not found");
    }

    if (!game.likes.includes(req.user._id)) {
      game.likes.push(req.user._id);
      //throw new ValidationError("You already liked this game");
    }

    if (game.dislikes.includes(req.user._id)) {
      game.dislikes = game.dislikes.filter((id) => id.toString() !== req.user._id);
    }


    await game.save();

    res.json({ msg: 'Game liked successfully', game });
  }),

  unlikeGame: CatchAsync(async (req, res, next) => {
    const game = await Game.findById(req.params.id);
    if (!game) {
      throw new ValidationError("Game not found");
    }

    if (!game.dislikes.includes(req.user._id)) {
      //throw new ValidationError("You already disliked this game");
      game.dislikes.push(req.user._id);
    }

    if (game.likes.includes(req.user._id)) {
      game.likes = game.likes.filter((id) => id.toString() !== req.user._id);
    }


    await game.save();

    res.json({ msg: 'Game unliked successfully', game });
  }),

  commentGame: CatchAsync(async (req, res, next) => {
    const { comment } = req.body;
    const game = await Game.findById(req.params.id);
    if (!game) {
      throw new APIError(404, "Game not found");
    }

    let newComment = {
      user: req.user._id,
      comment,
      game: game._id
    }

    await Comment.create(newComment);

    await game.save();
    res.json({ msg: 'Comment added successfully', game });

  }),

  buyGames: CatchAsync(async (req, res, next) => {

    let user = await User.findById(req.user._id);
    if (!user) {
      throw new APIError(404, "User not found");
    }

    let cart = user.cart;
    if (!cart.length) {
      throw new APIError(400, "Cart is empty");
    }


    let games = cart

    games = await Game.find({ _id: { $in: games } });

    // update game.bought + 1 for each game bought
    games.forEach(async (game) => {
      game.bought += 1;
      await game.save();
    });

    // add games to user's library
    if (!user.gamesBought) {
      user.gamesBought = [];
    }

    // if already bought a game, dont add it again
    games = games.filter((game) => !user.gamesBought.includes(game._id));
    user.gamesBought.push(...games);
    user.cart = [];
    user.wishlist = user.wishlist.filter(item => !cart.includes(item._id))
    await user.save();

    res.json({ msg: 'Games bought successfully', user });
  }),

  playGame: CatchAsync(async (req, res, next) => {
    let user = await User.findById(req.user._id);
    if (!user) {
      throw new APIError(404, "User not found");
    }

    let { game: gameId } = req.body;
    if (!gameId) {
      throw new APIError(400, "Game is required");
    }

    let game = await Game.findById(gameId);
    if (!game) {
      throw new APIError(404, "Game not found");
    }

    if (!user.gamesPlayed) {
      user.gamesPlayed = [];
    }

    if (!user.gamesPlayed.includes(game._id)) {
      user.gamesPlayed.push(game._id);
    }

    await user.save();
    res.json({ msg: 'Game played successfully', user });
  }),

  getPlayedGames: CatchAsync(async (req, res, next) => {
    let user = await User.findById(req.user._id)
      .populate('gamesPlayed', 'thumbnail description  name price type downloadLink')
    // reverse the order of games
    if (!user) {
      throw new APIError(404, "User not found");
    }

    // reverse
    res.json(user.gamesPlayed?.reverse()?.slice(0, 5));
  }),

  getBoughtGames: CatchAsync(async (req, res, next) => {
    let user = await User.findById(req.user._id)
      .populate('gamesBought', 'thumbnail description  name price type downloadLink');
    if (!user) {
      throw new APIError(404, "User not found");
    }

    res.json(user.gamesBought);
  }),

  getRecommendedGames: CatchAsync(async (req, res, next) => {
    const userId = req.user?._id;

    // Fetch the user's details including games interactions
    const user = await User.findById(userId)
      .populate('gamesLiked')
      .populate('gamesDisliked')
      .populate('gamesPlayed')
      .populate('gamesBought');

    if (!user) {
      // show games with highest bought
      let games = await Game.find().sort({ bought: -1 }).limit(10);
      return res.json(games.map(game => {
        // const similarity = calculateSimilarity(game, Array.from(gameTypes));
        return { game, similarity: 1 };
      }));
    }
    // Extract all game types from user's interactions
    const gameTypes = new Set();
    [...user.gamesLiked, ...user.gamesDisliked, ...user.gamesPlayed, ...user.gamesBought].forEach(game => {
      gameTypes.add(game.type);
    });

    // Create an array of game IDs that the user already has in their library
    const userLibrary = new Set([...user.gamesLiked, ...user.gamesDisliked, ...user.gamesPlayed, ...user.gamesBought, ...user.cart, ...user.wishlist].map(game => game._id.toString()));

    // Find games that match the types and are not in the user's library
    const recommendedGames = await Game.find({
      type: { $in: Array.from(gameTypes) },
      _id: { $nin: Array.from(userLibrary) }
    });

    // Optionally, calculate similarity percentage and filter by a threshold
    let resp = recommendedGames.map(game => {
      const similarity = calculateSimilarity(game, Array.from(gameTypes));
      return { game, similarity };
    }).filter(game => game.similarity > 0.5);  // Assuming you want at least 50% similarity

    if (!resp.length) {
      // show games with highest bought
      let games = await Game.find().sort({ bought: -1 }).limit(10);
      // game similarity 
      return res.json(
        games.map(game => {
          const similarity = calculateSimilarity(game, Array.from(gameTypes));
          return { game, similarity };
        })
      );
    }

    res.json(resp);
  }),
}

module.exports = GameController;
