const Comment = require("../models/Comment.model");
const Forum = require("../models/Forum.model");
const { APIError, ValidationError } = require("../utils/ApiError");
const CatchAsync = require("../utils/CatchAsync");

let ForumController = {
    createForum: CatchAsync(async (req, res, next) => {
        let { title, description } = req.body;

        if (!title || !description) {
            throw new ValidationError("All fields are required");
        }
        let forum = await Forum.create({
            title,
            description,
            user: req.user._id
        });

        res.json({ msg: 'Forum created successfully', forum });
    }),

    getForums: CatchAsync(async (req, res, next) => {
        // get user of forum, comments
        // for all comments get user of comment
        let forums = await Forum.find().populate({
            path: 'user',
            select: 'username profilePic email',
            model: 'Users'
        })
        .populate({
            path: 'comments',
            populate: {
                path: 'user',
                select: 'username profilePic email',
                model: 'Users'
            }
        
        });

        res.json({ forums });
    }),

    getForumById: CatchAsync(async (req, res, next) => {
        let forum = await Forum.findById(req.params.id).populate('user').populate('comments');

        if (!forum) {
            throw new APIError(404, "Forum not found");
        }

        res.json({ forum });
    }),

    addComment: CatchAsync(async (req, res, next) => {
        let { comment } = req.body;
        let forum = await Forum.findById(req.params.id);

        if (!forum) {
            throw new APIError(404, "Forum not found");
        }

        let newComment = await Comment.create({
            comment,
            user: req.user._id,
            forum: forum._id
        });

        forum.comments.push(newComment._id);
        await forum.save();

        res.json({ msg: 'Comment added successfully', newComment });
    }),
};

module.exports = ForumController;