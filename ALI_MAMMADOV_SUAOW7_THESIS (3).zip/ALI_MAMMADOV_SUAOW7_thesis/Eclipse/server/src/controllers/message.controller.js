const ChatModel = require('../models/Chat.model');
const Message = require('../models/Message.model');
const { APIError } = require('../utils/ApiError');
const CatchAsync = require('../utils/CatchAsync');

class MessageController {
    static PAGE_SIZE = 40;

    static createMessage = CatchAsync(async (req, res, next) => {
        const { user } = req;
        const { chatId, message, receiverId, messagetype, filedata, link } = req.body;

        if (!user) throw new APIError(400, "Login First");

        if (!chatId || !message || !receiverId) throw new APIError(400, "Data is missing {chatId, receiverId, message}");

        if (user?._id === receiverId) throw new APIError(400, "You can't send message to yourself");

        if (messagetype === "file" && !filedata) throw new APIError(400, "File Data is missing");

        let messageData = await Message.create({
            chatId: chatId,
            message,
            senderId: user._id,
            receiverId: receiverId,
            messageType: messagetype,
            filedata,
            link,
        });

        // update chat last message
        let chat = await ChatModel.findOneAndUpdate(
            { _id: chatId },
            { lastMessage: message, lastMessageTime: new Date()},
            { new: true }
        );

        res.status(200).json({
            success: true,
            message: "Message Sent Successfully",
            data: {
                message: messageData,
            },
        });
    });

    static getChatMessages = CatchAsync(async (req, res, next) => {
        const { chatId } = req.params;
        if (!chatId) throw new APIError(400, "Chat Id is missing");

        const { user } = req;
        if (!user) throw new APIError(401, "Login First");

        const cId = chatId;

        // Pagination and limit
        const { page, limit } = req.query;
        const p = page && !isNaN(parseInt(page)) ? parseInt(page) : 1;
        const requiredLimit = parseInt(limit) || this.PAGE_SIZE;

        const messages = await Message.find({ chatId: cId })
            .skip((p - 1) * requiredLimit)
            .limit(requiredLimit)
            .lean();

        const totalMessages = await Message.countDocuments({ chatId: cId });

        const totalPages = Math.ceil(totalMessages / requiredLimit);

        res.status(200).json({
            success: true,
            message: "Messages Fetched Successfully",
            data: {
                messages,
                currentPage: p,
                pageSize: requiredLimit,
                totalPages,
            },
        });
    });
}

module.exports = MessageController;
