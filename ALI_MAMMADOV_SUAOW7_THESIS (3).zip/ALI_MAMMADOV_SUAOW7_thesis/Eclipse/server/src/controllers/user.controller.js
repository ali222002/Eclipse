const FriendRequest = require("../models/FriendRequest.model");
const User = require("../models/User.model");
const { APIError } = require("../utils/ApiError");
const CatchAsync = require("../utils/CatchAsync");

const UserController = {
    getProfile: CatchAsync(async (req, res, next) => {
        let user = await User.findById(req.user?._id);

        if (!user) {
            throw new APIError(404, "User not found");
        }

        res.json(user);
    }),

    updateBio: CatchAsync(async (req, res, next) => {
        let { bio } = req.body;
        if (!bio) {
            throw new APIError(400, "Bio is required");
        }
        let user = await User.findById(req.user?._id);
        if (!user) {
            throw new APIError(404, "User not found");
        }

        user.bio = bio

        await user.save();
        res.json({ message: "Bio updated successfully" });
    }),

    updateProfile: CatchAsync(async (req, res, next) => {
        const { email, username } = req.body

        let user = await User.findById(req.user?._id);
        if (!user) {
            throw new APIError(404, "User not found");
        }

        // check if email or username is already taken by another user not including the current user
        let exists = await User.findOne({
            _id: { $ne: req.user?._id },
            $or: [
                { email },
                { username }
            ]
        });

        if (exists) {
            throw new APIError(400, "Email or username is already taken");
        }


        if (username) {
            user.username = username;
        }

        if (email) {
            user.email = email;
        }

        await user.save();
        res.json({ message: "Profile updated successfully", user });
    }),

    updateProfilePic: CatchAsync(async (req, res, next) => {
        console.log(req.file);
        let image = req.file?.path;
        if (!image) {
            throw new APIError(400, "Image is required");
        }

        let user = await User.findById(req.user?._id);
        if (!user) {
            throw new APIError(404, "User not found");
        }

        user.profilePic = image;

        await user.save();
        res.json({ message: "Profile picture updated successfully", link: image });
    }),

    getFriendshipStatus: CatchAsync(async (req, res, next) => {
        // return all users and their friendship status
        let user = await User.findById(req.user?._id);
        let friends = user.friends;
        console.log(friends);
        // except the current user
        let allUsers = await User.find({ _id: { $ne: req.user?._id } });

        // let users = allUsers.map(async user => {
        //     let status = "none";
        //     if (friends.includes(user._id)) {
        //         status = "friends";
        //     } else {
        //         let request = await FriendRequest.findOne({ sender: req.user?._id, receiver: user._id });
        //         if (request) {
        //             status = request.status;
        //         }
        //     }

        //     console.log(status);
        //     return {
        //         user,
        //         status
        //     }
        // });

        let users = []

        for (let i = 0; i < allUsers.length; i++) {
            let status = "none";
            if (friends.includes(allUsers[i]._id)) {
                status = "accepted";
            } else {
                let request = await FriendRequest.findOne({ sender: req.user?._id, receiver: allUsers[i]._id });
                if (request) {
                    status = request.status;
                }
            }

            users.push({
                user: allUsers[i],
                status
            });
        }


        res.json(users);
    }),

    sendFriendRequest: CatchAsync(async (req, res, next) => {
        let userId = req.params.id;

        console.log(userId, req.user._id);

        if (!userId) {
            throw new APIError(400, "User id is required");
        }

        if (userId === req.user?._id) {
            throw new APIError(400, "You cannot send friend request to yourself");
        }

        // check if already friend or friend request sent
        let user = await User.findById(userId);
        if (!user) {
            throw new APIError(404, "User not found");
        }

        let existfriendRequest = await FriendRequest.findOne({
            $or: [
                {
                    sender: req.user?._id,
                    receiver: userId
                },
                {
                    sender: userId,
                    receiver: req.user?._id
                }
            ]
        });

        if (existfriendRequest) {
            console.log("Friend req already");
            if (existfriendRequest.status === "pending" || user.friends.includes(userId)) throw new APIError(400, "Friend request already sent or already friends");

            console.log("set to pending");
            existfriendRequest.status = "pending"
            await existfriendRequest.save()

            return res.json({ message: "Friend request sent" });
        }


        let friendRequest = new FriendRequest({
            sender: req.user?._id,
            receiver: userId,
            status: "pending"
        });

        await friendRequest.save();
        res.json({ message: "Friend request sent" });
    }),

    acceptFriendRequest: CatchAsync(async (req, res, next) => {
        let userId = req.user?._id;

        let user = await User.findById(userId);
        if (!user) {
            throw new APIError(404, "User not found");
        }

        let friendRequest = await FriendRequest.findOne({ sender: req.params.id, receiver: userId });

        if (!friendRequest) {
            throw new APIError(404, "Friend request not found");
        }

        friendRequest.status = "accepted";

        await friendRequest.save();

        let otherUser = await User.findById(req.params.id);
        if (!otherUser) {
            throw new APIError(404, "User not found");
        }

        otherUser.friends.push(userId);
        user.friends.push(req.params.id);

        await user.save();
        await otherUser.save();

        res.json({ message: "Friend request accepted" });
    }),

    rejectFriendRequest: CatchAsync(async (req, res, next) => {
        let userId = req.user?._id;

        let user = await User.findById(userId);
        if (!user) {
            throw new APIError(404, "User not found");
        }

        let friendRequest = await FriendRequest.findOne({ sender: req.params.id, receiver: userId });

        if (!friendRequest) {
            throw new APIError(404, "Friend request not found");
        }

        friendRequest.status = "rejected";

        await friendRequest.save();
        await FriendRequest.deleteOne({
            _id: friendRequest?._id
        })

        res.json({ message: "Friend request rejected" });
    }),

    getFriends: CatchAsync(async (req, res, next) => {
        let userId = req.user?._id;

        let user = await User.findById(userId).populate("friends");
        if (!user) {
            throw new APIError(404, "User not found");
        }

        let friends = user.friends;

        res.json(friends);
    }),

    unfriendUser: CatchAsync(async (req, res, next) => {
        let userId = req.user?._id;

        let user = await User.findById(userId)
        if (!user) throw new APIError(404, "User not found")

        let friends = user.friends.filter((friend) => friend.toString() !== req.params.id)

        user.friends = friends
        await user.save()

        // on other user side
        let otherUser = await User.findById(req.params.id)
        if (!otherUser) throw new APIError(404, "User not found")

        let otherUserFriends = otherUser.friends.filter((friend) => friend.toString() !== userId)

        otherUser.friends = otherUserFriends
        await otherUser.save()

        // delete friend request
        await FriendRequest.deleteOne({
            $or: [
                {
                    sender: userId,
                    receiver: req.params.id
                },
                {
                    sender: req.params.id,
                    receiver: userId
                }
            ]
        })

        res.json({ message: "User unfriended successfully" })
    }),

    getFriendRequests: CatchAsync(async (req, res, next) => {
        let userId = req.user?._id;

        let user = await User.findById(userId);
        if (!user) {
            throw new APIError(404, "User not found");
        }

        // get all friend requests sent to the user or received by the user
        let friendRequests = await FriendRequest.find({
            $or: [
                // {
                //     sender: userId
                // },
                {
                    receiver: userId
                }
            ],
        })
            .populate("sender")
            .populate("receiver")
            .sort({ createdAt: -1 });

        res.json(friendRequests);
    }),


    updateCart: CatchAsync(async (req, res, next) => {
        let { game } = req.body;
        let userId = req.user._id;

        let user = await User.findById(userId);

        if (!user) {
            throw new APIError(404, "User not found");
        }

        if (user.gamesBought.includes(game)) {
            throw new APIError(400, "Game already bought");
        }

        if (user.cart.includes(game)) {
            console.log("Removing game from cart");
            // remove from cart
            let rem = user.cart.filter((g) => g._id?.toString() !== game);
            user.cart = rem;
            await user.save();
        } else {
            // add to cart
            user.cart.push(game);
            await user.save();
        }

        res.json({ msg: 'Game added to cart successfully', user });

    }),

    removeFromCart: CatchAsync(async (req, res, next) => {
        let { game } = req.body;
        let userId = req.user._id;

        let user = await User.findById(userId);

        if (!user) {
            throw new APIError(404, "User not found");
        }

        user.cart = user.cart.filter((g) => g._id?.toString() !== game);

        await user.save();

        res.json({ msg: 'Game removed from cart successfully', user });
    }),

    updateWishlist: CatchAsync(async (req, res, next) => {
        let { game } = req.body;
        let userId = req.user._id;

        let user = await User.findById(userId);

        if (!user) {
            throw new APIError(404, "User not found");
        }

        if (user.wishlist.includes(game)) {
            let filtered = user.wishlist.filter((g) => g._id?.toString() !== game);
            console.log("Removing game from wishlist", filtered);
            // remove from wishlist
            user.wishlist = filtered;
        } else {
            if (user.gamesBought.includes(game)) {
                throw new APIError(400, "Game already bought");
            }
            // add to wishlist
            user.wishlist.push(game);
        }

        await user.save();

        res.json({ msg: 'Game added to wishlist successfully', user });

    }),

    removeFromWishlist: CatchAsync(async (req, res, next) => {
        let { game } = req.body;
        let userId = req.user._id;

        let user = await User.findById(userId);

        if (!user) {
            throw new APIError(404, "User not found");
        }

        user.wishlist = user.wishlist.filter((g) => g._id?.toString() !== game._id);

        await user.save();

        res.json({ msg: 'Game removed from wishlist successfully', user });
    }),

    getCart: CatchAsync(async (req, res, next) => {
        let userId = req.user._id;

        let user = await User.findById(userId).populate("cart");

        if (!user) {
            throw new APIError(404, "User not found");
        }

        res.json(user.cart);
    }),

    getWishlist: CatchAsync(async (req, res, next) => {
        let userId = req.user._id;

        let user = await User
            .findById(userId)
            .populate("wishlist");

        if (!user) {
            throw new APIError(404, "User not found");
        }

        res.json(user.wishlist);

    })
}

module.exports = UserController;