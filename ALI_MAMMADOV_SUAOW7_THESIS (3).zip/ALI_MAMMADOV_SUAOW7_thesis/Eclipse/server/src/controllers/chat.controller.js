const Chat = require('../models/Chat.model');
const Message = require('../models/Message.model');
const { APIError } = require('../utils/ApiError');
const CatchAsync = require('../utils/CatchAsync');

class ChatController {
    static PAGE_SIZE = 10;

    static accessChat = CatchAsync(async (req, res) => {
        const { userid } = req.body;  // User ID of the other user to chat with
        const { _id: currentUserId } = req.user;  // ID of the current user
    
        // Check if trying to initiate a chat with oneself
        if (userid === currentUserId) {
            return res.status(400).json({ message: 'Cannot chat with yourself' });
        }
    
        try {
            let chat = await Chat.findOne({
                userIds: { $all: [currentUserId, userid] }
            });
    
            // If a chat does not exist, create a new one
            if (!chat) {
                chat = await Chat.create({ userIds: [currentUserId, userid], lastMessage: 'Started Chat', lastMessageTime: Date.now()});
            }
    
            res.status(200).json(chat);
        } catch (error) {
            res.status(500).json({ message: error.message });
        }
    });
    

    static getChats = CatchAsync(async (req, res) => {
        const { user } = req;
        if (!user || !user._id) throw new APIError(404, "Login First");

        const userId = user._id;
        const { page = 1 } = req.query;

        const chats = await Chat.find({ userIds: userId })
            .populate('userIds')
            .skip((page - 1) * ChatController.PAGE_SIZE)
            .limit(ChatController.PAGE_SIZE)
            .lean();

        const total = await Chat.countDocuments({ userIds: userId });

        const chatsToSend = await Promise.all(chats.map(async (chat) => ({
            ...chat,
            users: chat.userIds,
            userIds: chat.userIds.map((user) => user._id),
            unseenMessagesCount: await Message.countDocuments({
                chatId: chat._id,
                receiverId: userId,
                isRead: false,
            }),
        })));

        res.status(200).json({
            success: true,
            message: "Chats Fetched Successfully",
            chats: chatsToSend,
            total,
        });
    });

    static getChat = CatchAsync(async (req, res) => {
        const { user } = req;
        if (!user || !user._id) throw new APIError(404, "Login First");

        const { id: chatId } = req.params;
        if (!chatId) throw new APIError(400, "Chat Id is missing");

        const chat = await Chat.findById(chatId).populate('userIds').lean();
        if (!chat) throw new APIError(404, "Chat not found");

        res.status(200).json({
            success: true,
            message: "Chat Fetched Successfully",
            chat: {
                ...chat,
                users: chat.userIds,
                userIds: chat.userIds.map((user) => user._id),
            },
        });
    });

    static searchChatsWithMessage = CatchAsync(async (req, res) => {
        const { user } = req;
        if (!user || !user._id) throw new APIError(404, "Login First");

        const userId = user._id;
        const { query = '' } = req.query;

        if (query.trim().length === 0) {
            return res.status(200).json({
                success: true,
                message: "Chats Fetched Successfully",
                chats: [],
            });
        }

        const chats = await Chat.aggregate([
            { $match: { userIds: userId } },
            {
                $lookup: {
                    from: 'messages',
                    let: { chatId: '$_id' },
                    pipeline: [
                        { $match: { $expr: { $eq: ['$chatId', '$$chatId'] }, message: { $regex: query, $options: 'i' } } },
                        { $sort: { timestamp: -1 } },
                        { $limit: 1 },
                    ],
                    as: 'lastMessage',
                },
            },
            { $unwind: '$lastMessage' },
        ]);

        res.status(200).json({
            success: true,
            message: "Chats Fetched Successfully",
            chats,
        });
    });
}

module.exports = ChatController;
