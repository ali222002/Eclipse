// controllers/authController.js
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const User = require('../models/User.model');
const keys = require('../config/keys');
const CatchAsync = require('../utils/CatchAsync');
const { APIError, ValidationError } = require('../utils/ApiError');

let AuthController = {
    register: CatchAsync(async (req, res, next) => {
        const { username, email, password } = req.body;
        if (!username || !email || !password) {
            throw new ValidationError("All fields are required");
        }

        // TODO: CHECK USERNAME TOO

        let user = await User.findOne(
            {
                $or: [{
                    username: username
                }, {
                    email: email
                }]
            }
        );
        if (user) {
            throw new APIError(400, 'User already exists');
        }

        user = new User({ username, email, password });
        await user.save();

        const token = jwt.sign(user.toObject(), keys.secretOrKey, { expiresIn: 100 * 3600 });
        res.status(201).json({ msg: 'User registered successfully', user, token: `Bearer ${token}` });
    }),

    login: CatchAsync(async (req, res, next) => {
        const { email, password } = req.body;
        if (!email || !password) {
            throw new ValidationError("All fields are required");
        }

        const user = await User.findOne({ email });
        if (!user) {
            throw new APIError(404, 'User not found')
        }

        const isMatch = await bcrypt.compare(password, user.password);
        if (!isMatch) {
            throw new APIError(400, 'Invalid credentials');
        }

        const token = jwt.sign(user.toObject(), keys.secretOrKey, { expiresIn: 100 * 3600 });
        res.json({ success: true, token: `Bearer ${token}`, user });
    }),

    googleLogin: CatchAsync(async (req, res) => {
        // get user data from google
        const { firstName, lastName, email, googleId, imageUrl } = req.body;
        // Check if user with the same email already exists
        const user = await User?.findOne({ email });
        if (!user) {
            // check if user with the same username already exists
            let username = firstName + lastName;
            const userWithSameUsername = await User.findOne({ username: username });
            if (userWithSameUsername) {
                username = username + Math.floor(Math.random() * 1000);
            }
            // create new user
            const newUser = await User.create({
                username: username,
                email,
                password: googleId,
                profilePic: imageUrl
            });

            let token = jwt.sign(newUser.toObject(), keys.secretOrKey, { expiresIn: 100 * 3600 });

            res.status(201).json({
                success: true,
                user: newUser,
                token: `Bearer ${token}`,
                message: 'User registered successfully',
                status: 201
            });
        } else {
            let token = jwt.sign(user.toObject(), keys.secretOrKey, { expiresIn: 100 * 3600 });
            res.status(200).json({
                success: true,
                user,
                token: `Bearer ${token}`,
                message: 'Login successful',
                status: 200
            });
        }
    }),
    forgotPassword: CatchAsync(async (req, res, next) => {
        const { email } = req.body;
        if (!email) {
            throw new ValidationError("Email is required");
        }

        const user = await User.findOne({ email });
        if (!user) {
            throw new ValidationError("User not found");
        }

        res.json({ success: true, msg: 'Password reset link sent to your email' });
    })


}

module.exports = AuthController;