// define socket constants in an object
const socketEvents = {
    // socket events
    SOCKET_CONNECT: "connected",
    SOCKET_DISCONNECT: "disconnect",
    SOCKET_MESSAGE_RECIEVED: "message recieved",
    SOCKET_TYPING: "typing",
    SOCKET_STOP_TYPING: "stop typing",
    SOCKET_JOIN_CHAT: "join chat",
    SOCKET_LEAVE_CHAT: "leave chat",
    SOCKET_SETUP: "setup",
    SOCKET_SEND_MESSAGE: "new message",
    SOCKET_USER_ONLINE: "user online",
    SOCKET_USER_OFFLINE: "user offline",
    SOCKET_NOTIFICATION: "notification",
};

module.exports = socketEvents;