class APIError extends Error{
    constructor(status = 500, message = "Internal Server Error"){
        super(message)
        this.status = status
    }
}

class ValidationError extends APIError{
    constructor(message = "Validation Error"){
        super(400, message)
    }
}

// export above classes
module.exports = {
    APIError,
    ValidationError
}