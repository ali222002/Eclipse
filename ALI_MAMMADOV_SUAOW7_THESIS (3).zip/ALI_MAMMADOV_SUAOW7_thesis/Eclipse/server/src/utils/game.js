function calculateSimilarity(game, types) {
    // Simple similarity function (example)
    if (types.includes(game?.type)) return 1; // 100% similarity if exactly matching type
    return 0; // 0% similarity if not
}

module.exports = { calculateSimilarity };