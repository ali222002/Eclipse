const {
    SOCKET_SETUP,
    SOCKET_CONNECT,
    SOCKET_TYPING,
    SOCKET_STOP_TYPING,
    SOCKET_MESSAGE_RECIEVED,
    SOCKET_SEND_MESSAGE,
    SOCKET_LEAVE_CHAT,
    SOCKET_DISCONNECT,
    SOCKET_JOIN_CHAT,
    SOCKET_USER_ONLINE,
    SOCKET_USER_OFFLINE,
    SOCKET_NOTIFICATION,
} = require('./socketEvents');


class SocketServer {
    static activeUsers = [];
    static io;
    constructor(server) {
        this.io = require("socket.io")(server, {
            pingTimeout: 60000,
            cors: {
                origin: "http://localhost:3000",
                //credentials: true,
            },
        });
    }

    setup = () => {
        console.log(
            "Socket server is running on port",
        );
        this.io.on("connection", (socket) => {
            console.log("connected");
            socket.on(SOCKET_SETUP, (userData) => {
                console.log("setup");
                // add user to active users
                // userData with socket id
                userData["socketId"] = socket?.id;
                SocketServer.activeUsers.push(userData);

                // join user room
                socket.join(userData?._id);
                socket.emit(SOCKET_CONNECT, SocketServer.activeUsers);
                // broadcast to all users except the sender that user is online
                socket?.broadcast.emit(SOCKET_USER_ONLINE, SocketServer.activeUsers);
            });

            socket.on(SOCKET_JOIN_CHAT, (room) => {
                console.log("join chat", room);
                // check if user is not already in room then join
                socket.join(room);
            });

            socket.on(SOCKET_TYPING, (room) => {
                socket?.broadcast.to(room).emit(SOCKET_TYPING, room);
            });

            socket.on(SOCKET_STOP_TYPING, (room) => {
                socket?.broadcast.to(room).emit(SOCKET_STOP_TYPING, room);
            });

            socket.on(SOCKET_SEND_MESSAGE, (newMessageRecieved) => {
                console.log("send message");
                // if (!newMessageRecieved?.receiverId)
                // return console.log("recieverId not defined");

                // this is sending message twice
                // socket?.broadcast.to(newMessageRecieved?.receiverId).emit(SOCKET_MESSAGE_RECIEVED, newMessageRecieved);
                socket?.to(newMessageRecieved?.chatId).emit(SOCKET_MESSAGE_RECIEVED, newMessageRecieved);
                //socket?.broadcast.emit(SOCKET_MESSAGE_RECIEVED, newMessageRecieved);
            });

            socket.on(SOCKET_LEAVE_CHAT, (roomId) => {
                // leave room
                socket.leave(roomId);
                // IMPLEMENT USER DISCONNECTED
            });

            socket.on(SOCKET_DISCONNECT, () => {
                // user disconnected
                // remove user from active users
                let user = SocketServer.activeUsers.find((user) => user?.socketId === socket?.id);
                SocketServer.activeUsers = SocketServer.activeUsers.filter((user) => user?.socketId !== socket?.id);
                // broadcast to all users except the sender that user is offline
                socket?.broadcast.emit(SOCKET_USER_OFFLINE, SocketServer.activeUsers);
                socket.leave();
            });

            socket.on(SOCKET_NOTIFICATION, (notification) => {
                socket?.broadcast.emit(SOCKET_NOTIFICATION, notification);
            });

            socket.off("setup", () => {
                console.log("USER DISCONNECTED");
            });
        });
    }

}

module.exports = SocketServer;