const allowHeaders = (request, response, next) => {
    const allowedOrigins = ["http://localhost:3000", "https://localhost:3000"];

    const origin = request.headers.origin;

    if (allowedOrigins.includes(origin)) {
        response.setHeader("Access-Control-Allow-Origin", origin);
    }

    response.setHeader("Access-Control-Allow-Methods", "POST, PUT, GET, OPTIONS, DELETE");
    response.setHeader("Access-Control-Allow-Headers", "Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With,observe");
    response.setHeader("Access-Control-Max-Age", "3600");
    response.setHeader("Access-Control-Allow-Credentials", "true");
    response.setHeader("Access-Control-Expose-Headers", "Authorization, responseType, observe");
    response.setHeader("X-Powered-By", "nginx:202");

    if (request.method === "OPTIONS") {
        // Handle preflight OPTIONS request
        response.sendStatus(200);
    } else {
        next();
    }
}

module.exports = { allowHeaders };