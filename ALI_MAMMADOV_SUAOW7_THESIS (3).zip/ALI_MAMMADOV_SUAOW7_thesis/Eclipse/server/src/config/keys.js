// config/keys.js
module.exports = {
    secretOrKey: 'your_secret_key'
  };
  