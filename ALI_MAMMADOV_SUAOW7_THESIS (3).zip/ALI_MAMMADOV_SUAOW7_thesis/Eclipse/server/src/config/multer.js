const multer = require("multer");
const path = require("path");

const storage = multer.diskStorage({
  destination: './upload/images',
  filename: (req, file, cb) => {
    const uniquePrefix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    const fileExtension = path.extname(file.originalname);
    cb(null, `${uniquePrefix}${fileExtension}`);
  }
});

const upload = multer({
  storage: storage,
  limits: {
    fileSize: 100000042321
  }
});

module.exports = upload;
