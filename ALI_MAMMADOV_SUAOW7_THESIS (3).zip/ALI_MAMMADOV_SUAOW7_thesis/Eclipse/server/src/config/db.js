const { default: mongoose } = require("mongoose");

// DB Config
 const db = 'mongodb+srv://alimammadov221002:20022210@cluster0.oczdssz.mongodb.net/Eclipse';
// Connect to MongoDB
mongoose.connect(db, { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => console.log('MongoDB connected'))
  .catch(err => console.log(err));
