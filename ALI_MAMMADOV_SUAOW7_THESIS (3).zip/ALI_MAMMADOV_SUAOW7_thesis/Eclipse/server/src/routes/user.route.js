const express = require('express');
const upload = require('../config/multer');
const UserController = require('../controllers/user.controller');
const router = express.Router();

// update profile picture
router.put('/profilePic', upload.single('file'),  UserController.updateProfilePic)
// update bio
router.put('/bio', UserController.updateBio)
// get user profile
router.get('/profile', UserController.getProfile)

router.put('/profile', UserController.updateProfile)

router.get('/me/friends', UserController.getFriends)

router.get('/friends/requests', UserController.getFriendRequests)

router.get('/friends/status', UserController.getFriendshipStatus)

router.put('/friends/request/:id', UserController.sendFriendRequest)

router.put('/friends/accept/:id', UserController.acceptFriendRequest)

router.put('/friends/reject/:id', UserController.rejectFriendRequest)

router.put('/friends/unfriend/:id', UserController.unfriendUser)

router.put('/cart', UserController.updateCart)

router.put('/wishlist', UserController.updateWishlist)

router.get('/cart', UserController.getCart)

router.get('/wishlist', UserController.getWishlist)


module.exports = router;