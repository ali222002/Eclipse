const express = require('express');
const ChatController = require('../controllers/chat.controller');
const { authenticateToken } = require('../middelwares/auth');
const router = express.Router();

router.post('/', authenticateToken, ChatController?.accessChat);
router.get('/', authenticateToken, ChatController?.getChats);
router.get('/:id', authenticateToken, ChatController?.getChat);
router.get('/search', authenticateToken, ChatController?.searchChatsWithMessage);

module.exports = router;