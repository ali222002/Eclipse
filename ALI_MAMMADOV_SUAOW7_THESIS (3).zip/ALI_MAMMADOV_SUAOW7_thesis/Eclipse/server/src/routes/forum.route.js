const express = require('express');
const ForumController = require('../controllers/forum.controller');
const { authenticateToken } = require('../middelwares/auth');
const router = express.Router();

router.get('/', ForumController.getForums);
router.post('/', authenticateToken, ForumController.createForum);
router.get('/:id', ForumController.getForumById);
router.post('/:id/comment', authenticateToken, ForumController.addComment);

module.exports = router;