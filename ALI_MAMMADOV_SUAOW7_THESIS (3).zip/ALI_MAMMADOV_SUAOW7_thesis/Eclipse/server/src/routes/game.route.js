// routes/game.js
const express = require('express');

const { authenticateToken, getToken } = require('../middelwares/auth');
const GameController = require('../controllers/game.controller');
const upload = require('../config/multer');
const router = express.Router();

// @route   POST /games
// @desc    Create a new game
// @access  Private (Assuming only logged-in users can create games)
router.post('/', authenticateToken, upload.array("pictures", 6), GameController.createGame);

// @route   GET /games
// @desc    Get all games
// @access  Public
router.get('/', GameController.getGames);

// @route   GET /games/recommended
// @desc    Get recommended games
// @access  Public
router.get('/recommended', getToken, GameController.getRecommendedGames);

// @route   GET /games/me
// @desc    Get all games by user
// @access  Private (Assuming only logged-in users can get their games)
router.get('/me', authenticateToken, GameController.getMyGames);

// @route   GET /games/:id
// @desc    Get game by ID
// @access  Public
router.get('/:id', GameController.getGameById);

// @route   PUT /games/:id
// @desc    Update game by ID
// @access  Private (Assuming only logged-in users can update games)
router.put('/:id', authenticateToken, GameController.updateGame);

// @route   PUT /games/like/:id
// @desc    Like game by ID
// @access  Private (Assuming only logged-in users can like games)
router.put('/like/:id', authenticateToken, GameController.likeGame);

// @route   PUT /games/unlike/:id
// @desc    Unlike game by ID
// @access  Private (Assuming only logged-in users can unlike games)
router.put('/unlike/:id', authenticateToken, GameController.unlikeGame);

// @route   PUT /games/comment/:id
// @desc    Comment on game by ID
// @access  Private (Assuming only logged-in users can comment on games)
router.put('/comment/:id', authenticateToken, GameController.commentGame);

// @route   DELETE /games/:id
// @desc    Delete game by ID
// @access  Private (Assuming only logged-in users can delete games)
router.delete('/:id', authenticateToken, GameController.deleteGame);

// @route   POST /games/buy
// @desc    Buy games
// @access  Private (Assuming only logged-in users can buy games)
router.post('/buy', authenticateToken, GameController.buyGames);

// @route   GET /games/buy
// @desc    Get bought games
// @access  Private (Assuming only logged-in users can get bought games)
router.get('/me/buy', authenticateToken, GameController.getBoughtGames);

// @route   POST /games/play
// @desc    Play game
// @access  Private (Assuming only logged-in users can play games)
router.post('/play', authenticateToken, GameController.playGame);

// @route   GET /games/me/play
// @desc    Get played games
// @access  Private (Assuming only logged-in users can get played games)
router.get('/me/play', authenticateToken, GameController.getPlayedGames);


module.exports = router;
