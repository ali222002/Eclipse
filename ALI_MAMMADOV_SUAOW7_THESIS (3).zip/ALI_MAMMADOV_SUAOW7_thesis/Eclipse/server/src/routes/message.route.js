const express = require('express');
const MessageController = require('../controllers/message.controller');
const { authenticateToken } = require('../middelwares/auth');

const router = express.Router();

router.post('/', authenticateToken, MessageController?.createMessage);
router.get('/:chatId', authenticateToken, MessageController?.getChatMessages);

module.exports = router;