// Routes
const express = require('express');
const { authenticateToken } = require('../middelwares/auth');
const router = express.Router();

router.use('/auth', require('./auth.route'));
router.use('/users',  authenticateToken, require('./user.route'));
router.use('/games', require('./game.route'));
router.use('/forums', require('./forum.route'));
router.use('/messages', require('./message.route'));
router.use('/chat', require('./chat.route'));

module.exports = router;