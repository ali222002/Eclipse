// models/Game.model.js
const mongoose = require('mongoose');

const gameSchema = new mongoose.Schema({
  name: { type: String, required: true, default: ' '},
  thumbnail: { type: String, required: true },
  description: { type: String, required: true },
  price: { type: Number, required: true },
  pictures: [{ type: String, required: true }],
  downloadLink: { type: String },
  type: { type: String, required: true },
  likes: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Users' }],
  dislikes: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Users' }],
  bought: { type: Number, default: 0 },
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'Users', required: true },
  comments: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Comment' }],
  createdAt: { type: Date, default: Date.now }
});

const Game = mongoose.model('Game', gameSchema);

module.exports = Game;
