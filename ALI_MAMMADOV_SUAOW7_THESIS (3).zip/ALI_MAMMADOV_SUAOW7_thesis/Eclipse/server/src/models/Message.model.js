const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const messageSchema = new Schema({
  senderId: {
    type: mongoose.Schema.Types.ObjectId,
    required: true,
  },
  receiverId: {
    type: mongoose.Schema.Types.ObjectId,
    required: true,
  },
  message: {
    type: String,
    required: true,
    validate: {
      validator: function(v) {
        return v.length > 0 && v.length <= 255;
      },
      message: 'Message length should be between 1 and 255 characters.'
    },
  },
  chatId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Chat',
    required: true,
  },
  timestamp: {
    type: Date,
    default: Date.now,
  },
  isRead: {
    type: Boolean,
    default: false,
  },
  link: {
    type: String,
    default: null,
  },
}, {
  tableName: 'messages',
  timestamps: true,
});

// Message model
module.exports = mongoose.model('Message', messageSchema);
