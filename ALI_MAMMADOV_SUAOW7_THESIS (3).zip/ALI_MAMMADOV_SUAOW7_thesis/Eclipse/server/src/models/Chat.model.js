const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const chatSchema = new Schema({
    lastMessageRead: {
        type: Boolean,
        default: false,
    },
    lastMessageTime: {
        type: Date,
        default: Date.now,
    },
    userIds: {
        type: [Schema.Types.ObjectId],
        ref: 'Users',
        required: true,
    },
    lastMessage: {
        type: String,
        default: '',
    }
}, {
    tableName: 'chats',
    timestamps: true,
});

// Chat model
module.exports = mongoose.model('Chat', chatSchema);
