// comment model
const mongoose = require('mongoose');

const commentSchema = new mongoose.Schema({
    user: { type: mongoose.Schema.Types.ObjectId, ref: 'Users', required: true },
    game: { type: mongoose.Schema.Types.ObjectId, ref: 'Game'  },
    forum: { type: mongoose.Schema.Types.ObjectId, ref: 'Forum'},
    comment: { type: String, required: true },
    createdAt: { type: Date, default: Date.now }
});

const Comment = mongoose.model('Comment', commentSchema);

module.exports = Comment;