const jwt = require('jsonwebtoken');
const { APIError } = require('../utils/ApiError');
const keys = require('../config/keys');
// const bcrypt = require('bcrypt')

function authenticateToken(req, res, next) {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];

    if (!token) {
        throw new APIError(401, 'Unauthorized');
    }
    jwt.verify(token, keys.secretOrKey, (err, user) => {
        if (err) {
            throw new APIError(403, 'Invalid token');
        }
        req.user = user;
        next();
    });
}

function getToken(req, res, next) {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];

    if (!token) {
        req.user = null;
        return next();
    }
    jwt.verify(token, keys.secretOrKey, (err, user) => {
        if (err) {
            throw new APIError(403, 'Invalid token');
        }
        req.user = user;
        next();
    });
}
// function generateToken(user) {
//     return jwt.sign(user, secretKey, { expiresIn: '20d' });
// }

// function generateVerificationToken(user) {
//     var salt = bcrypt.genSaltSync(10);
//     var hash = bcrypt.hashSync(user.email, salt);

//     return hash;
// }

// function isAdmin(req, _, next) {
//     if (!req?.user) {
//         throw new APIError(401, 'Unauthorized');
//     }
    
//     if (req.user?.role !== USER_TYPE.ADMIN && false) {
//         throw new APIError(403, 'Unauthorized');
//     }
//     next();
// }
module.exports = {
    authenticateToken,
    getToken,
    // generateToken,
    // generateVerificationToken,
    // isAdmin
};