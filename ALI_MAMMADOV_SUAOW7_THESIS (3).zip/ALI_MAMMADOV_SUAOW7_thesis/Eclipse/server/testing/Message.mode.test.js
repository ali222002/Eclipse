const mongoose = require('mongoose');
const { MongoMemoryServer } = require('mongodb-memory-server');
const Message = require('../src/models/Message.model');

describe('Message Model Test', () => {
    let mongoServer;
    const opts = { useNewUrlParser: true, useUnifiedTopology: true };

    beforeAll(async () => {
        mongoServer = await MongoMemoryServer.create();
        const mongoUri = mongoServer.getUri();
        await mongoose.connect(mongoUri, opts);
    });

    afterAll(async () => {
        await mongoose.disconnect();
        await mongoServer.stop();
    });

    afterEach(async () => {
        await Message.deleteMany({});
    });

    it('should create and save a message successfully', async () => {
        const validMessage = new Message({
            senderId: new mongoose.Types.ObjectId(),
            receiverId: new mongoose.Types.ObjectId(),
            message: 'Hello, this is a test message.',
            chatId: new mongoose.Types.ObjectId()
        });
        const savedMessage = await validMessage.save();

        expect(savedMessage._id).toBeDefined();
        expect(savedMessage.senderId).toBeDefined();
        expect(savedMessage.receiverId).toBeDefined();
        expect(savedMessage.message).toBe('Hello, this is a test message.');
        expect(savedMessage.chatId).toBeDefined();
        expect(savedMessage.timestamp).toBeDefined();
        expect(savedMessage.isRead).toBe(false);
        expect(savedMessage.link).toBeNull();
    });

    it('should require senderId, receiverId, message, and chatId fields', async () => {
        let err;

        const messageWithoutSenderId = new Message({
            receiverId: new mongoose.Types.ObjectId(),
            message: 'Hello, this is a test message.',
            chatId: new mongoose.Types.ObjectId()
        });

        try {
            await messageWithoutSenderId.save();
        } catch (error) {
            err = error;
        }

        expect(err).toBeInstanceOf(mongoose.Error.ValidationError);
        expect(err.errors.senderId).toBeDefined();

        const messageWithoutReceiverId = new Message({
            senderId: new mongoose.Types.ObjectId(),
            message: 'Hello, this is a test message.',
            chatId: new mongoose.Types.ObjectId()
        });

        try {
            await messageWithoutReceiverId.save();
        } catch (error) {
            err = error;
        }

        expect(err).toBeInstanceOf(mongoose.Error.ValidationError);
        expect(err.errors.receiverId).toBeDefined();

        const messageWithoutText = new Message({
            senderId: new mongoose.Types.ObjectId(),
            receiverId: new mongoose.Types.ObjectId(),
            chatId: new mongoose.Types.ObjectId()
        });

        try {
            await messageWithoutText.save();
        } catch (error) {
            err = error;
        }

        expect(err).toBeInstanceOf(mongoose.Error.ValidationError);
        expect(err.errors.message).toBeDefined();

        const messageWithoutChatId = new Message({
            senderId: new mongoose.Types.ObjectId(),
            receiverId: new mongoose.Types.ObjectId(),
            message: 'Hello, this is a test message.'
        });

        try {
            await messageWithoutChatId.save();
        } catch (error) {
            err = error;
        }

        expect(err).toBeInstanceOf(mongoose.Error.ValidationError);
        expect(err.errors.chatId).toBeDefined();
    });

    it('should validate message length', async () => {
        let err;

        const messageWithTooShortText = new Message({
            senderId: new mongoose.Types.ObjectId(),
            receiverId: new mongoose.Types.ObjectId(),
            message: '',
            chatId: new mongoose.Types.ObjectId()
        });

        try {
            await messageWithTooShortText.save();
        } catch (error) {
            err = error;
        }

        expect(err).toBeInstanceOf(mongoose.Error.ValidationError);
        expect(err.errors.message).toBeDefined();

        const messageWithTooLongText = new Message({
            senderId: new mongoose.Types.ObjectId(),
            receiverId: new mongoose.Types.ObjectId(),
            message: 'a'.repeat(256),
            chatId: new mongoose.Types.ObjectId()
        });

        try {
            await messageWithTooLongText.save();
        } catch (error) {
            err = error;
        }

        expect(err).toBeInstanceOf(mongoose.Error.ValidationError);
        expect(err.errors.message).toBeDefined();
    });

    it('should set default values for timestamp and isRead', async () => {
        const validMessage = new Message({
            senderId: new mongoose.Types.ObjectId(),
            receiverId: new mongoose.Types.ObjectId(),
            message: 'Hello, this is a test message.',
            chatId: new mongoose.Types.ObjectId()
        });
        const savedMessage = await validMessage.save();

        expect(savedMessage.timestamp).toBeDefined();
        expect(savedMessage.isRead).toBe(false);
    });

    it('should allow setting a link', async () => {
        const validMessage = new Message({
            senderId: new mongoose.Types.ObjectId(),
            receiverId: new mongoose.Types.ObjectId(),
            message: 'Hello, this is a test message.',
            chatId: new mongoose.Types.ObjectId(),
            link: 'http://example.com'
        });
        const savedMessage = await validMessage.save();

        expect(savedMessage.link).toBe('http://example.com');
    });
});
