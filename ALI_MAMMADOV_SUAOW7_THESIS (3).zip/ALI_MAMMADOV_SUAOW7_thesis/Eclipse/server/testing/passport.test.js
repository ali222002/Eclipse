const passport = require('passport');
const JwtStrategy = require('passport-jwt').Strategy;
const ExtractJwt = require('passport-jwt').ExtractJwt;
const User = require('../src/models/User.model'); 
const keys = require('../src/config/keys'); 
const initializePassport = require('../src/config/passport'); 

jest.mock('passport');
jest.mock('passport-jwt', () => ({
  Strategy: jest.fn(),
  ExtractJwt: {
    fromAuthHeaderAsBearerToken: jest.fn(),
  },
}));
jest.mock('../src/models/User.model'); 

describe('Passport Configuration', () => {
  beforeEach(() => {
    passport.use.mockClear();
    ExtractJwt.fromAuthHeaderAsBearerToken.mockReturnValue('mockedToken');
  });

  it('should configure passport with JwtStrategy', () => {
    const mockPassport = { use: jest.fn() };
    initializePassport(mockPassport);

    expect(mockPassport.use).toHaveBeenCalled();
  });

  it('should call done with user if user is found', async () => {
    const user = { id: '123', name: 'Test User' };
    User.findById.mockResolvedValue(user);

    const strategy = JwtStrategy.mock.calls[0][1];
    const done = jest.fn();

    await strategy({ id: '123' }, done);

    expect(User.findById).toHaveBeenCalledWith('123');
    expect(done).toHaveBeenCalledWith(null, user);
  });

  it('should call done with false if user is not found', async () => {
    User.findById.mockResolvedValue(null);

    const strategy = JwtStrategy.mock.calls[0][1];
    const done = jest.fn();

    await strategy({ id: '123' }, done);

    expect(User.findById).toHaveBeenCalledWith('123');
    expect(done).toHaveBeenCalledWith(null, false);
  });

  it('should call done with error if there is an error', async () => {
    const error = new Error('Test error');
    User.findById.mockRejectedValue(error);

    const strategy = JwtStrategy.mock.calls[0][1];
    const done = jest.fn();

    await strategy({ id: '123' }, done);

    expect(User.findById).toHaveBeenCalledWith('123');
  });
});
