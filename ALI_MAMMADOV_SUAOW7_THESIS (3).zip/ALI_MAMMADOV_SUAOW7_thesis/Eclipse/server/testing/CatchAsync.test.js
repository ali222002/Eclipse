const asyncHandler = require('../src/utils/CatchAsync');

describe('asyncHandler', () => {
    let req;
    let res;
    let next;

    beforeEach(() => {
        req = {};
        res = {};
        next = jest.fn();
    });

    it('should call the provided function with req, res, and next', async () => {
        const mockFunction = jest.fn().mockResolvedValue('some result');
        const wrappedFunction = asyncHandler(mockFunction);

        await wrappedFunction(req, res, next);

        expect(mockFunction).toHaveBeenCalledWith(req, res, next);
    });

    it('should call next with error if the provided function throws an error', async () => {
        const error = new Error('Test error');
        const mockFunction = jest.fn().mockRejectedValue(error);
        const wrappedFunction = asyncHandler(mockFunction);

        await wrappedFunction(req, res, next);

        expect(next).toHaveBeenCalledWith(error);
    });
});
