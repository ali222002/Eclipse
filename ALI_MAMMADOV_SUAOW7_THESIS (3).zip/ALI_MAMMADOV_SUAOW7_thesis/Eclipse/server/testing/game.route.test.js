const request = require('supertest');
const express = require('express');
const gameRouter = require('../src/routes/game.route');
const GameController = require('../src/controllers/game.controller');
const { authenticateToken } = require('../src/middelwares/auth'); 
const upload = require('../src/config/multer'); 

jest.mock('../src/controllers/game.controller');
jest.mock('../src/middelwares/auth');
jest.mock('../src/config/multer', () => {
  return {
    array: jest.fn().mockImplementation(() => (req, res, next) => next()),
  };
});

const app = express();
app.use(express.json());
app.use('/api/games', gameRouter);

describe('Game Routes', () => {
    beforeEach(() => {
        authenticateToken.mockImplementation((req, res, next) => next());
    });

    afterEach(() => {
        jest.clearAllMocks();
    });

    describe('POST /api/games', () => {
        it('should call createGame', async () => {
            GameController.createGame.mockImplementation((req, res) => res.status(201).send({ game: {} }));

            const response = await request(app)
                .post('/api/games')
                .send({ thumbnail: 'http://example.com/thumbnail.jpg', description: 'This is a test game', price: 49.99, pictures: ['http://example.com/pic1.jpg', 'http://example.com/pic2.jpg'], type: 'Action' });

            expect(authenticateToken).toHaveBeenCalled();
            expect(upload.array).toHaveBeenCalledWith("pictures", 6);
            expect(GameController.createGame).toHaveBeenCalled();
            expect(response.status).toBe(201);
            expect(response.body.game).toEqual({});
        });
    });

    describe('GET /api/games', () => {
        it('should call getGames', async () => {
            GameController.getGames.mockImplementation((req, res) => res.status(200).send({ games: [] }));

            const response = await request(app).get('/api/games');

            expect(GameController.getGames).toHaveBeenCalled();
            expect(response.status).toBe(200);
            expect(response.body.games).toEqual([]);
        });
    });

    describe('GET /api/games/me', () => {
        it('should call getMyGames', async () => {
            GameController.getMyGames.mockImplementation((req, res) => res.status(200).send({ games: [] }));

            const response = await request(app).get('/api/games/me');

            expect(authenticateToken).toHaveBeenCalled();
            expect(GameController.getMyGames).toHaveBeenCalled();
            expect(response.status).toBe(200);
            expect(response.body.games).toEqual([]);
        });
    });

    describe('GET /api/games/:id', () => {
        it('should call getGameById', async () => {
            GameController.getGameById.mockImplementation((req, res) => res.status(200).send({ game: {} }));

            const response = await request(app).get('/api/games/123');

            expect(GameController.getGameById).toHaveBeenCalled();
            expect(response.status).toBe(200);
            expect(response.body.game).toEqual({});
        });
    });

    describe('PUT /api/games/:id', () => {
        it('should call updateGame', async () => {
            GameController.updateGame.mockImplementation((req, res) => res.status(200).send({ game: {} }));

            const response = await request(app)
                .put('/api/games/123')
                .send({ description: 'Updated description' });

            expect(authenticateToken).toHaveBeenCalled();
            expect(GameController.updateGame).toHaveBeenCalled();
            expect(response.status).toBe(200);
            expect(response.body.game).toEqual({});
        });
    });

    describe('PUT /api/games/like/:id', () => {
        it('should call likeGame', async () => {
            GameController.likeGame.mockImplementation((req, res) => res.status(200).send({}));

            const response = await request(app).put('/api/games/like/123');

            expect(authenticateToken).toHaveBeenCalled();
            expect(GameController.likeGame).toHaveBeenCalled();
            expect(response.status).toBe(200);
        });
    });

    describe('PUT /api/games/unlike/:id', () => {
        it('should call unlikeGame', async () => {
            GameController.unlikeGame.mockImplementation((req, res) => res.status(200).send({}));

            const response = await request(app).put('/api/games/unlike/123');

            expect(authenticateToken).toHaveBeenCalled();
            expect(GameController.unlikeGame).toHaveBeenCalled();
            expect(response.status).toBe(200);
        });
    });

    describe('PUT /api/games/comment/:id', () => {
        it('should call commentGame', async () => {
            GameController.commentGame.mockImplementation((req, res) => res.status(201).send({ comment: {} }));

            const response = await request(app)
                .put('/api/games/comment/123')
                .send({ comment: 'This is a test comment' });

            expect(authenticateToken).toHaveBeenCalled();
            expect(GameController.commentGame).toHaveBeenCalled();
            expect(response.status).toBe(201);
            expect(response.body.comment).toEqual({});
        });
    });

    describe('DELETE /api/games/:id', () => {
        it('should call deleteGame', async () => {
            GameController.deleteGame.mockImplementation((req, res) => res.status(200).send({}));

            const response = await request(app).delete('/api/games/123');

            expect(authenticateToken).toHaveBeenCalled();
            expect(GameController.deleteGame).toHaveBeenCalled();
            expect(response.status).toBe(200);
        });
    });

    describe('POST /api/games/buy', () => {
        it('should call buyGames', async () => {
            GameController.buyGames.mockImplementation((req, res) => res.status(200).send({}));

            const response = await request(app).post('/api/games/buy');

            expect(authenticateToken).toHaveBeenCalled();
            expect(GameController.buyGames).toHaveBeenCalled();
            expect(response.status).toBe(200);
        });
    });

    describe('GET /api/games/me/buy', () => {
        it('should call getBoughtGames', async () => {
            GameController.getBoughtGames.mockImplementation((req, res) => res.status(200).send({ games: [] }));

            const response = await request(app).get('/api/games/me/buy');

            expect(authenticateToken).toHaveBeenCalled();
            expect(GameController.getBoughtGames).toHaveBeenCalled();
            expect(response.status).toBe(200);
            expect(response.body.games).toEqual([]);
        });
    });
});
