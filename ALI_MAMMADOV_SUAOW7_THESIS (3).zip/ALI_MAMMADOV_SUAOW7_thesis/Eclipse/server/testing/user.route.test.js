const request = require('supertest');
const express = require('express');
const upload = require('../src/config/multer'); 
const UserController = require('../src/controllers/user.controller'); 
const userRouter = require('../src/routes/user.route'); 

jest.mock('../src/controllers/user.controller');
jest.mock('../src/config/multer', () => {
  return {
    single: jest.fn(() => (req, res, next) => next())
  };
});

const app = express();
app.use(express.json());
app.use('/api/users', userRouter);

describe('User Routes', () => {
  afterEach(() => {
    jest.clearAllMocks();
  });

  it('should update profile picture', async () => {
    UserController.updateProfilePic.mockImplementation((req, res) => res.status(200).send({ message: 'Profile picture updated' }));

    const response = await request(app)
      .put('/api/users/profilePic')
      .attach('file', Buffer.from('file content'), 'test-image.jpg');

    expect(upload.single).toHaveBeenCalledWith('file');
    expect(UserController.updateProfilePic).toHaveBeenCalled();
    expect(response.status).toBe(200);
    expect(response.body.message).toBe('Profile picture updated');
  });

  it('should update bio', async () => {
    UserController.updateBio.mockImplementation((req, res) => res.status(200).send({ message: 'Bio updated' }));

    const response = await request(app)
      .put('/api/users/bio')
      .send({ bio: 'New bio' });

    expect(UserController.updateBio).toHaveBeenCalled();
    expect(response.status).toBe(200);
    expect(response.body.message).toBe('Bio updated');
  });

  it('should get user profile', async () => {
    UserController.getProfile.mockImplementation((req, res) => res.status(200).send({ profile: 'User profile' }));

    const response = await request(app).get('/api/users/profile');

    expect(UserController.getProfile).toHaveBeenCalled();
    expect(response.status).toBe(200);
    expect(response.body.profile).toBe('User profile');
  });

  it('should update user profile', async () => {
    UserController.updateProfile.mockImplementation((req, res) => res.status(200).send({ message: 'Profile updated' }));

    const response = await request(app)
      .put('/api/users/profile')
      .send({ username: 'newUsername' });

    expect(UserController.updateProfile).toHaveBeenCalled();
    expect(response.status).toBe(200);
    expect(response.body.message).toBe('Profile updated');
  });

  it('should get user friends', async () => {
    UserController.getFriends.mockImplementation((req, res) => res.status(200).send({ friends: ['friend1', 'friend2'] }));

    const response = await request(app).get('/api/users/me/friends');

    expect(UserController.getFriends).toHaveBeenCalled();
    expect(response.status).toBe(200);
    expect(response.body.friends).toEqual(['friend1', 'friend2']);
  });

  it('should get friend requests', async () => {
    UserController.getFriendRequests.mockImplementation((req, res) => res.status(200).send({ requests: ['request1', 'request2'] }));

    const response = await request(app).get('/api/users/friends/requests');

    expect(UserController.getFriendRequests).toHaveBeenCalled();
    expect(response.status).toBe(200);
    expect(response.body.requests).toEqual(['request1', 'request2']);
  });

  it('should get friendship status', async () => {
    UserController.getFriendshipStatus.mockImplementation((req, res) => res.status(200).send({ status: 'friends' }));

    const response = await request(app).get('/api/users/friends/status');

    expect(UserController.getFriendshipStatus).toHaveBeenCalled();
    expect(response.status).toBe(200);
    expect(response.body.status).toBe('friends');
  });

  it('should send friend request', async () => {
    UserController.sendFriendRequest.mockImplementation((req, res) => res.status(200).send({ message: 'Friend request sent' }));

    const response = await request(app).put('/api/users/friends/request/123');

    expect(UserController.sendFriendRequest).toHaveBeenCalled();
    expect(response.status).toBe(200);
    expect(response.body.message).toBe('Friend request sent');
  });

  it('should accept friend request', async () => {
    UserController.acceptFriendRequest.mockImplementation((req, res) => res.status(200).send({ message: 'Friend request accepted' }));

    const response = await request(app).put('/api/users/friends/accept/123');

    expect(UserController.acceptFriendRequest).toHaveBeenCalled();
    expect(response.status).toBe(200);
    expect(response.body.message).toBe('Friend request accepted');
  });

  it('should reject friend request', async () => {
    UserController.rejectFriendRequest.mockImplementation((req, res) => res.status(200).send({ message: 'Friend request rejected' }));

    const response = await request(app).put('/api/users/friends/reject/123');

    expect(UserController.rejectFriendRequest).toHaveBeenCalled();
    expect(response.status).toBe(200);
    expect(response.body.message).toBe('Friend request rejected');
  });

  it('should update cart', async () => {
    UserController.updateCart.mockImplementation((req, res) => res.status(200).send({ message: 'Cart updated' }));

    const response = await request(app)
      .put('/api/users/cart')
      .send({ cart: ['game1', 'game2'] });

    expect(UserController.updateCart).toHaveBeenCalled();
    expect(response.status).toBe(200);
    expect(response.body.message).toBe('Cart updated');
  });

  it('should update wishlist', async () => {
    UserController.updateWishlist.mockImplementation((req, res) => res.status(200).send({ message: 'Wishlist updated' }));

    const response = await request(app)
      .put('/api/users/wishlist')
      .send({ wishlist: ['game1', 'game2'] });

    expect(UserController.updateWishlist).toHaveBeenCalled();
    expect(response.status).toBe(200);
    expect(response.body.message).toBe('Wishlist updated');
  });

  it('should get cart', async () => {
    UserController.getCart.mockImplementation((req, res) => res.status(200).send({ cart: ['game1', 'game2'] }));

    const response = await request(app).get('/api/users/cart');

    expect(UserController.getCart).toHaveBeenCalled();
    expect(response.status).toBe(200);
    expect(response.body.cart).toEqual(['game1', 'game2']);
  });

  it('should get wishlist', async () => {
    UserController.getWishlist.mockImplementation((req, res) => res.status(200).send({ wishlist: ['game1', 'game2'] }));

    const response = await request(app).get('/api/users/wishlist');

    expect(UserController.getWishlist).toHaveBeenCalled();
    expect(response.status).toBe(200);
    expect(response.body.wishlist).toEqual(['game1', 'game2']);
  });
});
