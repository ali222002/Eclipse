const mongoose = require('mongoose');
const { MongoMemoryServer } = require('mongodb-memory-server');
const Forum = require('../src/models/Forum.model');

describe('Forum Model Test', () => {
    let mongoServer;
    const opts = { useNewUrlParser: true, useUnifiedTopology: true };

    beforeAll(async () => {
        mongoServer = await MongoMemoryServer.create();
        const mongoUri = mongoServer.getUri();
        await mongoose.connect(mongoUri, opts);
    });

    afterAll(async () => {
        await mongoose.disconnect();
        await mongoServer.stop();
    });

    afterEach(async () => {
        await Forum.deleteMany({});
    });

    it('should create and save a forum successfully', async () => {
        const validForum = new Forum({
            title: 'Test Forum',
            description: 'This is a test forum',
            user: new mongoose.Types.ObjectId(),
            comments: [new mongoose.Types.ObjectId(), new mongoose.Types.ObjectId()]
        });
        const savedForum = await validForum.save();

        expect(savedForum._id).toBeDefined();
        expect(savedForum.title).toBe('Test Forum');
        expect(savedForum.description).toBe('This is a test forum');
        expect(savedForum.user).toBeDefined();
        expect(savedForum.comments.length).toBe(2);
        expect(savedForum.createdAt).toBeDefined();
    });

    it('should require title and description fields', async () => {
        let err;
        const forumWithoutTitle = new Forum({
            description: 'This is a test forum without title',
            user: new mongoose.Types.ObjectId()
        });

        try {
            await forumWithoutTitle.save();
        } catch (error) {
            err = error;
        }

        expect(err).toBeInstanceOf(mongoose.Error.ValidationError);
        expect(err.errors.title).toBeDefined();

        const forumWithoutDescription = new Forum({
            title: 'Test Forum',
            user: new mongoose.Types.ObjectId()
        });

        try {
            await forumWithoutDescription.save();
        } catch (error) {
            err = error;
        }

        expect(err).toBeInstanceOf(mongoose.Error.ValidationError);
        expect(err.errors.description).toBeDefined();
    });

    it('should set default createdAt value', async () => {
        const validForum = new Forum({
            title: 'Test Forum',
            description: 'This is a test forum',
            user: new mongoose.Types.ObjectId()
        });
        const savedForum = await validForum.save();

        expect(savedForum.createdAt).toBeDefined();
    });
});
