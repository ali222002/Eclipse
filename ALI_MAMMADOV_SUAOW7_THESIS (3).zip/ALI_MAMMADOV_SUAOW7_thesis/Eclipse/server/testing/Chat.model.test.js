const mongoose = require('mongoose');
const { MongoMemoryServer } = require('mongodb-memory-server');
const Chat = require('../src/models/Chat.model');

describe('Chat Model Test', () => {
    let mongoServer;
    const opts = { useNewUrlParser: true, useUnifiedTopology: true };

    beforeAll(async () => {
        mongoServer = await MongoMemoryServer.create();
        const mongoUri = mongoServer.getUri();
        await mongoose.connect(mongoUri, opts);
    });

    afterAll(async () => {
        await mongoose.disconnect();
        await mongoServer.stop();
    });

    afterEach(async () => {
        await Chat.deleteMany({});
    });

    it('should create and save a chat successfully', async () => {
        const validChat = new Chat({
            userIds: [new mongoose.Types.ObjectId(), new mongoose.Types.ObjectId()],
            lastMessage: 'Hello, this is the last message',
        });
        const savedChat = await validChat.save();

        expect(savedChat._id).toBeDefined();
        expect(savedChat.lastMessageRead).toBe(false);
        expect(savedChat.lastMessageTime).toBeDefined();
        expect(savedChat.userIds.length).toBe(2);
        expect(savedChat.lastMessage).toBe('Hello, this is the last message');
    });

    it('should set default values correctly', async () => {
        const validChat = new Chat({
            userIds: [new mongoose.Types.ObjectId(), new mongoose.Types.ObjectId()],
        });
        const savedChat = await validChat.save();

        expect(savedChat.lastMessageRead).toBe(false);
        expect(savedChat.lastMessageTime).toBeDefined();
        expect(savedChat.lastMessage).toBe('');
    });
});
