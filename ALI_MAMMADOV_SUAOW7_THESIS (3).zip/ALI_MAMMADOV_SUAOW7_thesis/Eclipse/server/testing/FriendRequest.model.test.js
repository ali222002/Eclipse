const mongoose = require('mongoose');
const { MongoMemoryServer } = require('mongodb-memory-server');
const FriendRequest = require('../src/models/FriendRequest.model');

describe('FriendRequest Model Test', () => {
    let mongoServer;
    const opts = { useNewUrlParser: true, useUnifiedTopology: true };

    beforeAll(async () => {
        mongoServer = await MongoMemoryServer.create();
        const mongoUri = mongoServer.getUri();
        await mongoose.connect(mongoUri, opts);
    });

    afterAll(async () => {
        await mongoose.disconnect();
        await mongoServer.stop();
    });

    afterEach(async () => {
        await FriendRequest.deleteMany({});
    });

    it('should create and save a friend request successfully', async () => {
        const validFriendRequest = new FriendRequest({
            sender: new mongoose.Types.ObjectId(),
            receiver: new mongoose.Types.ObjectId(),
            status: 'pending'
        });
        const savedFriendRequest = await validFriendRequest.save();

        expect(savedFriendRequest._id).toBeDefined();
        expect(savedFriendRequest.sender).toBeDefined();
        expect(savedFriendRequest.receiver).toBeDefined();
        expect(savedFriendRequest.status).toBe('pending');
        expect(savedFriendRequest.createdAt).toBeDefined();
    });

    it('should require sender and receiver fields', async () => {
        let err;
        const friendRequestWithoutSender = new FriendRequest({
            receiver: new mongoose.Types.ObjectId(),
            status: 'pending'
        });

        try {
            await friendRequestWithoutSender.save();
        } catch (error) {
            err = error;
        }

        expect(err).toBeInstanceOf(mongoose.Error.ValidationError);
        expect(err.errors.sender).toBeDefined();

        const friendRequestWithoutReceiver = new FriendRequest({
            sender: new mongoose.Types.ObjectId(),
            status: 'pending'
        });

        try {
            await friendRequestWithoutReceiver.save();
        } catch (error) {
            err = error;
        }

        expect(err).toBeInstanceOf(mongoose.Error.ValidationError);
        expect(err.errors.receiver).toBeDefined();
    });

    it('should set default createdAt and status values', async () => {
        const validFriendRequest = new FriendRequest({
            sender: new mongoose.Types.ObjectId(),
            receiver: new mongoose.Types.ObjectId()
        });
        const savedFriendRequest = await validFriendRequest.save();

        expect(savedFriendRequest.createdAt).toBeDefined();
        expect(savedFriendRequest.status).toBe('pending');
    });
});
