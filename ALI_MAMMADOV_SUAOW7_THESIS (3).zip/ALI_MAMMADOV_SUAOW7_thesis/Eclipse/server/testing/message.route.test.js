const request = require('supertest');
const express = require('express');
const messageRouter = require('../src/routes/message.route'); 
const MessageController = require('../src/controllers/message.controller'); 
const { authenticateToken } = require('../src/middelwares/auth');

jest.mock('../src/controllers/message.controller');
jest.mock('../src/middelwares/auth');

const app = express();
app.use(express.json());
app.use('/api/messages', messageRouter);

describe('Message Routes', () => {
    beforeEach(() => {
        authenticateToken.mockImplementation((req, res, next) => next());
    });

    afterEach(() => {
        jest.clearAllMocks();
    });

    describe('POST /api/messages', () => {
        it('should call createMessage', async () => {
            MessageController.createMessage.mockImplementation((req, res) => res.status(201).send({ message: 'Message created' }));

            const response = await request(app)
                .post('/api/messages')
                .send({ senderId: '601c3c8b9c1a1c23d8bba287', receiverId: '601c3c8b9c1a1c23d8bba288', message: 'Hello', chatId: '601c3c8b9c1a1c23d8bba289' });

            expect(authenticateToken).toHaveBeenCalled();
            expect(MessageController.createMessage).toHaveBeenCalled();
            expect(response.status).toBe(201);
            expect(response.body.message).toBe('Message created');
        });
    });

    describe('GET /api/messages/:chatId', () => {
        it('should call getChatMessages', async () => {
            MessageController.getChatMessages.mockImplementation((req, res) => res.status(200).send({ messages: [] }));

            const response = await request(app).get('/api/messages/601c3c8b9c1a1c23d8bba289');

            expect(authenticateToken).toHaveBeenCalled();
            expect(MessageController.getChatMessages).toHaveBeenCalled();
            expect(response.status).toBe(200);
            expect(response.body.messages).toEqual([]);
        });
    });
});
