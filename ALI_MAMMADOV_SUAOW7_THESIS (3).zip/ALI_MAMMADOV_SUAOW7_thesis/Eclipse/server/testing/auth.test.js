const jwt = require('jsonwebtoken');
const { APIError } = require('../src/utils/ApiError');
const keys = require('../src/config/keys');
const { authenticateToken } = require('../src/middelwares/auth');

jest.mock('jsonwebtoken');
jest.mock('../src/config/keys', () => ({
    secretOrKey: 'testSecret'
}));

describe('authenticateToken', () => {
    let req;
    let res;
    let next;

    beforeEach(() => {
        req = {
            headers: {}
        };
        res = {};
        next = jest.fn();
    });

    it('should throw APIError with 401 if no token is provided', () => {
        req.headers['authorization'] = undefined;

        try {
            authenticateToken(req, res, next);
        } catch (error) {
            expect(error).toBeInstanceOf(APIError);
            expect(error.status).toBe(401);
            expect(error.message).toBe('Unauthorized');
        }
    });

    it('should throw APIError with 403 if token is invalid', () => {
        req.headers['authorization'] = 'Bearer invalidToken';
        jwt.verify.mockImplementation((token, secret, callback) => {
            callback(new Error('Invalid token'), null);
        });

        try {
            authenticateToken(req, res, next);
        } catch (error) {
            expect(error).toBeInstanceOf(APIError);
            expect(error.status).toBe(403);
            expect(error.message).toBe('Invalid token');
        }
    });

    it('should call next and set req.user if token is valid', () => {
        const mockUser = { id: 1, name: 'Test User' };
        req.headers['authorization'] = 'Bearer validToken';
        jwt.verify.mockImplementation((token, secret, callback) => {
            callback(null, mockUser);
        });

        authenticateToken(req, res, next);

        expect(req.user).toEqual(mockUser);
        expect(next).toHaveBeenCalled();
    });
});
