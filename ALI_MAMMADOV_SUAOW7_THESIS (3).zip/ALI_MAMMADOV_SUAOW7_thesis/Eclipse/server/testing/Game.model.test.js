const mongoose = require('mongoose');
const { MongoMemoryServer } = require('mongodb-memory-server');
const Game = require('../src/models/Game.model'); 

describe('Game Model Test', () => {
    let mongoServer;
    const opts = { useNewUrlParser: true, useUnifiedTopology: true };

    beforeAll(async () => {
        mongoServer = await MongoMemoryServer.create();
        const mongoUri = mongoServer.getUri();
        await mongoose.connect(mongoUri, opts);
    });

    afterAll(async () => {
        await mongoose.disconnect();
        await mongoServer.stop();
    });

    afterEach(async () => {
        await Game.deleteMany({});
    });

    it('should create and save a game successfully', async () => {
        const validGame = new Game({
            thumbnail: 'http://example.com/thumbnail.jpg',
            description: 'This is a test game',
            price: 49.99,
            pictures: ['http://example.com/pic1.jpg', 'http://example.com/pic2.jpg'],
            type: 'Action',
            user: new mongoose.Types.ObjectId()
        });
        const savedGame = await validGame.save();

        expect(savedGame._id).toBeDefined();
        expect(savedGame.thumbnail).toBe('http://example.com/thumbnail.jpg');
        expect(savedGame.description).toBe('This is a test game');
        expect(savedGame.price).toBe(49.99);
        expect(savedGame.pictures.length).toBe(2);
        expect(savedGame.pictures).toEqual(['http://example.com/pic1.jpg', 'http://example.com/pic2.jpg']);
        expect(savedGame.type).toBe('Action');
        expect(savedGame.user).toBeDefined();
        expect(savedGame.createdAt).toBeDefined();
    });

    it('should require thumbnail, description, price, pictures, type, and user fields', async () => {
        let err;
        const gameWithoutThumbnail = new Game({
            description: 'This is a test game',
            price: 49.99,
            pictures: ['http://example.com/pic1.jpg', 'http://example.com/pic2.jpg'],
            type: 'Action',
            user: new mongoose.Types.ObjectId()
        });

        try {
            await gameWithoutThumbnail.save();
        } catch (error) {
            err = error;
        }

        expect(err).toBeInstanceOf(mongoose.Error.ValidationError);
        expect(err.errors.thumbnail).toBeDefined();

        const gameWithoutDescription = new Game({
            thumbnail: 'http://example.com/thumbnail.jpg',
            price: 49.99,
            pictures: ['http://example.com/pic1.jpg', 'http://example.com/pic2.jpg'],
            type: 'Action',
            user: new mongoose.Types.ObjectId()
        });

        try {
            await gameWithoutDescription.save();
        } catch (error) {
            err = error;
        }

        const gameWithoutPrice = new Game({
            thumbnail: 'http://example.com/thumbnail.jpg',
            description: 'This is a test game',
            pictures: ['http://example.com/pic1.jpg', 'http://example.com/pic2.jpg'],
            type: 'Action',
            user: new mongoose.Types.ObjectId()
        });

        try {
            await gameWithoutPrice.save();
        } catch (error) {
            err = error;
        }

        expect(err).toBeInstanceOf(mongoose.Error.ValidationError);
        expect(err.errors.price).toBeDefined();

        const gameWithoutPictures = new Game({
            thumbnail: 'http://example.com/thumbnail.jpg',
            description: 'This is a test game',
            price: 49.99,
            type: 'Action',
            user: new mongoose.Types.ObjectId()
        });

        try {
            await gameWithoutPictures.save();
        } catch (error) {
            err = error;
        }

        const gameWithoutType = new Game({
            thumbnail: 'http://example.com/thumbnail.jpg',
            description: 'This is a test game',
            price: 49.99,
            pictures: ['http://example.com/pic1.jpg', 'http://example.com/pic2.jpg'],
            user: new mongoose.Types.ObjectId()
        });

        try {
            await gameWithoutType.save();
        } catch (error) {
            err = error;
        }

        expect(err).toBeInstanceOf(mongoose.Error.ValidationError);
        expect(err.errors.type).toBeDefined();

        const gameWithoutUser = new Game({
            thumbnail: 'http://example.com/thumbnail.jpg',
            description: 'This is a test game',
            price: 49.99,
            pictures: ['http://example.com/pic1.jpg', 'http://example.com/pic2.jpg'],
            type: 'Action'
        });

        try {
            await gameWithoutUser.save();
        } catch (error) {
            err = error;
        }

        expect(err).toBeInstanceOf(mongoose.Error.ValidationError);
        expect(err.errors.user).toBeDefined();
    });

    it('should set default createdAt value', async () => {
        const validGame = new Game({
            thumbnail: 'http://example.com/thumbnail.jpg',
            description: 'This is a test game',
            price: 49.99,
            pictures: ['http://example.com/pic1.jpg', 'http://example.com/pic2.jpg'],
            type: 'Action',
            user: new mongoose.Types.ObjectId()
        });
        const savedGame = await validGame.save();

        expect(savedGame.createdAt).toBeDefined();
    });

    it('should set default bought value to 0', async () => {
        const validGame = new Game({
            thumbnail: 'http://example.com/thumbnail.jpg',
            description: 'This is a test game',
            price: 49.99,
            pictures: ['http://example.com/pic1.jpg', 'http://example.com/pic2.jpg'],
            type: 'Action',
            user: new mongoose.Types.ObjectId()
        });
        const savedGame = await validGame.save();

        expect(savedGame.bought).toBe(0);
    });
});
