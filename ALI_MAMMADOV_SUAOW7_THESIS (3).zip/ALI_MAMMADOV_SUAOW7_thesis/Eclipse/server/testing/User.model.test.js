const mongoose = require('mongoose');
const { MongoMemoryServer } = require('mongodb-memory-server');
const bcrypt = require('bcrypt');
const User = require('../src/models/User.model');

describe('User Model Test', () => {
    let mongoServer;
    const opts = { useNewUrlParser: true, useUnifiedTopology: true };

    beforeAll(async () => {
        mongoServer = await MongoMemoryServer.create();
        const mongoUri = mongoServer.getUri();
        await mongoose.connect(mongoUri, opts);
    });

    afterAll(async () => {
        await mongoose.disconnect();
        await mongoServer.stop();
    });

    afterEach(async () => {
        await User.deleteMany({});
    });

    it('should create and save a user successfully', async () => {
        const validUser = new User({
            username: 'testuser',
            email: 'testuser@example.com',
            password: 'password123'
        });
        const savedUser = await validUser.save();

        expect(savedUser._id).toBeDefined();
        expect(savedUser.username).toBe('testuser');
        expect(savedUser.email).toBe('testuser@example.com');
        expect(savedUser.password).not.toBe('password123'); 
        expect(savedUser.date).toBeDefined();
    });

    it('should hash the password before saving', async () => {
        const validUser = new User({
            username: 'testuser',
            email: 'testuser@example.com',
            password: 'password123'
        });

        await validUser.save();

        const isMatch = await bcrypt.compare('password123', validUser.password);
        expect(isMatch).toBe(true);
    });

    it('should not rehash the password if it is not modified', async () => {
        const validUser = new User({
            username: 'testuser',
            email: 'testuser@example.com',
            password: 'password123'
        });

        await validUser.save();
        const originalHashedPassword = validUser.password;

        validUser.email = 'newemail@example.com';
        await validUser.save();

        expect(validUser.password).toBe(originalHashedPassword);
    });

    it('should require unique email and username', async () => {
        const user1 = new User({
            username: 'testuser',
            email: 'testuser@example.com',
            password: 'password123'
        });

        await user1.save();

        const user2 = new User({
            username: 'testuser',
            email: 'testuser@example.com',
            password: 'password123'
        });

        let err;
        try {
            await user2.save();
        } catch (error) {
            err = error;
        }
    });
});
