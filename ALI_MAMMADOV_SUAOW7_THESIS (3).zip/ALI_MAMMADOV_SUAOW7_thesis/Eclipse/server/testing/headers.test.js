const request = require('supertest');
const express = require('express');
const { allowHeaders } = require('../src/utils/headers'); 

const app = express();
app.use(allowHeaders);

app.get('/test', (req, res) => {
    res.send('Test route');
});

describe('allowHeaders Middleware', () => {
    it('should set headers for allowed origins', async () => {
        const response = await request(app).get('/test').set('Origin', 'http://localhost:3000');

        expect(response.headers['access-control-allow-origin']).toBe('http://localhost:3000');
        expect(response.headers['access-control-allow-methods']).toBe('POST, PUT, GET, OPTIONS, DELETE');
        expect(response.headers['access-control-allow-headers']).toBe('Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With,observe');
        expect(response.headers['access-control-max-age']).toBe('3600');
        expect(response.headers['access-control-allow-credentials']).toBe('true');
        expect(response.headers['access-control-expose-headers']).toBe('Authorization, responseType, observe');
        expect(response.headers['x-powered-by']).toBe('nginx:202');
    });

    it('should handle OPTIONS request', async () => {
        const response = await request(app).options('/test').set('Origin', 'http://localhost:3000');

        expect(response.status).toBe(200);
        expect(response.headers['access-control-allow-origin']).toBe('http://localhost:3000');
        expect(response.headers['access-control-allow-methods']).toBe('POST, PUT, GET, OPTIONS, DELETE');
        expect(response.headers['access-control-allow-headers']).toBe('Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With,observe');
        expect(response.headers['access-control-max-age']).toBe('3600');
        expect(response.headers['access-control-allow-credentials']).toBe('true');
        expect(response.headers['access-control-expose-headers']).toBe('Authorization, responseType, observe');
        expect(response.headers['x-powered-by']).toBe('nginx:202');
    });

    it('should not set Access-Control-Allow-Origin header for disallowed origins', async () => {
        const response = await request(app).get('/test').set('Origin', 'http://notallowed.com');

        expect(response.headers['access-control-allow-origin']).toBeUndefined();
        expect(response.headers['access-control-allow-methods']).toBe('POST, PUT, GET, OPTIONS, DELETE');
        expect(response.headers['access-control-allow-headers']).toBe('Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With,observe');
        expect(response.headers['access-control-max-age']).toBe('3600');
        expect(response.headers['access-control-allow-credentials']).toBe('true');
        expect(response.headers['access-control-expose-headers']).toBe('Authorization, responseType, observe');
        expect(response.headers['x-powered-by']).toBe('nginx:202');
    });

    it('should call next for non-OPTIONS request', async () => {
        const nextFunction = jest.fn();
        const req = { method: 'GET', headers: {} };
        const res = { setHeader: jest.fn(), sendStatus: jest.fn() };

        allowHeaders(req, res, nextFunction);

        expect(nextFunction).toHaveBeenCalled();
    });
});
