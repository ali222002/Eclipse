const request = require('supertest');
const express = require('express');
const forumRouter = require('../src/routes/forum.route'); 
const ForumController = require('../src/controllers/forum.controller'); 
const { authenticateToken } = require('../src/middelwares/auth'); 

jest.mock('../src/controllers/forum.controller');
jest.mock('../src/middelwares/auth');

const app = express();
app.use(express.json());
app.use('/api/forums', forumRouter);

describe('Forum Routes', () => {
    beforeEach(() => {
        authenticateToken.mockImplementation((req, res, next) => next());
    });

    afterEach(() => {
        jest.clearAllMocks();
    });

    describe('GET /api/forums', () => {
        it('should call getForums', async () => {
            ForumController.getForums.mockImplementation((req, res) => res.status(200).send({ forums: [] }));

            const response = await request(app).get('/api/forums');

            expect(ForumController.getForums).toHaveBeenCalled();
            expect(response.status).toBe(200);
            expect(response.body.forums).toEqual([]);
        });
    });

    describe('POST /api/forums', () => {
        it('should call createForum', async () => {
            ForumController.createForum.mockImplementation((req, res) => res.status(201).send({ forum: {} }));

            const response = await request(app)
                .post('/api/forums')
                .send({ title: 'Test Forum', description: 'This is a test forum' });

            expect(authenticateToken).toHaveBeenCalled();
            expect(ForumController.createForum).toHaveBeenCalled();
            expect(response.status).toBe(201);
            expect(response.body.forum).toEqual({});
        });
    });

    describe('GET /api/forums/:id', () => {
        it('should call getForumById', async () => {
            ForumController.getForumById.mockImplementation((req, res) => res.status(200).send({ forum: {} }));

            const response = await request(app).get('/api/forums/123');

            expect(ForumController.getForumById).toHaveBeenCalled();
            expect(response.status).toBe(200);
            expect(response.body.forum).toEqual({});
        });
    });

    describe('POST /api/forums/:id/comment', () => {
        it('should call addComment', async () => {
            ForumController.addComment.mockImplementation((req, res) => res.status(201).send({ comment: {} }));

            const response = await request(app)
                .post('/api/forums/123/comment')
                .send({ comment: 'This is a test comment' });

            expect(authenticateToken).toHaveBeenCalled();
            expect(ForumController.addComment).toHaveBeenCalled();
            expect(response.status).toBe(201);
            expect(response.body.comment).toEqual({});
        });
    });
});
