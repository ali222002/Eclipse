const { APIError, ValidationError } = require('../src/utils/ApiError');

describe('APIError', () => {
    it('should create an instance of APIError with default status and message', () => {
        const error = new APIError();
        expect(error).toBeInstanceOf(Error);
        expect(error).toBeInstanceOf(APIError);
        expect(error.status).toBe(500);
        expect(error.message).toBe("Internal Server Error");
    });

    it('should create an instance of APIError with provided status and message', () => {
        const status = 404;
        const message = "Not Found";
        const error = new APIError(status, message);
        expect(error.status).toBe(status);
        expect(error.message).toBe(message);
    });
});

describe('ValidationError', () => {
    it('should create an instance of ValidationError with default status and message', () => {
        const error = new ValidationError();
        expect(error).toBeInstanceOf(Error);
        expect(error).toBeInstanceOf(APIError);
        expect(error).toBeInstanceOf(ValidationError);
        expect(error.status).toBe(400);
        expect(error.message).toBe("Validation Error");
    });

    it('should create an instance of ValidationError with provided message', () => {
        const message = "Custom Validation Error";
        const error = new ValidationError(message);
        expect(error.status).toBe(400);
        expect(error.message).toBe(message);
    });
});
