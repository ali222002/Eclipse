const request = require('supertest');
const express = require('express');
const router = require('../src/routes/chat.route'); 
const { authenticateToken } = require('../src/middelwares/auth'); 
const ChatController = require('../src/controllers/chat.controller'); 

jest.mock('../src/middelwares/auth');
jest.mock('../src/controllers/chat.controller');

const app = express();
app.use(express.json());
app.use('/api/chats', router);

describe('Chat Routes', () => {
    beforeEach(() => {
        authenticateToken.mockImplementation((req, res, next) => next());
    });

    afterEach(() => {
        jest.clearAllMocks();
    });

    describe('POST /api/chats', () => {
        it('should call accessChat', async () => {
            ChatController.accessChat.mockImplementation((req, res) => res.status(201).send({ success: true }));

            const response = await request(app).post('/api/chats').send({ userIds: ['123', '456'] });

            expect(authenticateToken).toHaveBeenCalled();
            expect(ChatController.accessChat).toHaveBeenCalled();
            expect(response.status).toBe(201);
            expect(response.body.success).toBe(true);
        });
    });

    describe('GET /api/chats', () => {
        it('should call getChats', async () => {
            ChatController.getChats.mockImplementation((req, res) => res.status(200).send({ chats: [] }));

            const response = await request(app).get('/api/chats');

            expect(authenticateToken).toHaveBeenCalled();
            expect(ChatController.getChats).toHaveBeenCalled();
            expect(response.status).toBe(200);
            expect(response.body.chats).toEqual([]);
        });
    });

    describe('GET /api/chats/:id', () => {
        it('should call getChat', async () => {
            ChatController.getChat.mockImplementation((req, res) => res.status(200).send({ chat: {} }));

            const response = await request(app).get('/api/chats/123');

            expect(authenticateToken).toHaveBeenCalled();
            expect(ChatController.getChat).toHaveBeenCalled();
            expect(response.status).toBe(200);
            expect(response.body.chat).toEqual({});
        });
    });
});
