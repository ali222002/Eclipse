const request = require('supertest');
const express = require('express');
const errorHandler = require('../src/middelwares/ErrorMiddelware');

const app = express();

// Middleware to simulate an error
app.get('/error', (req, res, next) => {
    const error = new Error('Test error');
    error.status = 400;
    next(error);
});

// Middleware to simulate an internal server error
app.get('/internal-error', (req, res, next) => {
    next(new Error());
});

// Error handling middleware
app.use(errorHandler);

describe('Error Handling Middleware', () => {
    it('should handle custom errors and respond with correct status and message', async () => {
        const response = await request(app).get('/error');

        expect(response.status).toBe(400);
        expect(response.body).toEqual({
            success: false,
            message: 'Test error',
            stack: expect.any(String),
        });
    });

    it('should handle internal server errors and respond with default message and status', async () => {
        const response = await request(app).get('/internal-error');

        expect(response.status).toBe(500);
        expect(response.body).toEqual({
            success: false,
            message: 'Internal server error',
            stack: expect.any(String),
        });
    });
});
