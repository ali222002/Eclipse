const request = require('supertest');
const express = require('express');
const AuthController = require('../src/controllers/auth.controller');
const authRouter = require('../src/routes/auth.route');

jest.mock('../src/controllers/auth.controller', () => ({
    register: jest.fn((req, res) => res.status(201).json({ message: 'User registered' })),
    login: jest.fn((req, res) => res.status(200).json({ message: 'User logged in' })),
    googleLogin: jest.fn((req, res) => res.status(200).json({ message: 'Google login successful' })),
    forgotPassword: jest.fn((req, res) => res.status(200).json({ message: 'Password reset link sent' }))
}));

const app = express();
app.use(express.json());
app.use('/auth', authRouter);

describe('Auth Routes', () => {
    it('POST /auth/register should call AuthController.register', async () => {
        const response = await request(app).post('/auth/register').send({ username: 'testuser', email: 'test@example.com', password: 'password' });
        expect(response.status).toBe(201);
        expect(response.body.message).toBe('User registered');
        expect(AuthController.register).toHaveBeenCalled();
    });

    it('POST /auth/login should call AuthController.login', async () => {
        const response = await request(app).post('/auth/login').send({ email: 'test@example.com', password: 'password' });
        expect(response.status).toBe(200);
        expect(response.body.message).toBe('User logged in');
        expect(AuthController.login).toHaveBeenCalled();
    });

    it('POST /auth/google-login should call AuthController.googleLogin', async () => {
        const response = await request(app).post('/auth/google-login').send({ firstName: 'Test', lastName: 'User', email: 'test@example.com', googleId: 'googleId', imageUrl: 'imageUrl' });
        expect(response.status).toBe(200);
        expect(response.body.message).toBe('Google login successful');
        expect(AuthController.googleLogin).toHaveBeenCalled();
    });

    it('POST /auth/forgot-password should call AuthController.forgotPassword', async () => {
        const response = await request(app).post('/auth/forgot-password').send({ email: 'test@example.com' });
        expect(response.status).toBe(200);
        expect(response.body.message).toBe('Password reset link sent');
        expect(AuthController.forgotPassword).toHaveBeenCalled();
    });
});
