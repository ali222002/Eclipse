const keys = require('../src/config/keys');

describe('Configuration Keys', () => {
    it('should export secretOrKey', () => {
        expect(keys.secretOrKey).toBeDefined();
        expect(keys.secretOrKey).toBe('your_secret_key');
    });
});
