const mongoose = require('mongoose');
const { MongoMemoryServer } = require('mongodb-memory-server');
const Comment = require('../src/models/Comment.model');

describe('Comment Model Test', () => {
    let mongoServer;
    const opts = { useNewUrlParser: true, useUnifiedTopology: true };

    beforeAll(async () => {
        mongoServer = await MongoMemoryServer.create();
        const mongoUri = mongoServer.getUri();
        await mongoose.connect(mongoUri, opts);
    });

    afterAll(async () => {
        await mongoose.disconnect();
        await mongoServer.stop();
    });

    afterEach(async () => {
        await Comment.deleteMany({});
    });

    it('should create and save a comment successfully', async () => {
        const validComment = new Comment({
            user: new mongoose.Types.ObjectId(),
            game: new mongoose.Types.ObjectId(),
            forum: new mongoose.Types.ObjectId(),
            comment: 'This is a test comment'
        });
        const savedComment = await validComment.save();

        expect(savedComment._id).toBeDefined();
        expect(savedComment.user).toBeDefined();
        expect(savedComment.game).toBeDefined();
        expect(savedComment.forum).toBeDefined();
        expect(savedComment.comment).toBe('This is a test comment');
        expect(savedComment.createdAt).toBeDefined();
    });

    it('should require user and comment fields', async () => {
        const commentWithoutUser = new Comment({ comment: 'This is a test comment' });
        let err;
        try {
            await commentWithoutUser.save();
        } catch (error) {
            err = error;
        }
        expect(err).toBeInstanceOf(mongoose.Error.ValidationError);
        expect(err.errors.user).toBeDefined();

        const commentWithoutText = new Comment({ user: new mongoose.Types.ObjectId() });
        try {
            await commentWithoutText.save();
        } catch (error) {
            err = error;
        }
        expect(err).toBeInstanceOf(mongoose.Error.ValidationError);
        expect(err.errors.comment).toBeDefined();
    });

    it('should set default createdAt value', async () => {
        const validComment = new Comment({
            user: new mongoose.Types.ObjectId(),
            game: new mongoose.Types.ObjectId(),
            forum: new mongoose.Types.ObjectId(),
            comment: 'This is a test comment'
        });
        const savedComment = await validComment.save();

        expect(savedComment.createdAt).toBeDefined();
    });
});
