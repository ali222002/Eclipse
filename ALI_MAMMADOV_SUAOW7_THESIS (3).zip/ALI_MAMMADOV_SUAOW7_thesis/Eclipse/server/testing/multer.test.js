const request = require('supertest');
const express = require('express');
const path = require('path');
const multer = require('multer');
const upload = require('../src/config/multer');

const app = express();
app.post('/upload', upload.single('image'), (req, res) => {
  res.status(200).send({ file: req.file });
});

describe('Multer Configuration', () => {
  it('should upload a file successfully', async () => {
    const response = await request(app)
      .post('/upload')
      .attach('image', Buffer.from('file content'), 'test-image.png');

    expect(response.status).toBe(200);
    expect(response.body.file).toBeDefined();
    expect(response.body.file.filename).toMatch(/^\d{13}-\d+\.png$/);
    expect(response.body.file.size).toBe(12);
  });

  it('should respect file size limit', async () => {
    const response = await request(app)
      .post('/upload')
      .attach('image', Buffer.alloc(10000000), 'large-file.png'); 

  });
});
