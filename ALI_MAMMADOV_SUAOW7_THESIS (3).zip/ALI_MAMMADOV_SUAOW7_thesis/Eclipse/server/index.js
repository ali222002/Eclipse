const http = require('http');
const app = require('./src/app');
const SocketServer = require('./src/utils/socket');

const port = process.env.PORT || 8000;

const server = http.createServer(app);

server.listen(port, () => {
    console.log(`Server running on port ${port}`);
});

let socketServer = new SocketServer(server);
socketServer.setup();