"use client";
import { useEffect, useMemo, useState } from 'react';
import io from 'socket.io-client';
import { useDispatch, useSelector } from 'react-redux';
import { newMessageRecieved, setConnectedSocket, updateActiveUsers } from '../redux/slices/chatSlice'; 
import { SERVER_URL as SOCKET_URL } from '../utils/util';
import { SOCKET_EVENTS } from '../utils/socketEvents';
import { setUserToStore } from '../redux/slices/globalSlice';

function useSocketIOHandler() {
    const dispatch = useDispatch()
    const [socket, setSocket] = useState(null);
    const [loading, setLoading] = useState(true);

    const loggedInUser = useSelector(state => state?.global?.user) || JSON.parse(localStorage.getItem("user")); 
    const currentUser = useMemo(() => {
        // if (typeof window === "undefined") return null;
        // return JSON.parse(localStorage.getItem("user"));
        return loggedInUser;
    }, []);

    useEffect(() => {
        let socket = null;
        const initializeSocket = async () => {
            setLoading(false)
            if (currentUser) {
                dispatch(setUserToStore(currentUser))
                socket = io(SOCKET_URL);
                dispatch(setConnectedSocket(socket));
                setSocket(socket);
                socket?.emit(SOCKET_EVENTS.SOCKET_SETUP, currentUser);
                socket?.on(SOCKET_EVENTS.SOCKET_CONNECT, (activeUsers) => {
                    dispatch(updateActiveUsers(activeUsers))
                })
            }
        };

        initializeSocket();

        return () => {
            socket?.off(SOCKET_EVENTS.SOCKET_CONNECT);
            socket?.off(SOCKET_EVENTS.SOCKET_MESSAGE_RECIEVED);
            socket?.off(SOCKET_EVENTS.SOCKET_USER_ONLINE);
            socket?.off(SOCKET_EVENTS.SOCKET_USER_OFFLINE);
            
            socket?.disconnect();
        };

        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [currentUser]);

    useEffect(() => {
        if (socket) {
            socket?.on(SOCKET_EVENTS.SOCKET_USER_ONLINE, (connectedUsers) => {
                dispatch(updateActiveUsers(connectedUsers))
            })
            socket?.on(SOCKET_EVENTS.SOCKET_USER_OFFLINE, (activeUsers) => {
                dispatch(updateActiveUsers(activeUsers))
            })
            return () => {
                socket?.off(SOCKET_EVENTS.SOCKET_USER_ONLINE)
                socket?.off(SOCKET_EVENTS.SOCKET_USER_OFFLINE)
            }
        }
    })

    useEffect(() => {
        socket?.on(SOCKET_EVENTS.SOCKET_MESSAGE_RECIEVED, (message) => {
            dispatch(newMessageRecieved(message));
        });
        return () => {
            socket?.off(SOCKET_EVENTS.SOCKET_MESSAGE_RECIEVED);
        }
    });

    // useEffect(() => {
    //     socket?.on(SOCKET_EVENTS.SOCKET_NOTIFICATION, (notification) => {
    //         if (currentUser?.id === notification?.receiverId && !(router?.pathname?.includes('messages'))) {
    //             //alert("Notification: " + JSON.stringify(notification?.message))
    //             dispatch(addNotification(notification))
    //         }
    //     });
    //     return () => {
    //         socket?.off(SOCKET_EVENTS.SOCKET_NOTIFICATION);
    //     }
    // });
    return { socket, loading };
}

export default useSocketIOHandler;
