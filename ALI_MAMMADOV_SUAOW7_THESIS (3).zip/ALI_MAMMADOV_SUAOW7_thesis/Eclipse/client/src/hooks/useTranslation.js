// useTranslation.js
import { useEffect, useState } from 'react';
import { useSelector } from 'react-redux';
import { translations } from '../utils/translation';

const useTranslation = () => {
    const { language: selectedLanguage } = useSelector(state => state.global);
    const [language, setLanguage] = useState("en");

    useEffect(() => {
        setLanguage(selectedLanguage);
    }, [selectedLanguage]);

    const translate = (key) => {
        return translations[language][key] || key;
    };

    return {
        language,
        setLanguage,
        translate,
    };
};

export default useTranslation;
