
import { fetchBaseQuery } from '@reduxjs/toolkit/query/react';
import { commonApi } from './commonApi';
import { BASE_URL, requestConfig } from "../../utils/util";
export const forumApi = commonApi.injectEndpoints({
    baseQuery: fetchBaseQuery({
        baseUrl: BASE_URL,
        ...requestConfig, // Include the requestConfig in the baseQuery
    }),
    endpoints: (builder) => ({
        createForum: builder.mutation({
            query: (data) => ({
                url: `forums`,
                method: 'POST',
                body: data
            }),
            invalidatesTags: ['Forum'],
        }),

        addComment: builder.mutation({
            query: (data) => ({
                url: `forums/${data.forumId}/comment`,
                method: 'POST',
                body: data
            }),
            invalidatesTags: ['Forum'],
        }),

        getAllForums: builder.query({
            query: () => `forums`,
            providesTags: ['Forum'],
        }),

        getForum: builder.query({
            query: (id) => `forums/${id}`,
            providesTags: ['Forum'],
        }),
    }),
});

export const {
    useCreateForumMutation,
    useAddCommentMutation,
    useGetAllForumsQuery,
    useGetForumQuery
} = forumApi;