import { fetchBaseQuery } from '@reduxjs/toolkit/query/react';

import { commonApi } from './commonApi';
import { BASE_URL, requestConfig } from '../../utils/util';

// Create the RTK Query API endpoints
export const messageApi = commonApi.injectEndpoints({
  baseQuery: fetchBaseQuery({
    baseUrl: BASE_URL,
    ...requestConfig, // Include the requestConfig in the baseQuery
  }),
  endpoints: (builder) => ({
    postMessage: builder.mutation({
      query: (data) => ({
        url: '/messages',
        method: 'POST',
        body: data,
      }),
      //invalidatesTags: ['Messages', 'Chats'],
    }),

    fetchConversation: builder.query({
      query: (id) => `/chat/${id}`,
    }),

    getChatMessages: builder.query({
      query: ({ chatId, currentPage, limit, search }) => `/messages/${chatId}?page=${currentPage}&limit=${50}&search=${search}`,
      providesTags: ['Messages']
    }),

    setupChat: builder.mutation({
      query: (data) => ({
        url: '/chat',
        method: 'POST',
        body: data,
      }),
      invalidatesTags: ['Chats'],
    }),

    getChats: builder.query({
      query: ({ page = 1, limit, search }) => `/chat?page=${page}&limit=${50}&search=${search}`,
      providesTags: ['Chats']
    }),
  }),
});

// Export hooks for each endpoint
export const {
  usePostMessageMutation,
  useGetChatMessagesQuery,
  useSetupChatMutation,
  useGetChatsQuery,
  useFetchConversationQuery,
} = messageApi;
