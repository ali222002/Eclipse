
import { fetchBaseQuery } from '@reduxjs/toolkit/query/react';
import { commonApi } from "./commonApi";
import { BASE_URL, requestConfig } from "../../utils/util";

export const gameApi = commonApi.injectEndpoints({
    baseQuery: fetchBaseQuery({
        baseUrl: BASE_URL,
        ...requestConfig, // Include the requestConfig in the baseQuery
    }),
    endpoints: (builder) => ({
        createGame: builder.mutation({
            query: (data) => ({
                url: `games`,
                method: 'POST',
                body: data
            }),
            invalidatesTags: ['Game'],
        }),

        updateGame: builder.mutation({
            query: (id, data) => ({
                url: `games/${id}`,
                method: 'PUT',
                body: data
            }),
            invalidatesTags: ['Game'],
        }),

        deleteGame: builder.mutation({
            query: (id) => ({
                url: `games/${id}`,
                method: 'DELETE',
            }),
            invalidatesTags: ['Game'],
        }),

        getGames: builder.query({
            query: () => `games`,
            providesTags: ['Game'],
        }),

        getRecommendedGames: builder.query({
            query: () => `games/recommended`,
            providesTags: ['Game'],
        }),

        getMyGames: builder.query({
            query: () => `games/me`,
            providesTags: ['Game'],
        }),

        getGameDetail: builder.query({
            query: (id) => `games/${id}`,
            providesTags: ['Game'],
        }),

        commentGame: builder.mutation({
            query: (data) => ({
                url: `games/comment/${data?.game}`,
                method: 'PUT',
                body: data?.comment
            }),
            invalidatesTags: ['Game'],
        }),

        likeGame: builder.mutation({
            query: (id) => ({
                url: `games/like/${id}`,
                method: 'PUT',
            }),
            invalidatesTags: ['Game'],
        }),

        unlikeGame: builder.mutation({
            query: (id) => ({
                url: `games/unlike/${id}`,
                method: 'PUT',
            }),
            invalidatesTags: ['Game'],
        }),

        buyGames: builder.mutation({
            query: (data) => ({
                url: `games/buy`,
                method: 'POST',
                body: data
            }),
            invalidatesTags: ['Game'],
        }),

        boughtGames: builder.query({
            query: () => `games/me/buy`,
            providesTags: ['Game'],
        }),

        playGame: builder.mutation({
            query: (data) => ({
                url: `games/play`,
                method: 'POST',
                body: data
            }),
            invalidatesTags: ['Game'],
        }),

        getPlayedGames: builder.query({
            query: () => `games/me/play`,
            providesTags: ['Game'],
        }),
    }),
});

export const {
    useCreateGameMutation,
    useUpdateGameMutation,
    useDeleteGameMutation,
    useGetGamesQuery,
    useGetGameDetailQuery,
    useCommentGameMutation,
    useLikeGameMutation,
    useUnlikeGameMutation,
    useBuyGamesMutation,
    useBoughtGamesQuery,
    useGetMyGamesQuery,
    useGetRecommendedGamesQuery,
    usePlayGameMutation,
    useGetPlayedGamesQuery
} = gameApi;