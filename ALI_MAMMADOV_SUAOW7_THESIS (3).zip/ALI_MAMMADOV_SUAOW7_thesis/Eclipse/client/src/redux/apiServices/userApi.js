
import { fetchBaseQuery } from '@reduxjs/toolkit/query/react';
import { commonApi } from './commonApi';
import { BASE_URL, requestConfig } from "../../utils/util";

export const userApi = commonApi.injectEndpoints({
    baseQuery: fetchBaseQuery({
        baseUrl: BASE_URL,
        ...requestConfig, // Include the requestConfig in the baseQuery
    }),
    endpoints: (builder) => ({
        register: builder.mutation({
            query: (data) => ({
                url: `auth/register`,
                method: 'POST',
                body: data
            }),
            invalidatesTags: ['Users'],
        }),

        login: builder.mutation({
            query: (data) => ({
                url: `auth/login`,
                method: 'POST',
                body: data
            }),
            invalidatesTags: ['Users'],
        }),

        googleLogin: builder.mutation({
            query: (userData) => ({
                url: '/auth/google-login',
                method: 'POST',
                body: userData,
            }),
            invalidatesTags: ['Users'],
        }),



        updateProfilePicture: builder.mutation({
            query: (data) => ({
                url: `users/profilePic`,
                method: 'PUT',
                body: data,
                headers: {
                    'Content-Type': "multi-form/data"
                }
            }),
            invalidatesTags: ['Users'],
        }),

        updateBio: builder.mutation({
            query: (data) => ({
                url: `users/bio`,
                method: "PUT",
                body: data
            }),
            invalidatesTags: ['Users'],
        }),
        getProfile: builder.query({
            query: () => `users/profile`,
            providesTags: ['Users'],
        }),
        updateProfile: builder.mutation({
            query: (data) => ({
                url: `users/profile`,
                method: "PUT",
                body: data
            }),
            invalidatesTags: ['Users'],
        }),

        getFriends: builder.query({
            query: () => `users/me/friends`,
            providesTags: ['Friends'],
        }),

        getFriendshipStatus: builder.query({
            query: () => `users/friends/status`,
            providesTags: ['Friends'],
        }),

        getFriendRequests: builder.query({
            query: () => `users/friends/requests`,
            providesTags: ['Friends'],
        }),

        sendFriendRequest: builder.mutation({
            query: (id) => ({
                url: `users/friends/request/${id}`,
                method: "PUT",
            }),
            invalidatesTags: ['Friends'],
        }),

        unfriendUser: builder.mutation({
            query: (id) => ({
                url: `users/friends/unfriend/${id}`,
                method: "PUT",
            }),
            invalidatesTags: ['Friends'],
        }),

        acceptFriendRequest: builder.mutation({
            query: (id) => ({
                url: `users/friends/accept/${id}`,
                method: "PUT",
            }),
            invalidatesTags: ['Friends'],
        }),

        rejectFriendRequest: builder.mutation({
            query: (id) => ({
                url: `users/friends/reject/${id}`,
                method: "PUT",
            }),
            invalidatesTags: ['Friends'],
        }),

        updateCart: builder.mutation({
            query: (data) => ({
                url: `users/cart`,
                method: "PUT",
                body: data
            }),
            invalidatesTags: ['Users'],
        }),

        updatewishlist: builder.mutation({
            query: (data) => ({
                url: `users/wishlist`,
                method: "PUT",
                body: data
            }),
            invalidatesTags: ['Users'],
        }),

        getCart: builder.query({
            query: () => `users/cart`,
            providesTags: ['Users'],
        }),

        getWishlist: builder.query({
            query: () => `users/wishlist`,
            providesTags: ['Users'],
        }),

    }),
});

export const {
    useRegisterMutation,
    useLoginMutation,
    useGoogleLoginMutation,
    useUpdateProfilePictureMutation,
    useGetProfileQuery,
    useUpdateBioMutation,
    useUpdateProfileMutation,
    useGetFriendsQuery,
    useGetFriendRequestsQuery,
    useGetFriendshipStatusQuery,
    useSendFriendRequestMutation,
    useAcceptFriendRequestMutation,
    useRejectFriendRequestMutation,
    useUpdateCartMutation,
    useUpdatewishlistMutation,
    useGetCartQuery,
    useGetWishlistQuery,
    useUnfriendUserMutation
} = userApi;