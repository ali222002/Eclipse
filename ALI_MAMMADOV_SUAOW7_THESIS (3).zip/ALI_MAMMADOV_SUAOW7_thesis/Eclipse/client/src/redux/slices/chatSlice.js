import { createSlice } from "@reduxjs/toolkit";
// import { sendNotification } from "../../api/conversations/messageApi";

const initialState = {
  allConversations: null,
  selectedConversation: null,
  conversationMessages: [],
  connectedSocket: null,
  isTyping: false,
  lastMessages: [],
  unSeenMessages: [],
  onlineUsers: [],
};

export const chatSlice = createSlice({
  name: "chat",
  initialState,
  reducers: {
    setAllConversations: (state, action) => {
      state.allConversations = action.payload;
    },
    setSelectedConversation: (state, action) => {
      // state.conversationMessages = []
      state.selectedConversation = action.payload;
    },
    addMessagesToStart: (state, action) => {
      state.conversationMessages = [...action.payload, ...state.conversationMessages];
    },
    setConversationMessages: (state, action) => {
      state.conversationMessages = action.payload;
    },
    addNewMessageToStore: (state, action) => {
      // add new message to lastMessages on sender side
      state.lastMessages = updateLastMessages(state, action);
      // add new message to conversationMessages
      state.conversationMessages = [...state.conversationMessages, action.payload];
      // if target user is offline send him a notification
    //   if (!state.onlineUsers?.find(u => u?._id === action.payload?.receiverId)) {
    //     fetch(`${BASE_URL}/notification`, {
    //       method: "POST",
    //       headers: {
    //         "Content-Type": "application/json",
    //         "Authorization": `Bearer ${localStorage.getItem("token")}`,
    //       },
    //       body: JSON.stringify({
    //         receiverId: action.payload?.receiverId,
    //         type: "message",
    //         message: "New message received " + action.payload?.message,
    //         link: "/me/messages/" + action.payload?.chatId,
    //       }),
    //     })
    //   }
    },
    setConnectedSocket: (state, action) => {
      state.connectedSocket = action.payload;
    },
    newMessageRecieved: (state, action) => {
      const message = action.payload;
      // update lastMessages
      state.lastMessages = updateLastMessages(state, action);

      if (message?.chatId === state.selectedConversation?._id) {
        // add new message into conversationMessages
        state.conversationMessages = [...state.conversationMessages, message];
      } else {
        state.unSeenMessages = updateUnseenMessages(state, action);
      }
    },
    changeTypingStatus: (state, action) => {
      const isTyping = action.payload;
      state.isTyping = isTyping;
    },
    addUserToActiveUsers: (state, action) => {
      let user = action?.payload
      let newOnlineUsers = [...state.onlineUsers]
      let userIndex = newOnlineUsers?.findIndex(u => u?._id === user?._id)
      if (userIndex === -1) {
        newOnlineUsers = [...newOnlineUsers, user]
      }
    },
    removeUserFromActiveUsers: (state, action) => {
      let user = action?.payload
      let newOnlineUsers = [...state.onlineUsers]
      let userIndex = newOnlineUsers?.findIndex(u => u?._id === user?._id)
      if (userIndex !== -1) {
        newOnlineUsers.splice(userIndex, 1)
      }
    },
    updateActiveUsers: (state, action) => {
      state.onlineUsers = action.payload
    }
  },
});

const updateUnseenMessages = (state, action) => {
  let unseenMessagesToReturn = [];
  let message = action.payload;
  let newUnseenMessages = [...state.unSeenMessages]
  let unseenMessageIndex = newUnseenMessages?.findIndex(m => m.chatId === message?.chatId)
  let unseenMessage = newUnseenMessages[unseenMessageIndex]
  let messageToReplace = {
    chatId: unseenMessage?.chatId || unseenMessage?.chatId,
    count: unseenMessage?.count + 1
  }
  newUnseenMessages[unseenMessageIndex] = messageToReplace
  if (unseenMessage) {
    unseenMessagesToReturn = [...newUnseenMessages]
  } else {
    unseenMessagesToReturn = [...state.unSeenMessages, {
      chatId: message?.chatId || message?.chatId,
      count: 1
    }]
  }
  return unseenMessagesToReturn;
}

const updateLastMessages = (state, action) => {
  let messagesToReturn = [];

  const message = action.payload;
  let lastMessage = {
    message: message?.message,
    time: new Date(action.payload?.timestamp),
    chatId: message?.chatId,
  };

  // find index of lastMessage in lastMessages
  let index = state.lastMessages?.findIndex(m => m?.chatId === message?.chatId)
  // if exists update lastMessage of that conversation with new lastMessage
  if (index !== -1) {
    let newLastMessages = [...state.lastMessages]
    newLastMessages[index] = lastMessage
    messagesToReturn = [...newLastMessages]
  } else {
    // if not exists, add new lastMessage
    messagesToReturn = [...state.lastMessages, lastMessage]
  }

  return messagesToReturn;
}

export const {
  setAllConversations,
  setConversationMessages,
  addMessagesToStart,
  setSelectedConversation,
  setConnectedSocket,
  addNewMessageToStore,
  newMessageRecieved,
  changeTypingStatus,
  addUserToActiveUsers,
  removeUserFromActiveUsers,
  updateActiveUsers
} = chatSlice.actions;
export default chatSlice.reducer;
