// globalSlice.js
import { createSlice } from '@reduxjs/toolkit';

const initialState = {
    user: null,
    cartLength: 0,
    language: 'en'
};

const globalSlice = createSlice({
    name: 'global',
    initialState,
    reducers: {
        setUserToStore(state, action) {
            state.user = action.payload;
        },
        setcartLengthToStore(state, action) {
            if (action.payload < 0) {
                return;
            }
            state.cartLength = action.payload;
        },
        setLanguageToStore(state, action) {
            if (action.payload === 'en' || action.payload === 'hu') {
                state.language = action.payload;
            }
        }
    },
});

export const {
    setUserToStore,
    setcartLengthToStore,
    setLanguageToStore
} = globalSlice.actions;
export default globalSlice.reducer;
