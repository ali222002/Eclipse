// App.js
import React, { useEffect } from 'react';
import Navbar from "./components/Navbar";
import Main from "./components/Main";
import About from "./components/About";
import Support from "./components/Support";
import Profile from "./components/Profile";
import LoginSignup from "./components/LoginSignup";
import Cart from "./components/Cart";
import Search from "./components/Search";
import Forums from "./components/Forums";
import Store from "./components/Store";
import Lab from "./components/Lab";
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import GameDetails from './pages/GameDetails';
import Library from './pages/Library';
import SalesChart from './pages/SalesChart';
import AuthLayout from './components/layouts/AuthLayout';
import MessagePage from './pages/MessagePage';
import ChatsPage from './pages/ChatsPage';
import useTranslation from './hooks/useTranslation';
import { useSelector } from 'react-redux';
import FriendsPage from './pages/Friends';

function App() {
  const { setLanguage } = useTranslation();
  const selectedLang = useSelector(state => state.global?.language);
  useEffect(() => {
    setLanguage(selectedLang);
  }, [selectedLang]);

  return (
    <div>
      <BrowserRouter>
        <div className="bg-[#1b2838]">
          <Navbar />
          <Routes>
            <Route element={<AuthLayout redirect={false} />}>
              <Route path="/" element={<Main />} />
              <Route path="/About" element={<About />} />
              <Route element={<AuthLayout />}> {/* This is the AuthLayout component */}
                <Route path="/Support" element={<Support />} />
                <Route path="/Profile" element={<Profile />} />
                <Route path="/Cart" element={<Cart />} />
                <Route path="/Friends" element={<FriendsPage />} />
                <Route path="/Forums" element={<Forums />} />
                <Route path="/Lab" element={<Lab />} />
                <Route path="/Library" element={<Library />} />
                <Route path="/SalesChart" element={<SalesChart />} />
                <Route path="/Search" element={<Search />} />
                <Route path='/Messages' element={<ChatsPage />} />
                <Route path='/Messages/:id' element={<MessagePage />} />
              </Route>

              <Route path="/LoginSignUp" element={<LoginSignup />} />
              <Route path="/Store" element={<Store />} />
              <Route path="/Store/:id" element={<GameDetails />} />

              <Route path='*' element={<h1>Not Found</h1>} />
            </Route>
          </Routes>
          {/* Now, the additional components are removed from here to ensure they only render within the Store component */}
          {/* Footer */}
        </div>
      </BrowserRouter>
    </div>
  );
}

export default App;
