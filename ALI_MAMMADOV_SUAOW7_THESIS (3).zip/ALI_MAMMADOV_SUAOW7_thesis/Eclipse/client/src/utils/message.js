// export const getSenderInfo = (users, prop, currentUser) => {
//     return users?.filter(
//         //(elem) => elem?._id !== currentUser?.firebaseDocId
//         (elem) => elem?._id !== currentUser?._id
//     )[0]?.[prop];
// };

export const getSenderInfo = (users, prop, currentUser) => {
    return users?.filter(
        (elem) => elem?._id !== currentUser?._id
    )[0][prop]
};

export const getSenderObject = (users, currentUser) => {
    return users?.filter(
        (elem) => elem?._id !== currentUser?._id
    )[0]
};

export const formatTimestamp = (timestamp) => {
    const date = new Date(timestamp);
    const currentDate = new Date();

    if (
        date.getDate() === currentDate.getDate() &&
        date.getMonth() === currentDate.getMonth() &&
        date.getFullYear() === currentDate.getFullYear()
    ) {
        // If the timestamp is from the same day, use the existing formatting
        const hours = date.getHours();
        const minutes = date.getMinutes();
        const formattedHours = hours % 12 || 12;
        const formattedMinutes = minutes < 10 ? `0${minutes}` : minutes;
        const ampm = hours >= 12 ? 'pm' : 'am';
        return `${formattedHours}:${formattedMinutes} ${ampm}`;
    } else {
        // Calculate the time difference in days
        const timeDifference = Math.ceil((currentDate - date) / (1000 * 60 * 60 * 24));
        if (timeDifference === 1) {
            return 'Yesterday';
        } else if (timeDifference <= 7) {
            return `${timeDifference} day${timeDifference > 1 ? 's' : ''} ago`;
        } else if (timeDifference <= 14) {
            return '1 week ago';
        } else if (timeDifference <= 30) {
            return `${Math.floor(timeDifference / 7)} weeks ago`;
        } else if (timeDifference <= 60) {
            return '1 month ago';
        } else if (timeDifference <= 365) {
            return `${Math.floor(timeDifference / 30)} months ago`;
        } else {
            return `${Math.floor(timeDifference / 365)} years ago`;
        }
    }
}
