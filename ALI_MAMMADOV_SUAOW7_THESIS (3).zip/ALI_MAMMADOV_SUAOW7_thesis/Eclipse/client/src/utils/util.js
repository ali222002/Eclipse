export const SERVER_URL = "http://localhost:8000" 
export const BASE_URL = SERVER_URL + "/api"

export const requestConfig = {
    headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json' 
    },
    withCredentials: true,
    credentials: 'include'
}

export const getImageUrl = (url) => {
    if (url?.includes("http")) {
        return url
    } else {
        return SERVER_URL + "/" + url
    }
}