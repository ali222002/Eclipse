export const gameTypes = [
    {
        name: 'RPG',
    },
    {
        name: 'Survival',
    },
    {
        name: 'First Shooter',
    },
    {
        name: 'Zombie',
    },
    {
        name: 'Fighter',
    }
]