import React from 'react'
import SolidGold from "../assets/SolidGold.jpg";
import SolidGold1 from "../assets/SolidGold1.jpg";
import SolidGold2 from "../assets/SolidGold2.jpg";
import SolidGold3 from "../assets/SolidGold3.jpg";
import SolidGold4 from "../assets/SolidGold4.jpg";
import steamcard from "../assets/steamcard.png";
import { TbApps } from "react-icons/tb";
import { Link } from 'react-router-dom';
import Carousel from './global/Carousel';
import useTranslation from '../hooks/useTranslation';
import { useGetRecommendedGamesQuery } from '../redux/apiServices/gameApi';
import GameCard from './global/GameCard';
import GameSkeleton from './global/GameSkeleton';


const Recomended = () => {
  const { translate } = useTranslation();
  const { isLoading, data } = useGetRecommendedGamesQuery()
  console.log(data);
  return (

    <div className="mx-[1rem] mt-[2rem] text-white text-[14px]">
      <div className="flex flex-row">
        <div className="flex flex-col w-1/4 -ml-28 ">
          <img src={steamcard} alt="Descriptive Alt Text" className="w-full h-full object-cover mb-3 -ml-12" />
          <div className=""></div> {/* Blue line */}
          {/* 5 Sections under the blue line */}
          <div className="space-y-2 lowercase">
            <div className="-ml-12 text-customBlue">{translate("connections")}</div>
            <Link to={'/Friends'} className="-ml-12 text-customGray my-5">{translate("friends")}</Link>
            <div className="-ml-12 text-customBlue">{translate("games")}</div>
            <Link to={'/Messages'} className="-ml-12 text-customGray text-lg">{translate("chats")}</Link>
            <div className="-ml-12 text-customBlue">{translate("buy")}</div>
            <Link to={'/Library'} className="-ml-12 text-customGray text-lg">{translate("library")}</Link>
            <div className="-ml-12 text-customBlue">{translate("development")}</div>
            <Link to={'/SalesChart'} className="-ml-12 text-customGray text-lg">{translate("sellsCharts")}</Link>
            {/* <div className="-ml-12 text-customGray">{translate("recommended")}</div> */}
          </div>
        </div>
        {/* Title */}
        <div className="-ml-12 -mt-3 "><p>{translate("recommended")}</p></div>
        {/* Featured */}
        {
          isLoading ? Array(1).fill().map((_, i) => (
            <GameSkeleton key={i} />
          )) :
            data &&
              data.length === 0 ?
              <div className='text-white text-center'>{translate("noResults")}</div> :
              <Carousel focusElems={1} autoSlide = {true}>
                {
                  data?.map(game => (
                    <div className='min-w-full text-xs leading-5' key={game?._id}><GameCard game={game?.game} /></div>
                  ))
                }
              </Carousel>
        }
        {/* <Carousel focusElems={1}>
          <div className="h-full md:h-[24rem] w-full flex flex-col  md:flex-row pt-3">
            <div className="w-full md:w-[62%] h-full bg-red-400 flex ">
              <img src={SolidGold} alt="" className="object-cover w-full" />
            </div>
            <div className="bg-[#0f1922] h-full w-full md:w-[38%] flex  flex-col justify-between ">
              <div className="  flex flex-col  items-center">
                <p className="text-[30px] mt-3">{translate("gameplayPictures")}</p>
                <div className="px-4 w-full h-[24rem] md:h-[15rem] pt-3">
                  <div className="h-[35%]   w-full flex pb-1 ">
                    <img src={SolidGold1} alt="" className="object-cover w-[50%] pr-1 " />
                    <img src={SolidGold2} alt="" className="object-cover w-[50%] pl-1" />
                  </div>
                  <div className="h-[35%]  w-full flex pt-1 ">
                    <img src={SolidGold3} alt="" className="object-cover w-[50%] pr-1" />
                    <img src={SolidGold4} alt="" className="object-cover w-[50%] pl-1" />
                  </div>
                  <div className=" flex flex-col items-center md:items-start  ">
                    <p className="text-[22px] pt-4">Now Available</p>
                    <div className="bg-[#8cc414] w-[6rem] rounded-[0.5rem] mt-1">
                      <p className="text-[15px] text-center">{translate("topSeller")}</p>
                    </div>
                  </div>
                </div>
              </div>
              <div className="flex items-center justify-center md:justify-between pr-4 gap-4 md:gap-0 -mt-4 md:mt-0 pb-2 md:pb-0">
                <div className="pl-4 pb-2 ">
                  <p className="text-[20px] md:text-[12px]">29.99$</p>
                </div>
                <TbApps className="text-[25px] md:text-[19px]   mb-[10px]" />
              </div>
            </div>
          </div>
        </Carousel> */}
      </div>
    </div>
  );
};

export default Recomended;