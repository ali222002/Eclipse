import React from 'react';
import { Link } from "react-router-dom";
import useTranslation from '../hooks/useTranslation';

const Categories = () => {
  const { translate } = useTranslation()
  return (
    <div className="gradient mx-[2rem] pl-4 pr-2 mt-8 flex items-center justify-between rounded-full py-[0.1rem]">
      <ul className="flex items-center py-1.5 text-white text-[14px] gap-10">
        <li>
          <Link to='/Store'><button>{translate('store')}</button></Link>
        </li>
        <li>
          <Link to='/Search'><button>{translate("search")}</button></Link>
        </li>
        <li>
          <Link to='/Forums'><button>{translate("forums")}</button></Link>
        </li>
        <li>
          <Link to='/Lab'><button>{translate("lab")}</button></Link>
        </li>
      </ul>
    </div>
  );
};

export default Categories