import React, { useEffect } from 'react'
import { useGetProfileQuery } from '../../redux/apiServices/userApi';
import { useDispatch, useSelector } from 'react-redux';
import { setUserToStore } from '../../redux/slices/globalSlice';
import { Navigate, Outlet } from 'react-router-dom';
import useSocketIOHandler from '../../hooks/useSocketIO';

const AuthLayout = ({
    redirect = true
}) => {
    const dispatch = useDispatch();
    const user = useSelector(state => state.global.user);
    useSocketIOHandler();

    const { isLoading, data } = useGetProfileQuery({
        skip: user
    });

    useEffect(() => {
        if (!isLoading && data) {
            dispatch(setUserToStore(data));
        }
    }, [isLoading, data]);


    if (isLoading) {
        return <p>Loading...</p>;
    }
    
    if (!data && !user && redirect) {
        return <Navigate to="/LoginSignup" replace />;
    }

    return <Outlet />;
};

export default AuthLayout;
