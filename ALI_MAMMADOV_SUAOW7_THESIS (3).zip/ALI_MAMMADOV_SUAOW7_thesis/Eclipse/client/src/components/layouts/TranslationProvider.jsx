import React, { createContext, useContext, useState, useCallback } from 'react';

const TranslationContext = createContext();

export const useTranslation = () => useContext(TranslationContext);

export const TranslationProvider = ({ children }) => {
    const [language, setLanguage] = useState('en');  // Default language
    const [translations, setTranslations] = useState({});

    const translate = useCallback(async (text) => {
        if (!text) return '';
        if (translations[text]) return translations[text]; // Use cached translation if available

        const apiKey = 'YOUR_API_KEY';  // Caution: Secure your API key properly
        const url = `https://translation.googleapis.com/language/translate/v2?key=${apiKey}`;
        
        try {
            const response = await fetch(url, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    q: text,
                    target: language
                })
            });
            const data = await response.json();
            const translatedText = data.data.translations[0].translatedText;
            setTranslations(prev => ({ ...prev, [text]: translatedText }));  // Cache the translation
            return translatedText;
        } catch (error) {
            console.error('Error translating:', error);
            return text; // Fallback to original text on error
        }
    }, [language, translations]);

    const value = {
        language,
        setLanguage,
        translate
    };

    return (
        <TranslationContext.Provider value={value}>
            {children}
        </TranslationContext.Provider>
    );
};
