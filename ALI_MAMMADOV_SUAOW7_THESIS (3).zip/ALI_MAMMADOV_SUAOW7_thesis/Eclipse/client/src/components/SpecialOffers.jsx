import React from "react";
import Card from "./Card";
import one from "../assets/DonkeyKongAmiga.jpg";
import two from "../assets/EyeoftheBeholderC64.jpg";
import three from "../assets/RygarTheLegendaryWarrior.jpg";
import four from "../assets/SmartyAndTheNastyGluttons.jpg";
import five from "../assets/SolidGold.jpg";
import six from "../assets/TinyBobble.jpg";
import seven from "../assets/CrazySue.jpg";
import eight from "../assets/Drip.jpg";
import nine from "../assets/Megaball.jpg";
import ten from "../assets/MineSweeper.jpg";

import useTranslation from "../hooks/useTranslation";
import Footer from "./global/Footer";
import GameSCard from "./global/GameSCard";
import { useGetGamesQuery } from "../redux/apiServices/gameApi";
import GameSkeleton from "./global/GameSkeleton";

const SpecialOffer = () => {
  const { translate } = useTranslation();
  const { isLoading, data } = useGetGamesQuery()
  const cards = [
    { wallpaper: one, title: "Gaming room" },
    { wallpaper: two, title: "Gaming room" },
    { wallpaper: three, title: "Gaming room" },
    { wallpaper: four, title: "Gaming room" },
    { wallpaper: five, title: "Gaming room" },
    { wallpaper: six, title: "Gaming room" },
    { wallpaper: seven, title: "Gaming room" },
    { wallpaper: eight, title: "Gaming room" },
    { wallpaper: nine, title: "Gaming room" },
    { wallpaper: ten, title: "Gaming room" },
  ];
  return (
    <>
      <div className="mx-[10rem]  ">
        <h4 className="text-white pt-6 my-5">{translate("specialOffers")}</h4>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {
            isLoading ? Array(10).fill().map((_, i) => <GameSkeleton key={i} />) :
              data?.
              slice(0, 8)?.
              map((game, index) => (
                <GameSCard key={index} game={game} showDiscount />
              ))}
        </div>
      </div>
      <div className="container-fluid" style={{ padding: '5%' }}>
      </div>

      <Footer />
    </>
  );
};

export default SpecialOffer;