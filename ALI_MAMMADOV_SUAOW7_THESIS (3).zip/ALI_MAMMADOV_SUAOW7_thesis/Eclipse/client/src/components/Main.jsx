// Store.js
import React from 'react';
import Categories from "./Categories";
import Recommended from "./Recommended";
import SpecialOffers from "./SpecialOffers";
import HomeGames from './HomeGames';

const Main = () => {
  return (
    <>
      <div className="lg:max-w-[90vw] xl:max-w-[80vw] mx-auto">
        {/* Store content */}
        <Categories />
        <Recommended />
        {/* Any other content specific to the Store page */}
        {/* <HomeGames /> */}
      </div>
      <SpecialOffers />
    </>
  );
};

export default Main;
