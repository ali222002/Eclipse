import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Logo from '../assets/logo.png';
import './Support.css';
import { useLocalStorage } from '../hooks/useLocalStorage';
import { useUpdateProfileMutation } from '../redux/apiServices/userApi';
import { useDispatch, useSelector } from 'react-redux';
import { setUserToStore } from '../redux/slices/globalSlice';


const Support = () => {
  return (
    <div className="support">
      <div className="container-fluid" style={{ padding: '20% 0', display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
        <div className="account-info">
          <h3>Account Information</h3>
          {/* <p>Username:
            {user?.username}
            <button onClick={() => setUpdateOn(true)}>Change Username</button>
          </p>
          <p>Email:
            {user?.email}
            <button onClick={() => setUpdateOn(true)}>Change Email</button>
          </p>
          <p>Password:
            {user?.password}
            <button>Change Password</button>
          </p> */}
          {
            <div className='flex justify-center items-center'>
              <UpdateprofileForm />
            </div>
          }
        </div>
      </div>

      <div className="card-footer" style={{ backgroundColor: '#171a21', width: '100%', height: '100px', padding: '20px 350px', color: 'whitesmoke', overflow: 'hidden', position: 'relative' }}>
        <div style={{ float: 'left', paddingRight: '10px', height: '100%' }}>
          <img src={Logo} width="60" height="25" alt="Eclipse Software" />
        </div>
        <div style={{ float: 'right', paddingLeft: '10px', height: '100%' }}>
        </div>
        <span>
          © 2024 Eclipse Corporation. All rights reserved. All trademarks are property of their respective owners in the US and other countries
          <br />
          VAT included in all prices where applicable.
        </span>
      </div>
    </div>
  );
}

const UpdateprofileForm = () => {
  // const [user, setUser] = useLocalStorage("user", {})
  const dispatch = useDispatch()
  const user = useSelector(state => state.global?.user)

  const [username, setUsername] = useState("")
  const [email, setEmail] = useState("")
  const [update, { isLoading, data, error }] = useUpdateProfileMutation()


  useEffect(() => {
    setUsername(user?.username)
    setEmail(user?.email)
  }, [user])

  useEffect(() => {
    if (!isLoading && data) {
      dispatch(setUserToStore({
        ...user,
        username,
        email
      }))
    }
  }, [isLoading, data])

  const handleUpdate = () => {
    update({
      username,
      email
    })
  }
  return (
    <div className='bg-tansperent flex flex-col w-[60%]'>
      {error && <p className="text-red-500">{error?.data?.message}</p>}
      {data && <p className="text-green-500">{data?.message}</p>}
      <input className='rounded-md border outline-none my-1 bg-transparent px-5 py-2' placeholder='' value={username} onChange={(e) => setUsername(e.target.value)} />
      <input className='rounded-md border outline-none my-1 bg-transparent px-5 py-2' value={email} onChange={(e) => setEmail(e.target.value)} />
      <div className='w-full justify-center items-center flex my-5'>
        <button className='px-3 py-2 bg-transparent border rounded-md max-w-min' onClick={() => handleUpdate()} disabled={isLoading}>{isLoading ? "Loading" : "Update"}</button>
      </div>
    </div>
  )
}

const UpdatePasswordForm = () => {
  const [user, setUser] = useLocalStorage("user", {})
  const [username, setUsername] = useState(user?.username)
  const [email, setEmail] = useState(user?.email)
  const [update, { isLoading, data, error }] = useUpdateProfileMutation()

  useEffect(() => {
    if (!isLoading && data) {
      setUser({
        ...user,
        username,
        email
      })
    }
  }, [isLoading, data])

  const handleUpdate = () => {
    update({
      username,
      email
    })
  }
  return (
    <div className='bg-tansperent flex flex-col w-[60%]'>
      {error && <p className="text-red-500">{error?.data?.message}</p>}
      <input className='rounded-md border outline-none my-1 bg-transparent px-5 py-2' placeholder='' value={username} onChange={(e) => setUsername(e.target.value)} />
      <input className='rounded-md border outline-none my-1 bg-transparent px-5 py-2' value={email} onChange={(e) => setEmail(e.target.value)} />
      <div className='w-full justify-center items-center flex my-5'>
        <button className='px-3 py-2 bg-transparent border rounded-md max-w-min' onClick={() => handleUpdate()} disabled={isLoading}>{isLoading ? "Loading" : "Update"}</button>
      </div>
    </div>
  )
}
export default Support;
