import React, { useEffect } from 'react';
import Categories from './Categories';
import { useGetCartQuery } from '../redux/apiServices/userApi';
import { SERVER_URL } from '../utils/util';
import { useBuyGamesMutation } from '../redux/apiServices/gameApi';
import { useLocalStorage } from '../hooks/useLocalStorage';
import { useDispatch } from 'react-redux';
import { setcartLengthToStore } from '../redux/slices/globalSlice';
import useTranslation from '../hooks/useTranslation';

const Cart = () => {
  const dispatch = useDispatch()
  const { translate } = useTranslation()
  const { isLoading, data } = useGetCartQuery()
  const [buy, { isLoading: checkingOut, error, isSuccess }] = useBuyGamesMutation()
  const [cart, setCart] = useLocalStorage('myCart', [])

  useEffect(() => {
    if (!checkingOut && !error) {
      dispatch(setcartLengthToStore(0))
      setCart([])
    }
  }, [checkingOut, error])

  return (
    <div className="lg:max-w-[90vw] xl:max-w-[80vw] mx-auto min-h-[90vh]">
      <Categories />
      <div className='my-5 w-full'>
        <h1 className='text-white text-2xl'>{translate("cart")}</h1>
        {isSuccess && <p className='text-green-500'>Order Placed Successfully</p>}
        <div className='grid grid-cols-12 w-full gap-5 my-5'>
          <div className='col-span-8'>
            {
              isLoading ? <p>{translate("loading")}</p> :
                <div className='w-full'>
                  {
                    data?.length === 0 ? <p className='text-white text-lg'>{translate("empty")}</p> :
                      <div className=''>
                        {
                          data?.map(game => (
                            <div key={game._id} className='bg-[#1b2838] p-4 rounded-lg border'>
                              <div className='flex justify-between items-center'>
                                <img src={SERVER_URL + "/" + game?.thumbnail} alt={game.title} className='w-20 h-20 object-cover' />
                                <div>
                                  <h1 className='text-white'>{game.description}</h1>
                                  <p className='text-white'>${game.price}</p>
                                </div>
                              </div>
                            </div>
                          ))
                        }
                      </div>
                  }
                </div>
            }
          </div>
          {/** order bill */}
          {
            data?.length > 0 &&
            <div className='col-span-4'>
              {error && <p className='text-red-500'>{error?.data?.message}</p>}
              <div className='bg-[#1b2838] p-4 rounded-lg border'>
                <h1 className='text-white'>{translate('orderSummary')}</h1>
                <div className='flex justify-between items-center mt-5'>
                  <p className='text-white'>{translate('noOfGames')}</p>
                  <p className='text-white'>{data?.length}</p>
                </div>
                <div className='flex justify-between items-center'>
                  <p className='text-white'>Total</p>
                  <p className='text-white'>${data?.reduce((acc, game) => acc + game.price, 0)}</p>
                </div>
                <button className='gradient w-full py-2 rounded-lg mt-2' onClick={() => buy()}>
                  {
                    checkingOut ? 'Checking Out...' : 'Checkout'
                  }
                </button>
              </div>
            </div>}
        </div>

      </div>
    </div>
  )
}

export default Cart