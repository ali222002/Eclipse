import React, { useState } from 'react'
import Categories from './Categories'
import UserCard from './global/UserCard'
import { useGetFriendRequestsQuery, useGetFriendshipStatusQuery } from '../redux/apiServices/userApi'
import UserSkeleton from './global/UserSkeleton'
import Sidebar from './dashboard/Sidebar'
import useTranslation from '../hooks/useTranslation'

const Search = () => {
  const { translate } = useTranslation()
  const [tab, setTab] = React.useState('users')

  return (
    <div className="lg:max-w-[90vw] xl:max-w-[80vw] mx-auto min-h-[90vh]">
      <Categories />
      <div className='flex mt-5'>
        <div className='w-full'>
          <div className='flex my-5'>
            <button onClick={() => setTab('users')} className={`px-4 py-2 ${tab === 'users' ? 'bg-[#2f3e4e]' : 'bg-transperent'} text-white`}>{translate("users")}</button>
            <button onClick={() => setTab('requests')} className={`px-4 py-2 ${tab === 'requests' ? 'bg-[#2f3e4e]' : 'bg-transperent'} text-white`}>{translate("requests")}</button>
          </div>

          <div className='fle justify-center items-center py-10 text-white w-full flex-col'>
            {
              tab === 'users' && <UsersTab />
            }
            {
              tab === 'requests' && <FriendRequestsTab />
            }
          </div>
        </div>
      </div>
    </div>
  )
}

export const UsersTab = () => {
  const [search, setSearch] = useState("")
  const { translate } = useTranslation()
  const { isLoading, data } = useGetFriendshipStatusQuery()

  return (
    <>
      <input type='text' placeholder={translate('username')} className='bg-[#2d3b4e] text-white px-6 py-4 rounded-2xl my-5 w-[40%]' onChange={(e) => setSearch(e.target.value)} value={search} />
      <div className='bg-[#1b2838] grid grid-cols-4 gap-5 w-full'>
        {
          isLoading ? Array(10).fill().map((_, i) => <UserSkeleton key={i} />) :
            data
              ?.filter((user) => user?.user?.username?.toLowerCase()?.includes(search?.toLowerCase()))
              ?.map((data, i) => (
                <UserCard key={i} user={data?.user} status={data?.status} />
              ))
        }
      </div>
    </>
  )
}
export const FriendRequestsTab = () => {
  const { translate } = useTranslation()
  const { isLoading, data } = useGetFriendRequestsQuery()
  return (
    <div className='bg-[#1b2838] grid grid-cols-4 gap-5 w-full'>
      {
        isLoading ? Array(10).fill().map((_, i) => <UserSkeleton key={i} />) :
          data?.map((data, i) => (
            <UserCard key={i} user={data?.sender} status={data?.status} type="friend-request" />
          ))
      }
      {
        !isLoading && data?.length === 0 && <p className='text-white text-center col-span-4'>{translate("noResults")}</p>
      }
    </div>
  )
}
export default Search