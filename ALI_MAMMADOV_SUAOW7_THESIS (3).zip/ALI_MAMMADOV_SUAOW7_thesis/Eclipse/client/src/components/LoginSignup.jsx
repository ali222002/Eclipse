import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';

import './LoginSignup.css';
import { useLoginMutation, useRegisterMutation } from '../redux/apiServices/userApi';
import { useDispatch } from 'react-redux';
import { setUserToStore } from '../redux/slices/globalSlice';
import GoogleLoginComponent from './global/GoogleLogin';

const LoginSignup = () => {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const [state, setState] = useState("Login");
  const [formData, setFormData] = useState({
    username: "",
    password: "",
    email: "",
  })

  const [signin, { isLoading: loginLoading, data: loginInfo, error: loginError }] = useLoginMutation();
  const [register, { isLoading: registerLoading, data: registerInfo, error: registerError }] = useRegisterMutation();
  const changeHandler = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value })

  }

  useEffect(() => {
    if (!loginLoading && loginInfo) {
      localStorage.setItem('token', loginInfo.token);
      localStorage.setItem('user', JSON.stringify(loginInfo.user));
      dispatch(setUserToStore(loginInfo.user));
      navigate('/');
    }
  }, [loginLoading, loginInfo, navigate])

  useEffect(() => {
    if (!registerLoading && registerInfo) {
      localStorage.setItem('token', registerInfo.token);
      localStorage.setItem('user', JSON.stringify(registerInfo.user));
      dispatch(setUserToStore(registerInfo.user));
      navigate('/');
    }
  }, [registerLoading, registerInfo, navigate])



  //validate form
  const validateForm = () => {
    if (state === "Login") {
      if (!formData.email || !formData.password) {
        alert("Please fill in all credentials");
        return false;
      }
    } else if (state === "Sign Up") {
      if (!formData.username || !formData.email || !formData.password) {
        alert("Please fill in all fields");
        return false;
      }
    }
    return true;
  };
  //login
  const login = async () => {
    if (!validateForm()) return;
    signin(formData);
  }
  //signup
  const signup = async () => {
    if (!validateForm()) return;

    register(formData);
  }

  const forgotPassword = async () => {
    if (!formData.email) {
      alert("Please enter your email address");
      return;
    }
  };

  return (
    <div className='loginsignup'>
      <div className="loginsignup-container">
        <h1>{state}</h1>
        {loginError && <p className="text-red-700 text-lg">{loginError?.data?.message}</p>}
        {registerError && <p className="loginsignup-error">{registerError?.data?.message}</p>}
        <div className="loginsignup-fields">
          {state === "Sign Up" && <input name='username' value={formData.username} onChange={changeHandler} type="text" placeholder='Enter Username' />}
          {state !== "Reset Password" && <input name='email' value={formData.email} onChange={changeHandler} type="email" placeholder='Enter Email' />}
          {(state === "Login" || state === "Sign Up" || state === "Reset Password") && (
            <input name='password' value={formData.password} onChange={changeHandler} type="password" placeholder='Enter Password' />
          )}
          {state === "Reset Password" && (
            <input name='resetToken' value={formData.resetToken} onChange={changeHandler} type="text" placeholder='Enter Reset Token' />
          )}
        </div>
        <button onClick={() => {
          if (state === "Login") login();
          else if (state === "Sign Up") signup();
          else if (state === "Forgot Password") forgotPassword();
        }}>Continue</button>
        <div className='w-full bg-slate-300'>
          <GoogleLoginComponent />
        </div>
        {state === "Sign Up" ? <p className="loginsignup-login">Already have an account ? <span onClick={() => { setState("Login") }}>Login here</span></p> :
          <p className="loginsignup-login">Don't have an account ? <span onClick={() => { setState("Sign Up") }}>Click Here</span></p>}
      </div>
    </div>
  );
}

export default LoginSignup