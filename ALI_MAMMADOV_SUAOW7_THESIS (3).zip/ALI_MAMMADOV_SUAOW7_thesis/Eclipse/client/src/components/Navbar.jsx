/* eslint-disable jsx-a11y/alt-text */
import React, { useEffect } from 'react';
import logo from '../assets/logo.png';
import './Navbar.css';
import { FiMenu } from 'react-icons/fi';
import { BiWorld } from 'react-icons/bi';
import { BsCart4 } from "react-icons/bs";
import { Link } from "react-router-dom";
import { useDispatch, useSelector } from 'react-redux';
import { setcartLengthToStore, setLanguageToStore } from '../redux/slices/globalSlice';
import useTranslation from '../hooks/useTranslation';



const Navbar = () => {
  const user = useSelector(state => state.global.user);

  const dispatch = useDispatch();

  const cartLength = useSelector(state => state.global.cartLength);

  const { translate, setLanguage } = useTranslation();

  useEffect(() => {
    dispatch(setcartLengthToStore(JSON.parse(localStorage.getItem('myCart'))?.length || 0));
  }, [cartLength]);

  const handleLanguage = (e) => {
    dispatch(setLanguageToStore(e.target.value));
    setLanguage(e.target.value);
  }

  return (
    <div className='navbar'>
      <div className="bg-[#171a21]">
        <div className="flex items-center max-w-[70vw] mx-auto">
          {/* Left side*/}
          <div className="flex items-center justify-center lg:justify-start py-2 px-2 lg:py-6 lg:px-8 w-full lg:w-auto">
            <div className="lg:hidden left-4 absolute text-white">
              <FiMenu className="text-[30px]" />
            </div>
            <div className="flex items-center text-[#c7d5e0] font-semibold text-[20px]">
              <img src={logo} className="w-12 h-12 mr-2" />
              <p>Eclipse®</p>
            </div>
          </div>
          {/* Middle*/}
          <div className="hidden lg:flex pl-10">
            <ul className="text-[#c5c3c0] text-[13px] flex gap-5">
              <li>
                <p>
                  <Link to='/'><button>{translate('main')}</button></Link>
                </p>
              </li>
              <li>
                <p>
                  <Link to='/About'><button>{translate("about")}</button></Link>
                </p>
              </li>
              <li>
                <p>
                  <Link to='/Support'><button>{translate("support")}</button></Link>
                </p>
              </li>
            </ul>
          </div>
          {/*Right side*/}
          <div className="absolute text-white right-[2.5rem] top-0 text-[12px] lg:flex items-center mt-2 hidden">
            {localStorage.getItem('token') ? (
              <>
                <div className="ml-4 p1-4 px-2 py-[2px] flex items-center">
                  <span className="text-[#c5c3c0] font-semibold hover:text-white duration-100 ease-out">
                    <Link to='/Profile'><button>{user?.username}</button></Link>
                  </span>
                </div>
                <div className="flex items-center bg-[#5c7e10] px-2 py-1 rounded-[0.3rem] duration-300 ease-in-out hover:brightness-105">
                  <button onClick={() => {
                    localStorage.removeItem("token");
                    localStorage.removeItem("user");
                    window.location.replace('/');
                  }}>{translate("logout")}</button>
                </div>
              </>
            ) : (
              <div className="flex items-center bg-[#5c7e10] px-2 py-1 rounded-[0.3rem] duration-300 ease-in-out hover:brightness-105">
                <Link to='/LoginSignup'><button>{translate("signIn")}</button></Link>
              </div>
            )}
            <div className="ml-4 p1-4 px-2 py-[2px] flex items-center">
              <select className="bg-[#1b2838] text-[#c5c3c0] font-semibold hover:text-white duration-100 ease-out" onChange={handleLanguage}>
                <option value={'en'}>Language</option>
                <option value={'en'}>English</option>
                <option value={'hu'}>Hungarian</option>
              </select>
              <BiWorld className="w-5 h-5 ml-1" />
            </div>
            <div className="h-[15px] w-[1px] bg-white mx-2">
            </div>
            <div className="flex items-center">
              <Link to='/Cart'><BsCart4 className="w-5 h-5 ml-1" /></Link>
              <div className="cart-count">{cartLength}</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Navbar;