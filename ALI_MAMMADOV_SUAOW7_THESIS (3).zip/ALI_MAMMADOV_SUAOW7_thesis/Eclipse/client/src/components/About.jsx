import React from 'react';
import './About.css';
import heroHardware from '../assets/heroCOM.png';
import heroEclipseworks from '../assets/heroCON.png';
import EclipseLogo from '../assets/heroVR.png';
import Logo from '../assets/logo.png';
import useTranslation from '../hooks/useTranslation';
import Footer from './global/Footer';

const About = () => {
  const {translate} = useTranslation();
  return (
    <div className="bg">
      <div className="container-fluid" style={{padding: '50px'}}>

        <div id="transparentBG" style={{textAlign: 'center', padding: '100px', overflowX: 'hidden'}}>
          <img style={{position: 'absolute', width: '800px', height: '700px', visibility: 'hidden'}} src={heroHardware} alt="Games"/>
          <h1 className="titleFont">{translate('accessGames')}</h1>
          <p className="smallFont">
            {translate('accessGamesPara1')}
            <br/>
            {translate('accessGamesPara2')}
          </p>
        </div>
      </div>

      <div className="container">
        <div className="container aboutBlock slide-in-rtl">
          <img style={{width: '470px', height: '266px', marginLeft: '40%', position: 'absolute'}} src={heroHardware} alt="Community"/>

          <div className="fade-in">
            <h1 style={{paddingTop: '100px'}} className="titleFont">
              {translate('joinCommunity')}
            </h1>
            <p className="smallFont">
              {translate('joinCommunityPara1')}
              <br/>
              {translate('joinCommunityPara2')}
            </p>
          </div>
        </div>

        <div className="slide-in-ltr">
          <img style={{width: '470px', height: '397px', marginRight: '70%', position: 'absolute'}} src={EclipseLogo} alt="Hardware"/>
          <div style={{marginLeft: '50%'}} className="fade-in"> 
            <h1 style={{paddingTop: '180px'}} className="titleFont">
              {translate('experienceEclipse')}
            </h1>
            <p className="smallFont">
              {translate('experienceEclipsePara')}
            </p>
          </div>
        </div>

        <div className="container aboutBlock slide-in-rtl" style={{marginTop: '200px'}}>
          <img style={{width: '470px', height: '296px', marginLeft: '50%', position: 'absolute'}} src={heroEclipseworks} alt="Steamworks"/>
          
          <div className="fade-in">
            <h1 style={{paddingTop: '100px'}} className="titleFont">
              {translate('releaseYourGame')}
            </h1>
            <p className="smallFont">
              {translate('releaseYourGamePara')}
              <br/> 
              {translate('releaseYourGamePara2')}
            </p>
          </div>
        </div>
        <br/>
      </div>

      {/* <div className="card-footer" style={{backgroundColor: '#171a21', width: '100%', height:'100px', padding: '20px 350px', color: 'whitesmoke', overflow: 'hidden', position: 'relative'}}>
        <div style={{float: 'left', paddingRight: '10px', height: '100%'}}>
          <img src={Logo} width="60" height="25" alt="Eclipse Software"/>
        </div>
        <div style={{float: 'right', paddingLeft: '10px', height: '100%'}}>
        </div>
        <span>
          © 2024 Eclipse Corporation. All rights reserved. All trademarks are property of their respective owners in the US and other countries
          <br/>
          VAT included in all prices where applicable.
        </span>
      </div> */}
      <Footer />
    </div>
  );
}

export default About;
