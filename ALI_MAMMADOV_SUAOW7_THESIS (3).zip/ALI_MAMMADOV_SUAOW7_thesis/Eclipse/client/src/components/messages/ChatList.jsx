import React, { useState, useEffect } from 'react';
import { useSelector } from 'react-redux';
import { useGetChatsQuery } from '../../redux/apiServices/messageApi';
import UserRow from './UserRow';

const itemsPerPage = 10;

const ChatList = ({ onSelectChat }) => {
    let { user } = useSelector(state => state.global);
    const [searchTerm, setSearchTerm] = useState('');
    const [currentPage, setCurrentPage] = useState(1);
    const [contacts, setContacts] = useState([]);

    const { data, error, isLoading } = useGetChatsQuery({
        search: searchTerm,
        page: currentPage,
        limit: itemsPerPage,
    });

    useEffect(() => {
        if (!isLoading && data) {
            setContacts(data?.chats);
        }
    }, [isLoading, data]);

    const handleSearchChange = (e) => {
        setSearchTerm(e.target.value.toLowerCase());
    };

    return (
        <div className="w-full h-full flex flex-col">
            <div className="px-4 py-3">
                <input
                    type="text"
                    placeholder="Search..."
                    value={searchTerm}
                    onChange={handleSearchChange}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring focus:ring-indigo-200"
                />
            </div>
            <div className="flex-1 overflow-y-auto">
                {!isLoading ? (
                    contacts.length > 0 ? (
                        // search term in username or last message
                        contacts
                            .filter((contact) => contact.users.find(u => u._id !== user._id).username.toLowerCase().includes(searchTerm) || contact.lastMessage.toLowerCase().includes(searchTerm))
                            .sort((a, b) => new Date(b.lastmessagetime) - new Date(a.lastmessagetime)).map((contact) => (
                                <UserRow key={contact._id} contact={contact} onSelectChat={onSelectChat} />
                            ))
                    ) : (
                        <div className="text-center text-2xl py-10 w-full min-h-full">No Conversation Found</div>
                    )
                ) : (
                    <div>Loading...</div>
                )}
            </div>
            <div className="w-full flex justify-center items-center py-4 text-white">
                <button
                    onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
                    disabled={currentPage === 1}
                    className="px-3 py-1 border border-gray-300 rounded-md mx-1"
                >
                    Previous
                </button>
                <button
                    onClick={() => setCurrentPage(prev => prev + 1)}
                    className="px-3 py-1 border border-gray-300 rounded-md mx-1"
                >
                    Next
                </button>
            </div>
        </div>
    );
};

export default ChatList;
