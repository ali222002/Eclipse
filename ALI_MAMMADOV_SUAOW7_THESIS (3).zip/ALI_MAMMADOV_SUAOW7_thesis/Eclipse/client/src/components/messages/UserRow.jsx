import React from 'react';
import { SERVER_URL } from '../../utils/util';
import { useSelector } from 'react-redux';

const UserRow = ({ contact, onSelectChat }) => {
  const { user } = useSelector(state => state.global);

  const otherUser = contact.users.find(u => u._id !== user._id);
  return (
    <div
      className="flex items-center p-4 text-white hover:bg-gray-100 hover:text-black cursor-pointer border-b border-gray-200"
      onClick={() => onSelectChat(contact)}
    >
      <img
        className="w-12 h-12 rounded-full mr-4"
        src={otherUser.profilePic ? `${SERVER_URL}/${otherUser.profilePic}` : 'default-profile-pic-url'}
        alt={otherUser.username}
      />
      <div className="flex-1">
        <div className="flex justify-between">
          <h5 className="text-lg font-medium">{otherUser.username}</h5>
        </div>
        <p className="text-sm text-gray-600">{contact.lastMessage}</p>
      </div>
    </div>
  );
};

export default UserRow;
