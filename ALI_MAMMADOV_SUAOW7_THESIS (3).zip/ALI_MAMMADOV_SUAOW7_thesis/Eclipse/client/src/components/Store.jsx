import React from 'react'
import Categories from './Categories'
import GameCard from './global/GameCard'
import { useGetGamesQuery } from '../redux/apiServices/gameApi'
import GameSkeleton from './global/GameSkeleton'
import useTranslation from '../hooks/useTranslation'
import GameSCard from './global/GameSCard'
import GameController from '../assets/3dgame.png'
const Store = () => {
  const [search, setSearch] = React.useState('')
  const { translate } = useTranslation()
  const { isLoading, data } = useGetGamesQuery()
  return (
    <>
      <div className="lg:max-w-[90vw] xl:max-w-[80vw] mx-auto min-h-screen">
        <Categories />

        {/* <h3 className='text-white text-lg mt-5 font-bold'>{translate("store")}</h3> */}
        <EpicGamesSaleBanner />

        <div className='flex items-center'>
          <input type='text' placeholder={translate('search')} className='bg-[#2d3b4e] text-white px-6 py-4 rounded-2xl my-5 w-[40%]' onChange={(e) => setSearch(e.target.value)} value={search} />
        </div>
        {
          isLoading ?
            <div className='w-full grid grid-cols-1  gap-4 mt-4'>
              {
                Array(10).fill().map((_, i) => <GameSkeleton key={i} />)
              }
            </div> :
            <div className='grid grid-cols-2 lg:grid-cols-5  gap-10 mt-4'> {/* Added grid layout */}
              {data?.
                filter((game) => game?.name?.toLowerCase()?.includes(search?.toLowerCase()) || game?.description?.toLowerCase()?.includes(search?.toLowerCase()) || game?.type?.toLowerCase()?.includes(search?.toLowerCase()))?.
                map(game => <GameSCard key={game._id} game={game} />)
              }
            </div>
        }

      </div>
    </>
  )
}
const EpicGamesSaleBanner = () => {
  const {translate} = useTranslation()
  return (
    <div className="bg-dark-900 text-white flex items-center justify-between w-full my-2 slide-in-ltr">
      <div className="space-y-4 w-1/2">
        <h1 className="text-5xl font- fade-in">{translate("salesBannerHeading")}</h1>
        <p className="text-xl fade-in">{translate('salesBannerPara')}</p>
      </div>
      <div className="flex space-x-4 w-1/2 justify-center items-center">
        <img src={GameController} alt="Epic Games Sale" className="w-1/2 h-auto" />
      </div>
    </div>
  );
};

export default Store