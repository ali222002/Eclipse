import React, { useState } from 'react'
import Categories from './Categories'
import { useAddCommentMutation, useCreateForumMutation, useGetAllForumsQuery } from '../redux/apiServices/forumApi'
import { getImageUrl, SERVER_URL } from '../utils/util'
import useTranslation from '../hooks/useTranslation'

const Forums = () => {
  const { translate } = useTranslation()
  return (
    <div className="lg:max-w-[90vw] xl:max-w-[80vw] mx-auto min-h-screen">
      <Categories />

      <div className='w-full'>
        <h1 className='text-white text-lg my-5'>{translate('forums')}</h1>
        <div className='grid grid-cols-12 gap-5'>
          <div className='col-span-7'>
            <ForumsList />
          </div>
          <div className='col-span-5'>
            <CreateForum />
          </div>
        </div>
      </div>
    </div>
  )
}

const ForumsList = () => {
  const { isLoading, data } = useGetAllForumsQuery()
  return (
    <div className='w-full'>
      <div className='grid grid-cols-1 gap-5'>
        {
          isLoading ?
            Array(10).fill().map((_, i) => (
              <div key={i} className='bg-[#1b2838] p-4 rounded-lg border'>
                <div className='animate-pulse flex justify-between items-center'>
                  <div className='bg-[#2f3e4e] w-1/2 h-20'></div>
                </div>
                <div className='mt-3'>
                  <div className='animate-pulse flex justify-between items-center'>
                    <div className='bg-[#2f3e4e] w-1/2 h-5'></div>
                  </div>
                  <div className='animate-pulse flex justify-between items-center'>
                    <div className='bg-[#2f3e4e] w-1/2 h-5'></div>
                  </div>
                </div>
              </div>
            )) :
            data?.forums?.map(forum => (
              <SingleForum key={forum._id} forum={forum} />
            ))
        }
      </div>
    </div>
  )
}

const SingleForum = ({ forum }) => {
  const [comment, setComment] = useState("")

  const [add, { isLoading, error }] = useAddCommentMutation()
  return (
    <div className='gradient p-4 rounded-lg'>
      <h3 className='text-white font-extrabold text-2xl'>{forum.title}</h3>
      <p className='text-white my-5'>{forum.description}</p>

      <div className='flex justify-between items-center'>
        <div className='flex items-center'>
          <img src={getImageUrl(forum?.user?.profilePic)} alt={forum?.user?.username} className='w-10 h-10 object-cover rounded-full' />
          <p className='text-white ml-3'>{forum?.user?.username}</p>
        </div>
        <p className='text-white'>{new Date(forum?.createdAt)?.toLocaleDateString()}</p>
      </div>

      <div className='flex flex-col items-center mt-5'>
        {
          forum?.comments?.length === 0 ? <h3 className='text-white font-bold text-lg'>No Comments Yet</h3> :
            forum?.comments?.map(comment => (
              <div key={comment._id} className='bg-[#2f3e4e] p-4 rounded-lg w-full my-3 flex'>
                <div className='flex items-center'>
                  <img src={getImageUrl(comment?.user?.profilePic)} alt={comment?.user?.username} className='w-10 h-10 object-cover rounded-full' />
                </div>
                <div className='ml-3'>
                  <p className='text-white mt-3'>{comment?.comment}</p>
                  <p className='text-white mt-3'>{new Date(comment?.createdAt)?.toDateString()}</p>
                </div>
              </div>
            ))

        }
      </div>

      <div className='grid grid-cols-8 gap-4 my-5'>
        {
          error && <p className='text-red-500 col-span-8'>{error?.data?.message}</p>
        }
        <input type='text' placeholder='Add a comment' className='border bg-transparent text-white p-2 rounded-lg col-span-6' value={comment} onChange={e => setComment(e.target.value)} />
        <button className=' bg-[#2f3e4e] text-white px-4 py-2 rounded-lg col-span-2'
          onClick={() => add({ forumId: forum?._id, comment: comment })}>{
            isLoading ? "Loading" : "Comment"
          }</button>
      </div>

    </div>
  )
}

const CreateForum = () => {
  const [title, setTitle] = useState('')
  const [description, setDescription] = useState('')
  const { translate } = useTranslation()
  const [create, { isLoading, error, isSuccess }] = useCreateForumMutation()

  const handleSubmit = (e) => {
    e.preventDefault()
    create({ title, description })
  }
  return (
    <div className='bg-[#1b2838] p-4 rounded-lg border'>
      <h3 className='text-white text-lg my-5'>{translate('createForum')}</h3>
      {error && <p className='text-red-500'>{error?.data?.message}</p>}
      {isSuccess && <p className='text-green-500'>Forum created successfully</p>}
      <form onSubmit={handleSubmit}>
        <div className='mb-3'>
          <label htmlFor="title" className='text-white'>{translate('title')}</label>
          <input type="text" id='title' value={title} onChange={e => setTitle(e.target.value)} className='w-full bg-[#2f3e4e] text-white p-2 rounded-lg border' />
        </div>
        <div className='mb-3'>
          <label htmlFor="description" className='text-white'>{translate('description')}</label>
          <textarea id='description' value={description} onChange={e => setDescription(e.target.value)} className='w-full bg-[#2f3e4e] text-white p-2 rounded-lg border h-44'></textarea>
        </div>
        <div className='mb-3 w-full flex justify-center items-center'>
          <button type='button' className='bg-[#2f3e4e] text-white px-4 py-2 rounded-lg' disabled={isLoading} onClick={handleSubmit}>{
            isLoading ? translate('loading') : translate('submit')
          }</button>
        </div>
      </form>
    </div>
  )
}
export default Forums