import React from 'react'
import Categories from './Categories'
import UploadGameForm from './dashboard/UploadGameForm'

const Lab = () => {
  return (
    <>
      <div className="lg:max-w-[90vw] xl:max-w-[80vw] mx-auto h-full">
        <Categories />
        <div className=' flex justify-center items-center py-10 text-white min-h-full'>
          <div className='bg-[#1b2838] p-10 rounded-lg border w-[60%] h-full'>
            <UploadGameForm />
          </div>
        </div>
      </div>
    </>
  )
}

export default Lab