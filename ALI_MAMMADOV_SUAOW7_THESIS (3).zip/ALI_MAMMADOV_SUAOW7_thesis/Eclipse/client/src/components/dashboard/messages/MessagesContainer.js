import React from 'react'
import { useEffect, useRef, useState } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import SingleMessage from './SingleMessage'
import { useGetChatMessagesQuery } from '../../../redux/apiServices/messageApi';
import { addMessagesToStart, setConversationMessages } from '../../../redux/slices/chatSlice';

// import { useGetChatMessagesQuery } from '@/redux/apiServices/messageApi'
// import { addMessagesToStart, setConversationMessages } from '@/redux/slices/chatSlice'

const PAGE_SIZE = 50;
const MessagesContainer = () => {
    const dispatch = useDispatch()

    const lastMessageRef = useRef();

    const [currentPage, setCurrentPage] = useState(1)

    const { selectedConversation, conversationMessages } = useSelector(state => state?.chat)

    const { isLoading, data, isError } = useGetChatMessagesQuery({
        chatId: selectedConversation?._id,
        currentPage,
        limit: PAGE_SIZE
    }, {
        skip: !selectedConversation?._id
    })

    useEffect(() => {
        if (!isLoading && data && data?.data?.messages) {
            if (data?.data?.currentPage === 1) {
                dispatch(setConversationMessages(data?.data?.messages))
            } else if (data?.data?.currentPage < data?.data?.totalPages) {
                dispatch(addMessagesToStart(data?.data?.messages))
            }
        }

        //return () => dispatch(setConversationMessages([]))
    }, [isLoading, data, dispatch])

    useEffect(() => {
        if (lastMessageRef?.current) {
            lastMessageRef?.current?.scrollIntoView({ behavior: 'smooth' });
        }
    }, [conversationMessages]);

    return (
        <div className='px-8 py-5 flex-1 overflow-y-auto max-h-[75vh] no-scrollbar'>
            {conversationMessages?.map((message, index) => (
                <div key={message._id} className='flex justify-between my-5'>
                    <SingleMessage
                        message={message}
                        messageRef={index === PAGE_SIZE - 2 ? lastMessageRef : null}
                    />
                </div>
            ))}
        </div>
    )
}

export default MessagesContainer