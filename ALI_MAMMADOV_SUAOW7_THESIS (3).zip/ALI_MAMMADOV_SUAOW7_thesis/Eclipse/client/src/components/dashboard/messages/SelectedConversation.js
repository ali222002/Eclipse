import React, { useMemo, useState } from 'react'
import { useEffect } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import MessagesContainer from './MessagesContainer'
import SendMessageActions from './SendMessageActions'
import { changeTypingStatus, setSelectedConversation } from '../../../redux/slices/chatSlice'
import { SOCKET_EVENTS } from '../../../utils/socketEvents'

import { getSenderInfo, getSenderObject } from '../../../utils/message'
import { commonApi } from '../../../redux/apiServices/commonApi'
import UserAvatar from '../../global/UserAvatar'
import { useNavigate, useParams } from 'react-router-dom'
import { messageApi, useFetchConversationQuery } from '../../../redux/apiServices/messageApi'
import { getImageUrl, SERVER_URL } from '../../../utils/util'

const SelectedConversation = () => {
    const dispatch = useDispatch()
    const navigate = useNavigate()
    let { id } = useParams()


    const { connectedSocket, selectedConversation } = useSelector(state => state?.chat)
    const { isLoading, data } = useFetchConversationQuery(id, {
        skip: !id
    })

    useEffect(() => {
        if (!connectedSocket) return
        connectedSocket.on(SOCKET_EVENTS.SOCKET_TYPING, (chatId) => {
            if (chatId === selectedConversation?._id) {
                dispatch(changeTypingStatus(true))
            }
        })
        connectedSocket.on(SOCKET_EVENTS.SOCKET_STOP_TYPING, (chatId) => {
            if (chatId === selectedConversation?._id) {
                dispatch(changeTypingStatus(false))
            }
        })
        return () => {
            connectedSocket?.off(SOCKET_EVENTS.SOCKET_TYPING)
            connectedSocket?.off(SOCKET_EVENTS.SOCKET_STOP_TYPING)
        }
    })

    useEffect(() => {
        if (!isLoading && data && data?.chat) {
            dispatch(setSelectedConversation(data?.chat))
        } else if (!isLoading && !data) {
            dispatch(setSelectedConversation(null))
            // navigate('/messages')
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [data, isLoading])

    useEffect(() => {
        if (selectedConversation?._id && connectedSocket) {
            connectedSocket?.emit(SOCKET_EVENTS.SOCKET_JOIN_CHAT, selectedConversation?._id);
        }
        return () => {
            connectedSocket?.emit(SOCKET_EVENTS.SOCKET_LEAVE_CHAT, selectedConversation?._id);
        };
    }, [id, connectedSocket, selectedConversation?._id]);

    useEffect(() => {
        // invalidate the conversation query to refetch the conversation
        if (id) {
            dispatch(messageApi.util.invalidateTags(['Messages']))
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [id])


    return (
        <div className='w-full flex flex-col' style={{
            background: "var(--color-5, #FFF)",
            height: "100%",
            borderRadius: "16px",
        }}>
            <SelectedUser />
            <MessagesContainer />
            <SendMessageActions />
        </div>
    )
}

const SelectedUser = () => {
    const [userStatus, setUserStatus] = useState(false);

    const { selectedConversation, isTyping, onlineUsers } = useSelector(
        (state) => state.chat
    );
    const currentUser = useSelector((state) => state?.global?.user);

    useEffect(() => {
        if (!onlineUsers) return

        const activeUser = onlineUsers?.find(u => u?._id === getSenderInfo(selectedConversation?.users, "_id", currentUser))
        activeUser ? setUserStatus(true) : setUserStatus(false)

    }, [onlineUsers, selectedConversation?.users, currentUser])

    let otherUser = useMemo(() => {
        return getSenderObject(selectedConversation?.users, currentUser)
    }, [selectedConversation?.users, currentUser])

    return (
        <div className='flex justify-centr items-center py-3 px-5' style={{
            borderRadius: "16px",
            background: "rgba(255, 61, 0, 0.12)"
        }}>
            <UserAvatar style={{
                width: "50px",
                height: "50px",
            }}
                label={otherUser?.username}
                src={getImageUrl(otherUser?.profilePic)}
                showStatus={userStatus}
            />
            <div className='flex flex-col items- ml-3'>
                <p className='text-sm font-semibold text-gray-600'>{otherUser?.username}</p>
                {isTyping && <p className='text-xs font-normal text-green-400'>Typing ...</p>}
            </div>
        </div>
    )
}
export default SelectedConversation