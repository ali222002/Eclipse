import React, { useEffect, useState } from 'react'
import { useSelector } from 'react-redux'
import { formatTimestamp, getSenderInfo } from '../../../utils/message'
import { Link } from 'react-router-dom'
import UserAvatar from '../../global/UserAvatar'
import { getImageUrl, SERVER_URL } from '../../../utils/util'

const UserRow = ({ contact }) => {
    const loggedInUser = useSelector(state => state?.global?.user)

    const [userStatus, setUserStatus] = useState(null)
    const [inComingLastMessage, setInComingLastMessage] = useState(null)

    const { selectedConversation, lastMessages, onlineUsers } = useSelector(
        (state) => state.chat
    );

    useEffect(() => {
        if (!lastMessages) return

        // get last message of this chat from lastMessages array
        const lastMessage = lastMessages?.find(m => m?.chatId === contact?._id)

        if (lastMessage) {
            // set last message of this single chat by getting it from lastMessages array
            setInComingLastMessage(lastMessage)
        }
    }, [lastMessages, contact?._id])

    useEffect(() => {
        if (!onlineUsers) return

        // get active user of this chat from onlineUsers array
        const activeUser = onlineUsers?.find(u => u?._id === getSenderInfo(contact?.user, "_id", loggedInUser))
        activeUser ? setUserStatus(true) : setUserStatus(false)
    }, [onlineUsers, contact?.users, loggedInUser])

    return (
        <Link
            to={`/messages/${contact?._id}`}
            className='flex cursor-pointer w-full px-6 py-4 whitespace-nowrap hover:bg-[#F4F4F4]'
            style={{
                backgroundColor: selectedConversation?._id === contact?._id ? 'rgba(255, 61, 0, 0.12)' : '',
            }}
        >
            <UserAvatar
                src={getImageUrl(getSenderInfo(contact?.users, "profilePic", loggedInUser))}
                style={{ width: '65px', height: '65px' }}
                showStatus={userStatus}
                alt={getSenderInfo(contact?.users, "username", loggedInUser)}
            />
            <div className="ml-4" style={{
                color: 'var(--color-text-dark, #041E42)',
                fontFamily: 'Jost',
            }}>
                <div className='flex justify-between items-center'>
                    <p className='text-[16px] font-[400]'>{getSenderInfo(contact?.users, "username", loggedInUser)}</p>
                    <p className='text-[14px] font-[200] ml-2 text-gray-500'>
                        {inComingLastMessage ? formatTimestamp(new Date(inComingLastMessage?.time)) : formatTimestamp(new Date(contact?.lastMessageTime))}
                    </p>
                </div>
                <p className='mt-2 text-[14px] font-normal text-gray-500'>
                    {inComingLastMessage ? `${inComingLastMessage?.message?.substring(0, 20)}` :
                        contact?.lastMessage?.substring(0, 20)}
                    {
                        inComingLastMessage ? inComingLastMessage?.message?.length > 20 ? '...' : '' :
                            contact?.lastMessage?.length > 20 ? '...' : ''
                    }
                </p>
            </div>
        </Link>
    )
}

export default UserRow