// import React, { memo, useEffect } from 'react'
// import Image from 'next/image'
// import { useSelector } from 'react-redux'
// import { getSenderInfo } from '@/utils/message'
// import { useUploadFileMutation } from '@/redux/apiServices/propertyApi'
// import { usePostMessageMutation } from '@/redux/apiServices/messageApi'

// const SendFileMesage = ({
//     messageInput,
//     handleSendMessage,
// }) => {
//     const { selectedConversation: conversation } = useSelector(state => state.chat)
//     const currentUser = useSelector(state => state?.global?.user)

//     const [uploadFile, { isLoading, isSuccess, data }] = useUploadFileMutation()

//     useEffect(() => {
//         if (!isLoading && data) {
//             let messagePayload = {
//                 chatId: conversation?._id,
//                 message: messageInput || 'File sent',
//                 receiverId: getSenderInfo(conversation?.users, 'id', currentUser),
//                 filedata: data?.files,
//                 messagetype: 'file',
//             }
//             console.log('messagePayload', messagePayload);
//             // send message
//             handleSendMessage(messagePayload);
//         }
//         // eslint-disable-next-line react-hooks/exhaustive-deps
//     }, [isLoading, data])

//     const handleImageChange = (e) => {
//         // if empty files return
//         if (e.target.files.length === 0) return
//         // upload image
//         const formData = new FormData();
//         formData.append('files', e.target.files[0]);

//         uploadFile(formData)
//         // // create message payload

//         // let messagePayload = {
//         //     chatId: conversation?._id,
//         //     message: messageInput,
//         //     receiverId: getSenderInfo(conversation?.users, 'id', currentUser),
//         //     files: e.target.files,
//         // }
//         // // send message
//         // sendMessage(messagePayload);
//     }
//     return (
//         <label className="">
//             <Image src={'/Dashboard/add.svg'} width={50} height={50} className='w-[50px] h-[50px] cursor-pointer' />
//             <input
//                 type="file"
//                 className="hidden"
//                 onChange={handleImageChange}
//                 // multiple
//                 accept='.jpg,.jpeg,.png'
//             />
//         </label>
//     )
// }

// export default memo(SendFileMesage)