"use client";
import React, { useState, useEffect } from 'react'
import UserRow from './UserRow';
import { useSelector } from 'react-redux'
import { useGetChatsQuery } from '../../../redux/apiServices/messageApi';
import UserRowSkeleton from '../../global/UserRowSkeleton';

const itemsPerPage = 10;
const ContactsTable = () => {
    const [searchTerm, setSearchTerm] = React.useState("");
    const [currentPage, setCurrentPage] = React.useState(1);
    const [totalContacts, setTotalContacts] = useState(0)
    const [totalPages, setTotalPages] = useState(1)
    const [contacts, setContacts] = useState([])

    const user = useSelector(state => state?.global?.user)

    const { isLoading, error, data } = useGetChatsQuery({
        search: searchTerm,
        page: currentPage,
        limit: 10,
    });

    // const firstItemIndex = (currentPage - 1) * itemsPerPage + 1;
    // const lastItemIndex = Math.min(
    //     firstItemIndex + itemsPerPage - 1,
    //     totalContacts
    // );

    useEffect(() => {
        if (!isLoading && data) {
            setTotalContacts(data?.total)
            setCurrentPage(Number(data?.page))
            setTotalPages(Math.ceil(data?.total / itemsPerPage))
            setContacts(data?.chats)
        }
    }, [isLoading, data])

    const firstItemIndex = (currentPage - 1) * itemsPerPage + 1;
    const lastItemIndex = Math.min(
        firstItemIndex + itemsPerPage - 1,
        totalContacts
    );

    const handleSearchChange = (value) => {
        setSearchTerm(value?.toLowerCase());
    };

    const { lastMessages } = useSelector(state => state?.chat)

    return (
        <div className="shadow-md rounded-lg min-h-[70vh]">
            <div className="px-6 py-3 my-5 w-full" style={{ fontFamily: "Jost", alignItems: "center", display: "flex" }}>
                <div className="w-full">
                    <input type="text" placeholder="Search" className="w-full border border-gray-300 rounded-md p-2 focus:outline-none focus:ring focus:ring-indigo-200" onChange={(e) => handleSearchChange(e.target.value)} />
                </div>
            </div>
            {!isLoading ? contacts?.length > 0 ?
                <>
                    <div className="min-w-full divide-y divide-[#F3F5F6]">
                        <div className="bg-white divide-y divide-[#F3F5F6]">
                            {contacts?.length > 0 &&
                                contacts?.
                                    filter((contact) => contact?.users?.find(u => u?._id !== user?._id)?.username?.toLowerCase()?.includes(searchTerm) || contact?.lastMessage?.toLowerCase()?.includes(searchTerm))?.
                                    slice()?.sort((a, b) => {
                                        const lastMessageA = lastMessages?.find(lastMessage => lastMessage?.chatId === a?._id)
                                        const lastMessageB = lastMessages?.find(lastMessage => lastMessage?.chatId === b?._id)
                                        const lastMessageTimeA = lastMessageA?.time || a?.lastmessagetime
                                        const lastMessageTimeB = lastMessageB?.time || b?.lastmessagetime
                                        return new Date(lastMessageTimeB) - new Date(lastMessageTimeA)
                                    })?.map((contact) => (
                                        <div key={contact._id}>
                                            <UserRow contact={contact} />
                                        </div>
                                    ))}
                        </div>
                    </div>
                    <div className="w-full flex flex-col justify-center items-center">
                        {/* <div className="my-4">
                            <Pagination
                                count={totalPages}
                                page={currentPage}
                                onChange={(_, page) => setCurrentPage(page)}
                                className="my-4"
                                // color="primary"
                                style={{
                                    "& .Mui-selected": {
                                        backgroundColor: "var(--dashboard-purple) !important",
                                        color: "white !important",
                                    },
                                    "& .MuiPaginationItem-root:hover": {
                                        border: "1px solid #000000 !important",
                                    },
                                    "& .MuiPaginationItem-previous": {
                                        border: "1px solid black",
                                        backgroundColor: "pink",
                                    },
                                }}
                            />
                        </div> */}
                    </div>
                </> :
                <div className="text-center text-2xl py-10 w-full min-h-full text-white ">No Conversation Found</div>
                : <div>
                    {Array.from(new Array(4)).map((_, key) => <UserRowSkeleton key={key} />)}
                </div>}
        </div>
    )
}

export default ContactsTable