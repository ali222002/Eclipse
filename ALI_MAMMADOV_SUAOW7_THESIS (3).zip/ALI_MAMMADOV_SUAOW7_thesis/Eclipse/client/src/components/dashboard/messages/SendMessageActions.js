import React, { useCallback, useEffect } from 'react'
import { useState } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { SOCKET_EVENTS } from '../../../utils/socketEvents'
import { getSenderInfo } from '../../../utils/message'
import { usePostMessageMutation } from '../../../redux/apiServices/messageApi'
import { addNewMessageToStore } from '../../../redux/slices/chatSlice'
// import SendFileMesage from './SendFileMesage'
import { VscSend } from "react-icons/vsc";

const SendMessageActions = () => {
    const currentUser = useSelector(state => state?.global?.user)
    const { selectedConversation: conversation, connectedSocket: socket } = useSelector(state => state.chat)
    const [messageInput, setMessageInput] = useState("")
    const dispatch = useDispatch()

    const [sendMessage, { isLoading, error, data }] = usePostMessageMutation();

    useEffect(() => {
        if (!isLoading && !error && data) {
            setMessageInput("")
            dispatch(addNewMessageToStore({
                ...data?.data?.message,
            }))
            if (socket) {
                socket.emit(SOCKET_EVENTS.SOCKET_SEND_MESSAGE, data?.data?.message);
               
            }
            else console.log('socket not connected')
        }

        return () => {
            setMessageInput("")
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [isLoading, error, data])

    const handleSendMessage = useCallback((data = null) => {
        if (!conversation._id) return
        if (isLoading) return
        if ((!messageInput || messageInput.trim().length === 0) && (!data?.message)) return
        let messagePayload = {
            chatId: conversation?._id,
            message: messageInput,
            receiverId: getSenderInfo(conversation?.users, '_id', currentUser)
        }
        data !== null ? sendMessage(data) : sendMessage(messagePayload);
    })

    return (
        <div className='p-4 flex justify-between items-center w-full'>
            {/* <SendFileMesage messageInput={messageInput} setMessageInput={setMessageInput} handleSendMessage={handleSendMessage} /> */}
            <MessageInput messageInput={messageInput} setMessageInput={setMessageInput} handleSendMessage={handleSendMessage} />
            <VscSend size={30} className='cursor-pointer ml-5' onClick={() => handleSendMessage()} />
        </div>
    )
}

const MessageInput = ({ messageInput, setMessageInput, handleSendMessage }) => {
    const { selectedConversation: conversation, connectedSocket: socket } = useSelector(state => state.chat)

    let typingTimeout; // Store the timeout ID
    const handleInputChange = (e) => {
        // message length should not exceed 800 characters
        if (e.target.value.length > 800) return
        setMessageInput(e.target.value)
        socket?.emit(SOCKET_EVENTS.SOCKET_TYPING, conversation?._id);

        clearTimeout(typingTimeout); // Clear any existing timeout
        typingTimeout = setTimeout(handleStopTyping, 1000); // Delay before emitting "stop typing"
    }

    const handleStopTyping = () => {
        socket?.emit(SOCKET_EVENTS.SOCKET_STOP_TYPING, conversation?._id);
    };

    return <div
        className='flex justify-between border-[#F3F5F6] border rounded-lg px-4 py-2 w-full bg-[#F1F3F5] h-[60px] relative'
    >
        <input
            value={messageInput}
            onChange={handleInputChange}
            onKeyUp={(key) => key?.code === 'Enter' && handleSendMessage()}
            type='text'
            placeholder='Type a message'
            className='bg-transparent flex-1'
        />
    </div>
}
export default SendMessageActions