import { formatTimestamp, getSenderInfo, getSenderObject } from '../../../utils/message'
import React, { useMemo } from 'react'
import { useSelector } from 'react-redux'
import UserAvatar from '../../global/UserAvatar'
import { getImageUrl, SERVER_URL } from '../../../utils/util'


const SingleMessage = ({ message, user = "admin" }) => {
    const loggedInUser = useSelector(state => state?.global?.user)
    const { selectedConversation } = useSelector(state => state.chat)

    const isSender = message?.senderId === loggedInUser?._id
    const otherUser = useMemo(() => {
        return getSenderObject(selectedConversation?.users, loggedInUser)
    }, [selectedConversation, loggedInUser])

    const sender = useMemo(() => {
        return isSender ? loggedInUser : otherUser
    }, [isSender, loggedInUser, otherUser])

    return (
        <div className='flex w-full'>
            <div className='flex flex-col w-full'>
                <div className={`flex items-center ${isSender ? 'flex-row-reverse' : ''}`}>
                    {<UserAvatar src={getImageUrl(sender?.profilePic)} label={sender?.username} style={{ width: '40px', height: '40px' }} showStatus={false} />}
                    <div className='flex flex-col font-[Jost]' style={{
                        background: isSender ? 'rgba(13, 90, 168, 0.20)' : '#1b2838',
                        color: isSender ? 'var(--color-text-dark, #041E42)' : 'white',
                        borderRadius: '16px',
                        margin: isSender ? '0px 10px 0px 0px' : '0px 0px 0px 10px',
                    }}>
                        {
                            message?.files && message?.files?.length > 0 ?
                                (
                                    <img src={message?.files[0]?.fileurl} width={40} height={40} className='min-w-[150px] max-w-[200px] h-[auto] cursor-pointer object-contain rounded-[16px]'
                                        alt={message?.message} />
                                )
                                :
                                null
                        }
                        <div className='px-4  py-2'>
                            <p className='text-[14px] font-[400]'>{message?.message}</p>
                            <p className='text-[14px] font-[200] justify-end'>{formatTimestamp(message?.timestamp)}</p>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    )
}

export default SingleMessage