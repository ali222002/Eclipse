// import React, { useMemo } from 'react'
// import { useSelector } from 'react-redux'
// import Accordion from '@mui/material/Accordion';
// import AccordionSummary from '@mui/material/AccordionSummary';
// import AccordionDetails from '@mui/material/AccordionDetails';
// import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
// import { getSenderObject } from '@/utils/message';
// import userimg from "../../../../public/User/defaultUserImage.png"


// export const SelectedUser = () => {
//     const loggedInUser = useSelector(state => state?.global?.user)
//     const { selectedConversation, conversationMessages } = useSelector(state => state?.chat)

//     const secondUser = useMemo(() => {
//         return getSenderObject(selectedConversation?.users, loggedInUser)
//     }, [loggedInUser, selectedConversation])

//     const userDetails = [
//         {
//             label: 'Email',
//             component: <p className='text-sm font-semibold text-gray-600 my-3'>{secondUser?.email}</p>
//         },
//         {
//             label: 'Media',
//             component: <div className='grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2'>
//                 {
//                     conversationMessages?.map((message, index) => {
//                         if (message?.files?.length > 0) {
//                             return (
//                                 <img key={index} src={message?.files[0]?.fileurl} height={40} className=' h-[auto] max-w-[100px] max-h-[100px] cursor-pointer object-contain rounded-[10px]'
//                                     alt={message?.message} />
//                             )
//                         }
//                     })
//                 }
//             </div>
//         },
//         {
//             label: 'Documents',
//             component: <p className='text-sm font-semibold text-gray-600 my-3'>Nothing Found</p>
//         },
//         {
//             label: 'Information',
//             component: <div>
//                 <p className='text-sm font-semibold text-gray-600 my-3'>{
//                     secondUser?.firstname + " " +
//                     (secondUser?.lastname || "")
//                 }</p>
//                 <p className='text-sm font-semibold text-gray-600 my-3'>{secondUser?.email}</p>
//             </div>
//         }
//     ]
//     return (
//         <div className='w-full flex flex-col'>
//             <UserPhoto title={secondUser?.firstname + " " + (secondUser?.lastname || "")} src={secondUser?.profilepicture} />
//             <div className='flex flex-col mt-5'>
//                 {
//                     userDetails.map((detail, index) => (
//                         <DetailsAccordion key={index} label={detail.label}>
//                             {detail.component}
//                         </DetailsAccordion>
//                     ))
//                 }
//             </div>
//         </div>
//     )
// }

// const UserPhoto = ({ src, title }) => {
//     console.log(src);
//     return (
//         <div className='flex justify-center items-center bg-[#FFF] p-5 rounded-[16px]'>
//             <div className='flex flex-col items-center ml-3'>
//                 <Image src={src ? src : userimg} width={30} height={30} className='rounded-[20px] w-[200px] h-[150px] bg-center bg-contain' />
//                 <p className='text-sm font-semibold text-gray-600 my-3'>{title}</p>
//             </div>
//         </div>
//     )
// }

// const DetailsAccordion = ({ label, children }) => {
//     return (
//         <Accordion sx={{
//             marginTop: '10px',
//             background: '#FFF',
//             borderRadius: '16px !important',
//             border: 'none',
//         }}
//             square={true}
//         >
//             <AccordionSummary
//                 expandIcon={<ExpandMoreIcon />}
//                 aria-controls="panel1a-content"
//                 id="panel1a-header"
//             >
//                 <p style={{
//                     color: "rgba(0, 0, 0, 0.35)",
//                     fontFamily: "Jost",
//                     fontSize: "16px",
//                     fontStyle: "normal",
//                     fontWeight: "400",
//                 }}>{label}</p>
//             </AccordionSummary>
//             <AccordionDetails>
//                 {children}
//             </AccordionDetails>
//         </Accordion>
//     )
// }
