import React from 'react'

const Sidebar = () => {
    return (
        <div className="space-y-2 p-10">
            <div className="-ml-12 text-customBlue">CONNECTIONS</div>
            <div className="-ml-12 text-customGray">Friends</div>
            <div className="-ml-12 text-customGray">Chat</div>
            <div className="-ml-12 text-customBlue">BUYING</div>
            <div className="-ml-12 text-customGray">Library</div>
            <div className="-ml-12 text-customBlue">DEVELOPMENT</div>
            <div className="-ml-12 text-customGray">Sells Chart</div>
            <div className="-ml-12 text-customBlue">GAMES</div>
            <div className="-ml-12 text-customGray">Recommended</div>
        </div>
    )
}

export default Sidebar