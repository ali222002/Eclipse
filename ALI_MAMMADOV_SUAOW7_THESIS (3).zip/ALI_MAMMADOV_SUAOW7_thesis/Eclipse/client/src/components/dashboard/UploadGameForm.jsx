import React, { useState } from 'react'
import { gameTypes } from '../../utils/games'
import FileInput from '../global/FileInput'
import { useNavigate } from 'react-router-dom'
import useTranslation from '../../hooks/useTranslation'

// thumbnail, description, price, pictures, type
const UploadGameForm = () => {
    const navigate = useNavigate()
    const [game, setGame] = useState({
        name: '',
        description: '',
        price: '',
        thumbnail: '',
        pictures: [],
        folder: '',
        type: ''
    })
    const [Loading, setLoading] = useState(false)
    const [error, setError] = useState(null)
    const {translate} = useTranslation()

    const handleChange = (e) => {
        setGame({
            ...game,
            [e.target.name]: e.target.value
        })
    }

    const handleSubmit = async (e) => {
        e.preventDefault()

        if (!game.name || !game.description || !game.price || !game.thumbnail || !game.pictures || !game.type || !game.folder) {
            alert('All fields are required')
            return
        }
        if (game.pictures.length < 4 || game.pictures.length > 4) {
            alert("4 images are required" + game.pictures.length)
            return
        }

        setLoading(true)
        let formData = new FormData()
        formData.append('name', game.name)
        formData.append('description', game.description)
        formData.append('price', game.price)
        formData.append('pictures', game.thumbnail)
        let len = game.pictures.length > 5 ? 5 : game.pictures.length
        for (let i = 0; i < len; i++) {
            formData.append('pictures', game.pictures[i])
        }
        formData.append('pictures', game.folder)
        formData.append('type', game.type)

        const token = localStorage.getItem('token');
        try {
            let res = await fetch(`http://localhost:8000/api/games`, {
                method: 'POST',
                headers: {
                    'Authorization': `${token}`,
                },
                body: formData
            })

            navigate('/')
        } catch (error) {
            setError(error?.message)
        } finally {
            setLoading(false)
        }


    }
    return (
        <div className='w-full'>
            <h1 className='text-white text-2xl font-bold'>{translate("uploadGame")}</h1>
            <form className='flex flex-col gap-5 mt-5'>
                <input type='text' placeholder={translate('gameName')} className='bg-[#2d3b4e] text-white p-2 rounded-lg' onChange={handleChange} name='name' required />
                <input type='number' placeholder={translate('price')} className='bg-[#2d3b4e] text-white p-2 rounded-lg' onChange={handleChange} name='price' required />
                <div className='w-full'>
                    <label htmlFor="game-type" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white"></label>
                    <select name='type' id='game-type' className=' w-full h-[40px] bg-[#2d3b4e] rounded-lg' onChange={handleChange} required>
                        <option value='' className='p-5'>{translate("selectAType")}</option>
                        {
                            gameTypes.map((type, index) => (
                                <option key={index} value={type.name} className='py-5'>{type.name}</option>
                            ))
                        }
                    </select>
                </div>
                <textarea type='text' placeholder={translate('description')} className='bg-[#2d3b4e] text-white p-2 rounded-lg h-20' onChange={handleChange} name='description' required />
                <p className='text-white'>{translate("thumbnail")}</p>
                <FileInput id={"thumbnail"} multiple={false} accept='image/*' onChange={(e) => {
                    setGame({
                        ...game,
                        thumbnail: e.target.files[0]
                    })
                }} />
                <p className='text-white'>{translate("pictures")}</p>
                <FileInput id={"pictures"} multiple={true} accept='image/*' onChange={(e) => {
                    setGame({
                        ...game,
                        pictures: e.target.files
                    })
                }} />
                <p className='text-white'>{translate("game") + " " + translate("folder")}</p>
                <FileInput id={"folder"} multiple={false}
                    showPreview={false}
                    accept='application/zip,application/x-zip-compressed,application/x-7z-compressed,application/x-rar-compressed'
                    onChange={(e) => {
                        setGame({
                            ...game,
                            folder: e.target.files[0]
                        })
                    }} />

                <div className='flex justify-center items-center my-5'>
                    <button type='button' className=' text-white px-10 py-2 rounded-lg gradient max-w-min' onClick={handleSubmit} disabled={Loading}>
                        {
                            Loading ? translate("loading") : translate('submit')
                        }
                    </button>
                </div>
            </form>
        </div>
    )
}

export default UploadGameForm