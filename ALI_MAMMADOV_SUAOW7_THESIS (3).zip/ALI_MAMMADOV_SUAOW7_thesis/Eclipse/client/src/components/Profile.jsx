import React, { useEffect, useState } from 'react';
import Pro from '../assets/profile.jpg';
import './Profile.css';
import { useLocalStorage } from '../hooks/useLocalStorage';
import { useUpdateBioMutation, useUpdateProfilePictureMutation } from '../redux/apiServices/userApi';
import { MdOutlineModeEdit } from "react-icons/md";
import { CgProfile } from "react-icons/cg";
import { getImageUrl, SERVER_URL } from '../utils/util';
import { useDispatch, useSelector } from 'react-redux';
import { setUserToStore } from '../redux/slices/globalSlice';
import { useGetPlayedGamesQuery } from '../redux/apiServices/gameApi';

const Profile = () => {
  // const [user, setUser] = useLocalStorage("user", {})
  const dispatch = useDispatch()

  const [editBio, setEditBio] = useState(false)

  const { user } = useSelector(state => state.global)

  const [update, { isLoading, data, error }] = useUpdateBioMutation()
  const { isLoading: loading, data: games } = useGetPlayedGamesQuery()
  // const [addProfilePic, { isLoading: uploading, error: uploadError }] = useUpdateProfilePictureMutation()

  const [bio, setBio] = useState(user?.bio)
  const [filePreview, setFilePreview] = useState('')

  useEffect(() => {
    if (!isLoading && data) {
      dispatch(setUserToStore({
        ...user,
        bio: bio
      }))
      // setUser({
      //   ...user,
      //   bio: bio
      // })
      setEditBio(false)
    }
  }, [isLoading, data])


  const handleUpdateBio = () => {
    update({
      bio
    })
  }


  const previewFile = (file) => {
    const reader = new FileReader();
    reader.onload = () => {
      setFilePreview(reader.result);
    };
    reader.readAsDataURL(file);
  };

  const handleFileInputChange = async (e) => {
    const files = e.target.files;
    let file = files && files[0]

    previewFile(file);
    let formData = new FormData();
    formData.append('file', file);

    const token = localStorage.getItem('token');
    let res = await fetch(`http://localhost:8000/api/users/profilePic`, {
      method: 'PUT',
      headers: {
        'Authorization': `${token}`
      },
      body: formData
    })

    dispatch(setUserToStore({
      ...user,
      profilePic: res?.data?.link
    }))

    // setUser({
    //   ...user,
    //   profilePic: res?.data?.link
    // })


    //addProfilePic(formData)

  }


  let imgSrc = filePreview || getImageUrl(user?.profilePic) || Pro
  return (
    <div className="profile bg-gray-800 text-white min-h-screen flex flex-col">
      <div className="flex-grow flex justify-center items-center">
        <div className="card bg-gray-900 border border-gray-700 p-5 w-full max-w-4xl">
          <div className="profile-header flex items-center mb-4 pb-4 border-b border-gray-700">
            {/* <img src={Pro} alt="User" className="w-16 h-16 rounded-full border-2 border-gray-500 mr-4" /> */}
            <div className='relative'>
              <div className="flex items-center cursor-pointer justify-center relative w-16 h-16 rounded-full border-2 border-brand-100">
                <label for="file">
                  <img src={imgSrc} alt="User" className="w-16 h-16 rounded-full border-2 border-gray-500 mr-4" />
                </label>

                <input
                  id="file"
                  className="absolute w-full h-full hidden"
                  type="file"
                  accept="image/*"
                  onChange={handleFileInputChange}
                />
              </div>

              {/* <input type="file" name="file-input" id="file-input" className="absolute top-3 w-[1px]" 
              ></input> */}
            </div>
            <div className='ml-5'>
              <h2 className="text-lg">{user?.username}</h2>
              <div className='flex items-center'>
                <p>{user?.bio ? user?.bio : "No additional information provided."}</p>
                <MdOutlineModeEdit className='ml-2 text-gray-400 cursor-pointer' onClick={() => setEditBio(!editBio)} />
              </div>
            </div>
          </div>
          {editBio && <div className="recent-activity my-5">
            {error && <p className="text-red-500">{error?.data?.message}</p>}
            <h3 className="text-gray-400">Bio</h3>
            <textarea className='h-20 w-full border outline-none my-1 bg-transparent px-5 py-2' value={bio} onChange={(e) => setBio(e.target.value)} />
            <button className='px-3 py-2 bg-transparent border rounded-md' onClick={() => handleUpdateBio()} disabled={isLoading}>{isLoading ? "Loading" : "Update"}</button>
          </div>}
          <div className="recent-activity">
            <h3 className="text-gray-400">Recent Activities</h3>
            <div className='w-full'>
              {
                !loading ?
                  games?.map(game => (
                    <div key={game._id} className='bg-[#2f3e4e] p-4 rounded-lg w-full my-3 flex items-center'>
                      <div className='flex items-center'>
                        <img src={getImageUrl(game?.thumbnail)} alt={game?.title} className='w-10 h-10 object-cover rounded-full' />
                      </div>
                      <div className='ml-3'>
                        <p className='text-white'>{game?.name}</p>
                      </div>
                    </div>
                  ))
                  :
                  Array(6).fill().map((_, i) => (
                    <div key={i} className='bg-[#2f3e4e] p-4 rounded-lg w-full my-3 flex'>
                      <div className='flex items-center'>
                        <div className='w-10 h-10 bg-gray-500 rounded-full'></div>
                      </div>
                      <div className='ml-3'>
                        <p className='text-white mt-3'>Loading...</p>
                        <p className='text-white mt-3'>Loading...</p>
                      </div>
                    </div>
                  ))

              }
            </div>
            {/* Add game images or activity logs here */}
          </div>
        </div>
      </div>
    </div>
  )
}

export default Profile;
