import React from 'react'

const GameSkeleton = () => {
  return (
    <div className='animate-pulse bg-[#1b2838] rounded-lg p-4 w-full'>
      <div className='flex justify-center items-center w-full'>
        <div className='w-[400px] h-48 bg-[#2e3c4d] rounded-lg'></div>
      </div>
      <div className='flex flex-col justify-center items-center mt-4'>
        <div className='w-[300px] h-4 bg-[#2e3c4d] rounded-lg'></div>
        <div className='w-[200px] h-4 bg-[#2e3c4d] rounded-lg mt-2'></div>
      </div>
    </div>
  )
}

export default GameSkeleton