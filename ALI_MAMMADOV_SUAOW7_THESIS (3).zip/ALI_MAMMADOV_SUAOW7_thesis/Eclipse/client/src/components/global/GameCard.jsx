import React from 'react'
import { TbApps } from "react-icons/tb";
import { SERVER_URL } from '../../utils/util';
import { useNavigate } from 'react-router-dom';
import useTranslation from '../../hooks/useTranslation';


const GameCard = ({
    game
}) => {
    const { translate } = useTranslation()
    const navigate = useNavigate()
    return (
        <div className="h-full w-full flex flex-col  md:flex-row pt-3">
            <div className="w-full md:w-[62%] h-full bg-red-400 flex ">
                <img src={SERVER_URL + "/" + game?.thumbnail} alt="" className="object-cover w-full" />
            </div>
            <div className="bg-[#0f1922] h-full w-full md:w-[38%] flex  flex-col justify-between text-white py-5">
                <div className="  flex flex-col  items-center">
                    <p className="text-lg mt-3">{translate("gameplayPictures")}</p>
                    <div className="px-4 w-full my-2">
                        <div className='grid grid-cols-2 gap-5'>
                            {
                                game?.pictures?.map((screenshot, index) => (
                                    <img key={index} src={SERVER_URL + "/" + screenshot} alt="" className="object-cover w-full h-[10rem] md:h-[7rem] rounded-md" />
                                ))
                            }
                        </div>
                        <div className=" flex flex-col items-center md:items-start  ">
                        <p className="bg-green-800 px-3 py-1 my-3">{game?.type?.substr(0, 30)}</p>
                            <p className=" pt-4">{game?.name?.substr(0, 200)}</p>
                            <p className=" pt-4">{game?.description?.substr(0, 300)}</p>
                        </div>
                    </div>
                </div>
                <div className="flex items-center justify-center md:justify-between pr-4 gap-4 md:gap-0 -mt-4 md:mt-0 pb-2 md:pb-0">
                    <div className="pl-4 pb-2 ">
                        <p className="text-[20px] md:text-[12px]">{game?.price}$</p>
                    </div>
                    <TbApps className="text-[25px] md:text-[19px]   mb-[10px]" />
                </div>
                {/* <div className="flex w-full justify-center pb-4">
                    <button className='bg-[#2f3e4e] text-white py-2 px-5 rounded-[0.5rem] text-[20px]'
                        onClick={() => navigate(`/Store/${game?._id}`)}
                    >{translate("details")} </button>
                </div> */}

            </div>
        </div>
    )
}

export default GameCard