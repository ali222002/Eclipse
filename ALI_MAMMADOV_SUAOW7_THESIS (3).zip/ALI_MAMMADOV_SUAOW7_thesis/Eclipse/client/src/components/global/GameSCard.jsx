import React from 'react';
import { SERVER_URL } from '../../utils/util';
import { Link } from 'react-router-dom';

const GameSCard = ({
    game,
    showDiscount = false
}) => {
    return (
        <Link to={`/Store/${game?._id}`} className="shadow-lg rounded-lg p-4 max-w-sm transform transition duration-500 hover:scale-105 cursor-pointer text-white">
            <div className="relative">
                <img className="rounded-lg w-full h-[350px]  
                " src={SERVER_URL + "/" + game?.pictures[0]} alt="Game Thumbnail" />
                {showDiscount && <span className="absolute top-0 right-0 bg-red-500 text-white px-2 py-1 text-xs font-bold rounded-bl-lg">-20%</span>}
            </div>
            <div className="mt-4">
                <h5 className="text-lg font-bold">{game?.name || game?.description(0, 30)}</h5>
                <p className=" text-sm">{game?.type}</p>
                <div className="flex justify-between items-center mt-3">
                    <p className="text-xl font-bold">{game?.price?.toFixed(1)}$</p>
                    {showDiscount && <p className="text-sm line-through">
                        {(game?.price + game?.price * 0.2).toFixed(1)}$
                    </p>}
                </div>
            </div>
        </Link>
    );
};

export default GameSCard;
