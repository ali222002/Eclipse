import React from 'react'

const UserSkeleton = () => {
  return (
    <div className='flex flex-col items-center justify-center mt-20'>
      <div className='w-20 h-20 bg-gray-300 rounded-full animate-pulse'></div>
      <div className='mt-4 w-20 h-4 bg-gray-300 rounded-full animate-pulse'></div>
    </div>
  )
}

export default UserSkeleton