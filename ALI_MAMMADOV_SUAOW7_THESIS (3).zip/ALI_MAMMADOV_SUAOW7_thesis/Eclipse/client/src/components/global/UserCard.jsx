import React, { useEffect } from 'react';
import { getImageUrl } from '../../utils/util';
import { useAcceptFriendRequestMutation, useRejectFriendRequestMutation, useSendFriendRequestMutation, useUnfriendUserMutation } from '../../redux/apiServices/userApi';
import { useSetupChatMutation } from '../../redux/apiServices/messageApi';
import { useSelector } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import useTranslation from '../../hooks/useTranslation';

const UserCard = ({ user, status, type = "user", request }) => {
    const navigate = useNavigate();
    const { user: currentUser } = useSelector(state => state.global);
    const { translate } = useTranslation()
    const [send, { isLoading: sendLoading, error: sendError }] = useSendFriendRequestMutation();
    const [reject, { isLoading: rejectLoading }] = useRejectFriendRequestMutation();
    const [accept, { isLoading: acceptLoading }] = useAcceptFriendRequestMutation();
    const [setupChat, { isLoading: chatLoading, error: chatError, data: chatData }] = useSetupChatMutation();
    const [unfriend, { isLoading: saving }] = useUnfriendUserMutation()

    const handleRejectFriend = (e) => {
        e.preventDefault();
        if (rejectLoading || !user?._id) return;
        reject(user?._id);
    };

    const handleAcceptFriend = (e) => {
        e.preventDefault();
        if (acceptLoading || !user?._id) return;
        accept(user?._id);
    };

    const handleAddFriend = (e) => {
        e.preventDefault();
        if (sendLoading || !user?._id) return;
        send(user?._id);
    };

    const handleStartChat = async (e) => {
        e.preventDefault();
        if (!currentUser) {
            navigate('/auth/login');
            return;
        }

        if (currentUser?._id === user?._id) {
            // Handle case where user tries to chat with themselves
            return;
        }

        if (!user?._id) return;

        await setupChat({
            userid: user?._id,
        });
    };

    // Redirect to chat page if chat setup is successful
    useEffect(() => {
        if (chatData && chatData._id) {
            navigate(`/messages/${chatData._id}`);
        }
    }, [chatData, navigate]);

    const handleUnfriend = (e) => {
        e.preventDefault();
        if (saving || !user?._id) return;
        unfriend(user?._id)
    }

    return (
        <div className="border p-5 rounded-lg shadow flex justify-center items-center flex-col transform transition duration-500 hover:scale-105">
            {(sendError || chatError) && <div className="text-red-500 p-2 rounded-lg">{sendError?.data?.message || chatError?.data?.message}</div>}
            <div className="flex flex-col items-center pb-10">
                <img
                    className="w-24 h-24 mb-3 rounded-full shadow-lg"
                    src={`${getImageUrl(user?.profilePic)}`}
                    alt="Profile image"
                />
                <h5 className="mb-1 text-xl font-medium dark:text-white">{user?.username}</h5>
                <span className="text-sm text-gray-500">{user?.bio || "No Bio Provided"}</span>
            </div>
            {type === "user" && (
                <div className="flex mt-4 md:mt-6">
                    {status === "pending" && (
                        <button className="inline-flex items-center px-4 py-2 text-sm font-medium text-center text-white bg-[#5c7e10] rounded-full" disabled>
                            {translate("pending")}
                        </button>
                    )}
                    {status === "accepted" && (
                        <button
                            className="inline-flex items-center px-4 py-2 text-sm font-medium text-center text-white bg-[#5c7e10] rounded-full"
                            onClick={handleStartChat}
                            disabled={chatLoading}
                        >
                            {chatLoading ? translate("loading") : translate("startChat")}
                        </button>
                    )}
                    {status === "rejected" && (
                        <button className="inline-flex items-center px-4 py-2 text-sm font-medium text-center text-white bg-[#5c7e10] rounded-full"
                            onClick={handleAddFriend}
                            disabled={sendLoading}
                        >
                            {sendLoading ? translate("loading") : translate("addFriend")}
                        </button>
                    )}
                    {status === "none" && (
                        <button
                            className="inline-flex items-center px-4 py-2 text-sm font-medium text-center text-white bg-[#5c7e10] rounded-full"
                            onClick={handleAddFriend}
                            disabled={sendLoading}
                        >
                            {sendLoading ? translate("loading") : translate("addFriend")}
                        </button>
                    )}
                    {status === "friends" && (
                        <div className='flex flex-wrap gap-3'>
                            <button
                                className="inline-flex items-center px-4 py-2 text-sm font-medium text-center text-white bg-[#5c7e10] rounded-full"
                                onClick={handleStartChat}
                                disabled={chatLoading}
                            >
                                {chatLoading ? translate("loading") : translate("startChat")}
                            </button>
                            <button
                                className="inline-flex items-center px-4 py-2 text-sm font-medium text-center text-white bg-[#5c7e10] rounded-full"
                                onClick={handleUnfriend}
                                disabled={saving}
                            >
                                {saving ? translate("loading") : translate("unfriend")}
                            </button>
                        </div>
                    )}
                </div>
            )}
            {type === "friend-request" && (
                status === "pending" ? (
                    // check if the request is sent by the user then show only status pending
                    request?.sender?._id === currentUser?._id ? (
                        <button
                            className="inline-flex items-center my-5 px-4 py-2 text-sm font-medium text-center text-white bg-[#5c7e10] rounded-full"
                            disabled
                        >
                            {translate("requestSent")}
                        </button>
                    ) : (
                        // else show accept and reject buttons
                        <div className="flex mt-4 md:mt-6 gap-4">
                            <button
                                className="inline-flex items-center px-4 py-2 text-sm font-medium text-center text-white bg-[#5c7e10] rounded-full"
                                onClick={handleAcceptFriend}
                                disabled={acceptLoading}
                            >
                                {acceptLoading ? translate("loading") : translate("accept")}
                            </button>
                            <button
                                className="inline-flex items-center px-4 py-2 text-sm font-medium text-center text-white bg-[#5c7e10] rounded-full"
                                onClick={handleRejectFriend}
                                disabled={rejectLoading}
                            >
                                {rejectLoading ? translate("loading") : translate("reject")}
                            </button>
                        </div>
                    )
                ) : status === "accepted" ? (
                    <button
                        className="inline-flex items-center my-5 px-4 py-2 text-sm font-medium text-center text-white bg-[#5c7e10] rounded-full"
                        disabled
                    >
                        {translate("accepted")}
                    </button>
                ) : status === "rejected" && (
                    <button className="inline-flex items-center px-4 py-2 text-sm font-medium text-center text-white bg-[#5c7e10] rounded-full"
                        onClick={handleAddFriend}
                        disabled={sendLoading}
                    >
                        {sendLoading ? translate("loading") : translate("addFriend")}
                    </button>
                )
            )}
            {/* {type === "user" && (
        <div className="mt-4 md:mt-6">
          <button
            className="inline-flex items-center px-4 py-2 text-sm font-medium text-center text-white bg-[#5c7e10] rounded-full"
            onClick={handleStartChat}
            disabled={chatLoading}
          >
            {chatLoading ? "Loading" : "Start Chat"}
          </button>
        </div>
      )} */}
        </div>
    );
};

export default UserCard;
