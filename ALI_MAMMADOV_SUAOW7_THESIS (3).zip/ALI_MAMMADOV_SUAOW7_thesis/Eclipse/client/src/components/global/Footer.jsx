import React from 'react'
// import Logo from '../assets/logo.png';
import Logo from "../../assets/logo.png"
import useTranslation from '../../hooks/useTranslation';
const Footer = () => {
    const { translate } = useTranslation();
    return (
        <div className="card-footer" style={{ backgroundColor: '#171a21', width: '100%', height: '120px', padding: '20px 350px', color: 'whitesmoke', overflow: 'hidden', position: 'relative' }}>
            <div style={{ float: 'left', paddingRight: '10px', height: '100%' }}>
                <img src={Logo} width="60" height="25" alt="Eclipse Software" />
            </div>
            <div style={{ float: 'right', paddingLeft: '10px', height: '100%' }}>
            </div>
            <span>
                © 2024 {translate("footer")}
                <br />
                {translate("vatText")}
            </span>
        </div>
    )
}

export default Footer