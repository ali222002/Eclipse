import React from 'react'

const UserAvatar = ({
    src,
    showStatus = true,
    status = "Active",
    label,
    style,
    ...props
}) => {
    return (
        <div
            style={{
                position: 'relative',
                display: 'inline-block',
                marginRight: 4,
            }}
        >
            {showStatus && (
                <div
                    style={{
                        position: 'absolute',
                        top: -2,
                        right: -2,
                        width: 14,
                        height: 14,
                        borderRadius: '50%',
                        boxShadow: '0 0 0 2px #fff',
                        backgroundColor: status === 'Active' ? '#50CD89' : '#FF5B5B',
                    }}
                />
            )}
            <img
                alt={label}
                src={src}
                className='w-12 h-12 rounded-full object-cover'
                style={style}
                {...props}
            />
        </div>
    )
}

export default UserAvatar