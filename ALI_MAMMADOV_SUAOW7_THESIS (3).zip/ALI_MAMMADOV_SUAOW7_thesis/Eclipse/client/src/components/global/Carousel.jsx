import { useState, useEffect } from "react";
import { IoIosArrowBack, IoIosArrowForward } from "react-icons/io";

export default function Carousel({
  children: slides,
  autoSlide = false,
  autoSlideInterval = 5000,
  focusElems = 1
}) {
  const [curr, setCurr] = useState(0);

  // Update the maximum index calculation
  const maxIndex = Math.ceil(slides?.length / focusElems) - 1;

  const prev = () => {
    setCurr(curr => curr === 0 ? maxIndex : curr - 1);
  };

  const next = () => {
    setCurr(curr => curr === maxIndex ? 0 : curr + 1);
  };

  useEffect(() => {
    if (!autoSlide) return;
    const slideInterval = setInterval(next, autoSlideInterval);
    return () => clearInterval(slideInterval);
  }, [next]);

  return (
    <div className="overflow-hidden relative w-full flex md:flex-col md:max-h-[70vh] rounded">
      <div
        className="flex transition-transform ease-out duration-500 w-full"
        style={{ transform: `translateX(-${curr * (100 / focusElems)}%)` }}
      >
        {slides}
      </div>
      <div className="absolute inset-0 flex items-center justify-between p-1">
        <button onClick={prev} className="p-1 rounded-full shadow bg-white/80 text-gray-800 hover:bg-white">
          <IoIosArrowBack size={30} />
        </button>
        <button onClick={next} className="p-1 rounded-full shadow bg-white/80 text-gray-800 hover:bg-white">
          <IoIosArrowForward size={30} />
        </button>
      </div>

      <div className="absolute bottom-4 right-0 left-0 w-full">
        <div className="flex items-center justify-center gap-2 w-full">
          {Array.from({ length: Math.ceil(slides?.length / focusElems) }).map((_, i) => (
            <div
              key={i}
              className={`
              transition-all w-2 h-2 bg-white rounded-full
              ${curr === i ? "p-1" : "bg-opacity-50"}
            `}
              onClick={() => setCurr(i)} // Allow clicking on indicators to switch slides
            />
          ))}
        </div>
      </div>
    </div>
  );
}
