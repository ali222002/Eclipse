import React from 'react'

const UserRowSkeleton = () => {
    return (
        <div className="flex items-center justify-between p-4 bg-white border-b border-gray-200">
            <div className="flex items-center">
                <div className="w-12 h-12 bg-gray-200 rounded-full"></div>
                <div className="flex flex-col ml-4">
                    <div className="w-20 h-4 bg-gray-200 rounded"></div>
                    <div className="w-16 h-4 bg-gray-200 rounded mt-2"></div>
                </div>
            </div>
            <div className="w-12 h-4 bg-gray-200 rounded"></div>
        </div>

    )
}

export default UserRowSkeleton