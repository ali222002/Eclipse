import React, { useEffect, useState } from 'react'
import { MdOutlineEmail } from "react-icons/md";
// import axios from 'axios';
import { useGoogleLogin } from '@react-oauth/google';
import { useNavigate } from 'react-router-dom';
import { useGoogleLoginMutation } from '../../redux/apiServices/userApi';


const GoogleLoginComponent = () => {
    const navigate = useNavigate()
    const [user, setUser] = useState(null);
    const [loading, setLoading] = useState(false);

    const [googleLogin, { data, isLoading, isError, error, response }] = useGoogleLoginMutation()

    const login = useGoogleLogin({
        onSuccess: (codeResponse) => {
            setUser(codeResponse)
        },
        onError: (error) => console.log('Login Failed:', error)
    });

    useEffect(() => {
        async function fetchData() {
            if (user) {
                try {
                    setLoading(true)
                    const res = await fetch(`https://www.googleapis.com/oauth2/v1/userinfo?access_token=${user.access_token}`, {
                        headers: {
                            Authorization: `Bearer ${user.access_token}`,
                            Accept: 'application/json'
                        }
                    });
                    setLoading(false)
                    const data = await res.json();
                    let dataToSend = {
                        email: data.email,
                        name: data.name,
                        firstName: data.given_name,
                        lastName: data.family_name,
                        googleId: data.id,
                        imageUrl: data.picture
                    }
                    let response = await googleLogin(dataToSend)
                    localStorage.setItem("token", response?.data?.token)
                    localStorage.setItem("user", JSON.stringify(response?.data?.user))
                } catch (err) {
                    console.log(err)
                }
            }
        }
        fetchData();
    }, [user, googleLogin]);

    useEffect(() => {
        if (!isLoading && !isError && data && !error) {
            localStorage.setItem('token', data.token);
            localStorage.setItem('user', JSON.stringify(data.user));

            // check status if that is 201 then show form to select user type else if 200 return to profile
            if (data?.status === 201) {
                // setShowPopup(true)
            } else if (data?.status === 200) {
                navigate('/')
            }
        }
    }, [isLoading, data, isError, error, navigate, response])
    return (
        <>
            <div className="flex items-center justify-center my-2 bg-red-500 py-2 px-10 cursor-pointer" onClick={login} >
                <MdOutlineEmail className='cursor-pointer text-white' size={25} />
                <p className='text-white ml-2'>{isLoading || loading ? "Please Wait ..." : "Continue With Google"}</p>
            </div>
        </>
    )
}


export default GoogleLoginComponent
