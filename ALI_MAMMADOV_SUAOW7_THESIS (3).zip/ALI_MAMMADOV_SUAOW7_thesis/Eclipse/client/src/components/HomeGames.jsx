import React from 'react'
import Categories from './Categories'
import GameCard from './global/GameCard'
import GameSkeleton from './global/GameSkeleton'
import { useGetGamesQuery } from '../redux/apiServices/gameApi'
import Carousel from './global/Carousel'
import useTranslation from '../hooks/useTranslation'

const HomeGames = () => {
    const { translate } = useTranslation()
    const { isLoading, data } = useGetGamesQuery()
    return (
        <>
            <div className="w-full">
                <h3 className='text-white text-lg my-5 font-bold'>{translate("store")}</h3>
                {
                    isLoading ?
                        <div className='w-full grid grid-cols-1  gap-4 mt-4'>
                            {
                                Array(10).fill().map((_, i) => <GameSkeleton key={i} />)
                            }
                        </div> :
                        <div className=''> {/* Added grid layout */}
                            <Carousel focusElems={1} autoSlide={true}>
                                {data?.slice(0, 5)?.map(game => <div className='min-w-[80vw]' key={game?._id}><GameCard game={game} /></div>)}
                            </Carousel>
                        </div>
                }

            </div>
        </>
    )
}

export default HomeGames