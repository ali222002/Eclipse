import React from 'react';
import ContactsTable from '../components/dashboard/messages/ContactsTable';

const ChatsPage = () => {

    return (
        <div className="flex h-[92vh]">
            <div className='grid grid-cols-1 lg:grid-cols-12 gap-8 w-full'>
                <div className='hidden lg:block lg:col-span-4'>
                    <ContactsTable />
                </div>
                <div className='col-span-1 lg:col-span-8'>
                    {/* <SelectedConversation /> */}
                </div>
                
            </div>
        </div>
    );
};

export default ChatsPage;
