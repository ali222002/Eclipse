import React, { useState } from 'react';
import ChatBox from '../components/messages/ChatBox';
import ChatList from '../components/messages/ChatList';
import ContactsTable from '../components/dashboard/messages/ContactsTable';
import SelectedConversation from '../components/dashboard/messages/SelectedConversation';


const MessagePage = () => {
    const [selectedChat, setSelectedChat] = useState(null);

    const handleSelectChat = (chat) => {
        setSelectedChat(chat);
    };

    return (
        <div className="flex h-[92vh]">
            {/* <div className="w-1/3 border-r border-gray-300">
        <ChatList onSelectChat={handleSelectChat} />
      </div>
      <div className="w-2/3">
        {selectedChat ? <ChatBox chat={selectedChat} /> : <div className="p-4 text-white">Select a chat</div>}
      </div> */}
            <div className='grid grid-cols-1 lg:grid-cols-12 gap-8 w-full'>
                <div className='hidden lg:block lg:col-span-4'>
                    <ContactsTable />
                </div>
                <div className='col-span-1 lg:col-span-8'>
                    <SelectedConversation />
                </div>
                
            </div>
        </div>
    );
};

export default MessagePage;
