import React, { useEffect, useState } from 'react'
import Categories from '../components/Categories'
import { useBoughtGamesQuery, usePlayGameMutation } from '../redux/apiServices/gameApi'
import { SERVER_URL } from '../utils/util'
import { useGetWishlistQuery, useUpdatewishlistMutation } from '../redux/apiServices/userApi'

const Library = () => {
    const [tab, setTab] = useState('purchased')

    return (
        <div className="lg:max-w-[90vw] xl:max-w-[80vw] mx-auto min-h-[90vh]">
            <Categories />
            <div className='flex my-5'>
                <div className='w-full'>
                    <div className='flex my-5'>
                        <button onClick={() => setTab('purchased')} className={`px-4 py-2 ${tab === 'purchased' ? 'bg-[#2f3e4e]' : 'bg-transperent'} text-white`}>Purchased</button>
                        <button onClick={() => setTab('wishlist')} className={`px-4 py-2 ${tab === 'wishlist' ? 'bg-[#2f3e4e]' : 'bg-transperent'} text-white`}>Wishlist</button>
                    </div>
                </div>
            </div>

            <div className='w-full'>
                {
                    tab === 'purchased' ? <PurchasedTab /> : <WishlistTab />
                }
            </div>
        </div>
    )
}

const PurchasedTab = () => {
    const { isLoading, data } = useBoughtGamesQuery()
    const [playGame, { isLoading: saving, data: gameData }] = usePlayGameMutation()

    const handleDownload = (game) => {
        let downloadLink = SERVER_URL + "/" + game?.downloadLink
        window.open(downloadLink, '_blank')
    }

    const handlePlay = (game) => {
        // play game
        playGame({ game: game?._id })
        // download game
        handleDownload(game)
    }

    return (
        <div>
            {
                isLoading ?
                    <div className='grid grid-cols-3 gap-5'>
                        {
                            Array(6).fill().map((_, i) => (
                                <div key={i} className='bg-[#1b2838] p-4 rounded-lg border'>
                                    <div className='flex justify-between items-center'>
                                        <div className='w-20 h-20 bg-gray-500 rounded-lg'></div>
                                        <div>
                                            <h1 className='text-white'>Loading...</h1>
                                            <p className='text-white'>Loading...</p>
                                        </div>
                                    </div>
                                </div>
                            ))
                        }
                    </div>
                    :
                    <div className='grid grid-cols-3 gap-5'>
                        {data?.map(game => (
                            <div key={game._id} className='bg-[#1b2838] p-4 rounded-lg border'>
                                <div className='flex justify-between items-center'>
                                    <img src={SERVER_URL + "/" + game?.thumbnail} alt={game.title} className='w-20 h-20 object-cover' />
                                    <div className='ml-5'>
                                        <h1 className='text-white'>{game.description?.substring(0, 50)}</h1>
                                        <p className='text-white'>${game.price}</p>
                                    </div>
                                </div>
                                <div className='flex flex-col items-end'>
                                    <button className='bg-[#2f3e4e] text-white px-2 py-1 rounded-lg' onClick={() => handlePlay(game)}>
                                        {saving ? 'Loading...' : 'Play'}
                                    </button>
                                </div>
                            </div>
                        ))}
                    </div>
            }
        </div>
    )
}

const WishlistTab = () => {
    const { isLoading, data } = useGetWishlistQuery()
    const [update, { isLoading: updating }] = useUpdatewishlistMutation()
    return (
        <div>
            {
                isLoading ?
                    <div className='grid grid-cols-3 gap-5'>
                        {
                            Array(6).fill().map((_, i) => (
                                <div key={i} className='bg-[#1b2838] p-4 rounded-lg border'>
                                    <div className='flex justify-between items-center'>
                                        <div className='w-20 h-20 bg-gray-500 rounded-lg'></div>
                                        <div>
                                            <h1 className='text-white'>Loading...</h1>
                                            <p className='text-white'>Loading...</p>
                                        </div>
                                    </div>
                                </div>
                            ))
                        }
                    </div>
                    :
                    <div className='grid grid-cols-3 gap-5'>
                        {data?.map(game => (
                            <div key={game._id} className='bg-[#1b2838] p-4 rounded-lg border'>
                                <div className='flex justify-between items-center'>
                                    <img src={SERVER_URL + "/" + game?.thumbnail} alt={game.title} className='w-20 h-20 object-cover' />
                                    <div className='ml-5'>
                                        <h1 className='text-white'>{game.description?.substring(0, 50)}</h1>
                                        <p className='text-white'>${game.price}</p>
                                        <button
                                            className='bg-[#2f3e4e] text-white px-2 py-1 rounded-lg'
                                            onClick={() => update({ game: game?._id })}
                                            disabled={updating}
                                        >
                                            {updating ? 'Removing...' : 'Remove'}
                                        </button>
                                    </div>
                                </div>
                            </div>
                        ))}
                    </div>
            }
            {
                data?.length === 0 && <p className='text-white text-lg'>No games in wishlist</p>
            }
        </div>
    )
}
export default Library