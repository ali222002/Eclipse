import React from 'react'
import Categories from '../components/Categories'
import { useGetMyGamesQuery } from '../redux/apiServices/gameApi'
import { SERVER_URL } from '../utils/util'

const SalesChart = () => {
    const { isLoading, data } = useGetMyGamesQuery()
    return (
        <div className="lg:max-w-[90vw] xl:max-w-[80vw] mx-auto min-h-screen">
            <Categories />

            <div className='w-full'>
                <h1 className='text-white text-lg my-5'>Sales Chart</h1>

                <div className='grid grid-cols-3 gap-5'>
                    {
                        isLoading ?
                            Array(10).fill().map((_, i) => (
                                <div key={i} className='bg-[#1b2838] p-4 rounded-lg border'>
                                    <div className='animate-pulse flex justify-between items-center'>
                                        <div className='bg-[#2f3e4e] w-1/2 h-20'></div>
                                    </div>
                                    <div className='mt-3'>
                                        <div className='animate-pulse flex justify-between items-center'>
                                            <div className='bg-[#2f3e4e] w-1/2 h-5'></div>
                                        </div>
                                        <div className='animate-pulse flex justify-between items-center'>
                                            <div className='bg-[#2f3e4e] w-1/2 h-5'></div>
                                        </div>
                                    </div>
                                </div>
                            )) :
                            data &&
                                data.length === 0 ?
                                <div className='text-white text-center'>You haven't published any games</div> :
                                data?.map(game => (
                                    <div key={game._id} className='bg-[#1b2838] p-4 rounded-lg border'>
                                        <div className='flex justify-between items-center'>
                                            <img src={SERVER_URL + "/" + game?.thumbnail} alt={game.description} className='w-full h-auto object-cover' />
                                        </div>
                                        <div className='mt-3'>
                                            <p className='text-white'>{game.description}</p>
                                            <p className='text-white border px-3 py-2 max-w-min rounded-full my-3'>${game.price}</p>
                                        </div>
                                        <hr className='border-t border-white my-3' />
                                        <h4 className='text-white font-bold mt-5 mb-2'>Game Stats</h4>
                                        <div className='flex justify-between items-center'>
                                            <p className='text-white'>Purchases: {game?.bought}</p>
                                            <p className='text-white'>Likes: {game?.likes?.length}</p>
                                            <p className='text-white'>Un Likes: {game?.dislikes?.length}</p>
                                        </div>
                                    </div>
                                ))}
                </div>

            </div>
        </div>
    )
}

export default SalesChart