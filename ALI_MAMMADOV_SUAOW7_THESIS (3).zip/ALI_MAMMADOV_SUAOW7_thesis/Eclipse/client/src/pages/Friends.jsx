import React, { useState } from 'react'
import { useGetFriendsQuery } from '../redux/apiServices/userApi'
import Categories from '../components/Categories'
import useTranslation from '../hooks/useTranslation'
import UserCard from '../components/global/UserCard'
import UserSkeleton from '../components/global/UserSkeleton'

const FriendsPage = () => {
  const { translate } = useTranslation()

  return (
    <div className="lg:max-w-[90vw] xl:max-w-[80vw] mx-auto min-h-[90vh]">
      <Categories />
      <div className='flex mt-5'>
        <div className='w-full'>
          <div className='fle justify-center items-center py-10 text-white min-h-full w-full flex-col'>
            <FriendsTab />
          </div>
        </div>
      </div>
    </div>
  )
}

export const FriendsTab = () => {
  const [search, setSearch] = useState("")
  const { translate } = useTranslation()
  const { isLoading, data } = useGetFriendsQuery()

  return (
    <>
      <input type='text' placeholder={translate('username')} className='bg-[#2d3b4e] text-white px-6 py-4 rounded-2xl my-5 w-[40%]' onChange={(e) => setSearch(e.target.value)} value={search} />
      <div className='bg-[#1b2838] grid grid-cols-4 gap-5 w-full'>
        {
          isLoading ? Array(10).fill().map((_, i) => <UserSkeleton key={i} />) :
            data
              ?.filter((user) => user?.username?.toLowerCase()?.includes(search?.toLowerCase()))
              ?.map((friend, i) => (
                <UserCard key={i} user={friend} status={'friends'} />
              ))
        }
      </div>
    </>
  )
}

export default FriendsPage