import React, { useEffect, useState } from 'react';
import Categories from '../components/Categories';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { useCommentGameMutation, useGetGameDetailQuery, useLikeGameMutation, useUnlikeGameMutation } from '../redux/apiServices/gameApi';
import { getImageUrl, SERVER_URL } from '../utils/util';
import { useLocalStorage } from '../hooks/useLocalStorage';
import { useDispatch, useSelector } from 'react-redux';
import { setcartLengthToStore } from '../redux/slices/globalSlice';
import { useAddToCartMutation, useUpdateCartMutation, useUpdatewishlistMutation } from '../redux/apiServices/userApi';
import likeIcon from '../assets/like.png'; 
import dislikeIcon from '../assets/dislike.png'; 

const GameDetails = () => {
    const { id } = useParams();
    const { isLoading, data } = useGetGameDetailQuery(id, {
        skip: !id
    });

    return (
        <div className="lg:max-w-[90vw] xl:max-w-[80vw] mx-auto min-h-screen">
            <Categories />
            {
                isLoading ? <p>Loading...</p>
                    :
                    <div className='flex flex-col justify-center items-center py-10 text-white min-h-full w-full'>
                        <div className='grid grid-cols-12 gap-4'>
                            <div className='col-span-8'>
                                <img src={SERVER_URL + "/" + data?.thumbnail} className='object-cover w-full h-[30rem]' alt="" />
                            </div>
                            <div className='col-span-4'>
                                <div className='bg-[#1b2838] p-10 rounded-lg border h-full'>
                                    <img src={SERVER_URL + "/" + data?.thumbnail} className='object-cover w-full' alt="" />
                                    <h4 className='text-[20px] my-3'>{data?.type}</h4>
                                    <h1 className='text-[30px] my-3'>{data?.name}</h1>
                                    <p className='text-[20px]'>{data?.description}</p>
                                    <p className='text-[20px] font-bold'>{data?.price}$</p>
                                    <GameActions game={data} />
                                    <GameAnalytics game={data} />
                                </div>
                            </div>
                        </div>
                        <div className='grid grid-cols-12 gap-4 w-full'>
                            <div className='col-span-8 grid grid-cols-4 gap-5'>
                                {
                                    data?.pictures?.map((picture, index) => (
                                        <img key={index} src={SERVER_URL + "/" + picture} alt="" className='object-cover w-full border rounded' />
                                    ))
                                }
                            </div>
                        </div>
                        <div className='w-full my-10'>
                            <h3 className='text-[30px] my-5 underline'>Description</h3>
                            <p className='text-[20px]'>{data?.description}</p>
                        </div>
                        <GameCommentsSection game={data} />
                    </div>
            }
        </div>
    );
}


const GameCommentsSection = ({ game }) => {
    const [comment, setComment] = useState('');
    const [add, { isLoading, data }] = useCommentGameMutation();

    const handleAddComment = () => {
        let data = {
            comment: {
                comment: comment,
            },
            game: game?._id
        };
        add(data);
    }

    return (
        <div className='w-full my-10'>
            <h3 className='text-[30px] my-5 underline'>Comments</h3>
            <div className='grid grid-cols-12 gap-4 my-10'>
                <div className='col-span-8'>
                    {game?.comments?.map((comment, index) => (
                        <div className='bg-[#1b2838] p-5 rounded-lg flex' key={index}>
                            <img src={getImageUrl(comment?.user?.profilePic)} alt="" className='object-cover w-[50px] h-[50px] rounded-full' />
                            <div className='ml-5'>
                                <h1 className='text-[20px]'>{comment?.user?.username}</h1>
                                <p className='text-[15px]'>{comment?.comment}</p>
                            </div>
                        </div>))}
                </div>
            </div>

            <div className='grid grid-cols-12 gap-4'>
                <div className='col-span-8'>
                    <textarea className='bg-[#1b2838] text-white border w-full p-2 rounded-lg h-20'
                        onChange={(e) => setComment(e.target.value)}
                        value={comment}
                        placeholder='Write your comment here...'>
                    </textarea>
                    <button className='text-md rounded-lg my-3 px-2 py-3 bg-transperent border  hover:bg-white hover:text-black' onClick={handleAddComment} disabled={isLoading}>
                        {
                            isLoading ? "Loading" : "Add Comment"
                        }
                    </button>
                </div>
            </div>
        </div>
    );
}

const GameAnalytics = ({ game }) => {
    const [like, setLike] = useState(false);
    const [dislike, setDislike] = useState(false);

    const [likeGame, { isLoading }] = useLikeGameMutation();
    const [unlikeGame, { isLoading: unLoading }] = useUnlikeGameMutation();

    const handleLike = () => {
        setLike(true);
        setDislike(false);

        if (!like) {
            likeGame(game?._id);
        }
    }

    const handleDislike = () => {
        setDislike(true);
        setLike(false);

        if (!dislike) {
            unlikeGame(game?._id);
        }
    }

    return (
        <div className='grid grid-cols-3 gap-4'>
            <div className='flex items-center justify-center'>
                <img 
                    src={likeIcon} 
                    className='w-6 h-6 cursor-pointer' 
                    alt="Like" 
                    onClick={handleLike} 
                />
                <p className='text-[20px] ml-4'>{game?.likes?.length}</p>
            </div>
            <div className='flex items-center justify-center'>
                <img 
                    src={dislikeIcon} 
                    className='w-6 h-6 cursor-pointer' 
                    alt="Dislike" 
                    onClick={handleDislike} 
                />
                <p className='text-[20px] ml-4'>{game?.dislikes?.length}</p>
            </div>
        </div>
    );
}


const GameActions = ({ game }) => {
    const navigate = useNavigate();
    const [cart, setCart] = useLocalStorage("myCart", []);

    const [updateCart] = useUpdateCartMutation();
    const [updateWishlist] = useUpdatewishlistMutation();

    const user = useSelector(state => state.global?.user);

    const dispatch = useDispatch();

    const cartLength = useSelector(state => state.global.cartLength);
    const [addedToCart, setAddedToCart] = useState(cart?.find((item) => item?._id === game?._id));
    const [addedToWishlist, setAddedToWishlist] = useState(user?.wishlist?.includes(game?._id)); 

    useEffect(() => {
        setAddedToWishlist(user?.wishlist?.includes(game?._id));
    }, [JSON.stringify(user)]);

    const handleWishList = () => {
        if (!user) {
            return;
        }

        updateWishlist({
            game: game?._id
        });
    }

    const handleAddToCart = () => {
        if (!user) {
            return;
        }
        let cart = JSON.parse(localStorage.getItem("myCart")) || [];

        updateCart({
            game: game?._id
        });

        if (cart?.find((item) => item?._id === game?._id)) {
            setAddedToCart(false);
            dispatch(setcartLengthToStore(cartLength - 1));
            setCart((prev) => {
                return prev.filter((item) => item._id !== game._id);
            });
            return;
        }

        dispatch(setcartLengthToStore(cartLength + 1));
        setAddedToCart(true);

        let previousCart = cart;
        setCart([...previousCart, {
            name: game?.name,
            price: game?.price,
            thumbnail: game?.thumbnail,
            _id: game?._id,
            description: game?.description
        }]);
    }

    const handleBuy = () => {
        if (!user) {
            return;
        }

        if (user?.gamesBought?.includes(game?._id)) {
            return;
        }

        let cart = JSON.parse(localStorage.getItem("myCart")) || [];

        if (!cart?.find((item) => item?._id === game?._id)) {
            handleAddToCart();
        }
        navigate('/cart');
    }

    return (
        <div className='grid grid-cols-3 gap-4 my-5'>
            <button className={`text-md rounded-full px-2 py-3 bg-transperent border hover:bg-white hover:text-black disabled:cursor-not-allowed ${addedToCart ? 'bg-yellow-200 text-black' : 'bg-transparent'}`} disabled={!user || user?.gamesBought?.includes(game?._id)} onClick={handleAddToCart}>Add To Cart</button>
            <button className={`text-md rounded-full px-2 py-3 bg-transperent border hover:bg-white hover:text-black disabled:cursor-not-allowed col-span- ${addedToWishlist ? 'bg-yellow-200 text-black' : 'bg-transparent'}`} disabled={!user || user?.gamesBought?.includes(game?._id)} onClick={handleWishList}>Add To Wishlist</button>
        </div>
    );
}

export default GameDetails;
